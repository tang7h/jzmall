<?php
$data = array (
  0 => 
  array (
    'parent_id' => '0',
    'cat_id' => '1',
    'grade' => '0',
  ),
  1 => 
  array (
    'parent_id' => '0',
    'cat_id' => '2',
    'grade' => '0',
  ),
  2 => 
  array (
    'parent_id' => '0',
    'cat_id' => '3',
    'grade' => '0',
  ),
  3 => 
  array (
    'parent_id' => '0',
    'cat_id' => '4',
    'grade' => '0',
  ),
  4 => 
  array (
    'parent_id' => '0',
    'cat_id' => '5',
    'grade' => '0',
  ),
  5 => 
  array (
    'parent_id' => '0',
    'cat_id' => '6',
    'grade' => '0',
  ),
  6 => 
  array (
    'parent_id' => '0',
    'cat_id' => '7',
    'grade' => '0',
  ),
  7 => 
  array (
    'parent_id' => '0',
    'cat_id' => '8',
    'grade' => '0',
  ),
  8 => 
  array (
    'parent_id' => '0',
    'cat_id' => '9',
    'grade' => '0',
  ),
  9 => 
  array (
    'parent_id' => '0',
    'cat_id' => '10',
    'grade' => '0',
  ),
  10 => 
  array (
    'parent_id' => '0',
    'cat_id' => '11',
    'grade' => '0',
  ),
  11 => 
  array (
    'parent_id' => '0',
    'cat_id' => '12',
    'grade' => '0',
  ),
  12 => 
  array (
    'parent_id' => '0',
    'cat_id' => '13',
    'grade' => '0',
  ),
  13 => 
  array (
    'parent_id' => '0',
    'cat_id' => '14',
    'grade' => '0',
  ),
  14 => 
  array (
    'parent_id' => '1',
    'cat_id' => '15',
    'grade' => '0',
  ),
  15 => 
  array (
    'parent_id' => '1',
    'cat_id' => '16',
    'grade' => '0',
  ),
  16 => 
  array (
    'parent_id' => '1',
    'cat_id' => '17',
    'grade' => '0',
  ),
  17 => 
  array (
    'parent_id' => '1',
    'cat_id' => '18',
    'grade' => '0',
  ),
  18 => 
  array (
    'parent_id' => '1',
    'cat_id' => '19',
    'grade' => '0',
  ),
  19 => 
  array (
    'parent_id' => '1',
    'cat_id' => '20',
    'grade' => '0',
  ),
  20 => 
  array (
    'parent_id' => '1',
    'cat_id' => '21',
    'grade' => '0',
  ),
  21 => 
  array (
    'parent_id' => '1',
    'cat_id' => '22',
    'grade' => '0',
  ),
  22 => 
  array (
    'parent_id' => '1',
    'cat_id' => '23',
    'grade' => '0',
  ),
  23 => 
  array (
    'parent_id' => '1',
    'cat_id' => '24',
    'grade' => '0',
  ),
  24 => 
  array (
    'parent_id' => '1',
    'cat_id' => '25',
    'grade' => '0',
  ),
  25 => 
  array (
    'parent_id' => '15',
    'cat_id' => '26',
    'grade' => '0',
  ),
  26 => 
  array (
    'parent_id' => '15',
    'cat_id' => '27',
    'grade' => '0',
  ),
  27 => 
  array (
    'parent_id' => '15',
    'cat_id' => '28',
    'grade' => '0',
  ),
  28 => 
  array (
    'parent_id' => '15',
    'cat_id' => '29',
    'grade' => '0',
  ),
  29 => 
  array (
    'parent_id' => '15',
    'cat_id' => '30',
    'grade' => '0',
  ),
  30 => 
  array (
    'parent_id' => '15',
    'cat_id' => '31',
    'grade' => '0',
  ),
  31 => 
  array (
    'parent_id' => '15',
    'cat_id' => '32',
    'grade' => '0',
  ),
  32 => 
  array (
    'parent_id' => '16',
    'cat_id' => '33',
    'grade' => '0',
  ),
  33 => 
  array (
    'parent_id' => '16',
    'cat_id' => '34',
    'grade' => '0',
  ),
  34 => 
  array (
    'parent_id' => '16',
    'cat_id' => '35',
    'grade' => '0',
  ),
  35 => 
  array (
    'parent_id' => '16',
    'cat_id' => '36',
    'grade' => '0',
  ),
  36 => 
  array (
    'parent_id' => '16',
    'cat_id' => '37',
    'grade' => '0',
  ),
  37 => 
  array (
    'parent_id' => '16',
    'cat_id' => '38',
    'grade' => '0',
  ),
  38 => 
  array (
    'parent_id' => '17',
    'cat_id' => '39',
    'grade' => '0',
  ),
  39 => 
  array (
    'parent_id' => '17',
    'cat_id' => '40',
    'grade' => '0',
  ),
  40 => 
  array (
    'parent_id' => '17',
    'cat_id' => '41',
    'grade' => '0',
  ),
  41 => 
  array (
    'parent_id' => '17',
    'cat_id' => '42',
    'grade' => '0',
  ),
  42 => 
  array (
    'parent_id' => '18',
    'cat_id' => '43',
    'grade' => '0',
  ),
  43 => 
  array (
    'parent_id' => '18',
    'cat_id' => '44',
    'grade' => '0',
  ),
  44 => 
  array (
    'parent_id' => '18',
    'cat_id' => '45',
    'grade' => '0',
  ),
  45 => 
  array (
    'parent_id' => '18',
    'cat_id' => '46',
    'grade' => '0',
  ),
  46 => 
  array (
    'parent_id' => '18',
    'cat_id' => '47',
    'grade' => '0',
  ),
  47 => 
  array (
    'parent_id' => '19',
    'cat_id' => '48',
    'grade' => '0',
  ),
  48 => 
  array (
    'parent_id' => '19',
    'cat_id' => '49',
    'grade' => '0',
  ),
  49 => 
  array (
    'parent_id' => '19',
    'cat_id' => '50',
    'grade' => '0',
  ),
  50 => 
  array (
    'parent_id' => '19',
    'cat_id' => '51',
    'grade' => '0',
  ),
  51 => 
  array (
    'parent_id' => '19',
    'cat_id' => '52',
    'grade' => '0',
  ),
  52 => 
  array (
    'parent_id' => '19',
    'cat_id' => '53',
    'grade' => '0',
  ),
  53 => 
  array (
    'parent_id' => '20',
    'cat_id' => '54',
    'grade' => '0',
  ),
  54 => 
  array (
    'parent_id' => '20',
    'cat_id' => '55',
    'grade' => '0',
  ),
  55 => 
  array (
    'parent_id' => '20',
    'cat_id' => '56',
    'grade' => '0',
  ),
  56 => 
  array (
    'parent_id' => '20',
    'cat_id' => '57',
    'grade' => '0',
  ),
  57 => 
  array (
    'parent_id' => '21',
    'cat_id' => '58',
    'grade' => '0',
  ),
  58 => 
  array (
    'parent_id' => '21',
    'cat_id' => '59',
    'grade' => '0',
  ),
  59 => 
  array (
    'parent_id' => '21',
    'cat_id' => '60',
    'grade' => '0',
  ),
  60 => 
  array (
    'parent_id' => '21',
    'cat_id' => '61',
    'grade' => '0',
  ),
  61 => 
  array (
    'parent_id' => '21',
    'cat_id' => '62',
    'grade' => '0',
  ),
  62 => 
  array (
    'parent_id' => '21',
    'cat_id' => '63',
    'grade' => '0',
  ),
  63 => 
  array (
    'parent_id' => '21',
    'cat_id' => '64',
    'grade' => '0',
  ),
  64 => 
  array (
    'parent_id' => '21',
    'cat_id' => '65',
    'grade' => '0',
  ),
  65 => 
  array (
    'parent_id' => '21',
    'cat_id' => '66',
    'grade' => '0',
  ),
  66 => 
  array (
    'parent_id' => '21',
    'cat_id' => '67',
    'grade' => '0',
  ),
  67 => 
  array (
    'parent_id' => '22',
    'cat_id' => '68',
    'grade' => '0',
  ),
  68 => 
  array (
    'parent_id' => '22',
    'cat_id' => '69',
    'grade' => '0',
  ),
  69 => 
  array (
    'parent_id' => '22',
    'cat_id' => '70',
    'grade' => '0',
  ),
  70 => 
  array (
    'parent_id' => '22',
    'cat_id' => '71',
    'grade' => '0',
  ),
  71 => 
  array (
    'parent_id' => '22',
    'cat_id' => '72',
    'grade' => '0',
  ),
  72 => 
  array (
    'parent_id' => '22',
    'cat_id' => '73',
    'grade' => '0',
  ),
  73 => 
  array (
    'parent_id' => '22',
    'cat_id' => '74',
    'grade' => '0',
  ),
  74 => 
  array (
    'parent_id' => '22',
    'cat_id' => '75',
    'grade' => '0',
  ),
  75 => 
  array (
    'parent_id' => '23',
    'cat_id' => '76',
    'grade' => '0',
  ),
  76 => 
  array (
    'parent_id' => '23',
    'cat_id' => '77',
    'grade' => '0',
  ),
  77 => 
  array (
    'parent_id' => '23',
    'cat_id' => '78',
    'grade' => '0',
  ),
  78 => 
  array (
    'parent_id' => '23',
    'cat_id' => '79',
    'grade' => '0',
  ),
  79 => 
  array (
    'parent_id' => '23',
    'cat_id' => '80',
    'grade' => '0',
  ),
  80 => 
  array (
    'parent_id' => '24',
    'cat_id' => '81',
    'grade' => '0',
  ),
  81 => 
  array (
    'parent_id' => '24',
    'cat_id' => '82',
    'grade' => '0',
  ),
  82 => 
  array (
    'parent_id' => '24',
    'cat_id' => '83',
    'grade' => '0',
  ),
  83 => 
  array (
    'parent_id' => '24',
    'cat_id' => '84',
    'grade' => '0',
  ),
  84 => 
  array (
    'parent_id' => '25',
    'cat_id' => '85',
    'grade' => '0',
  ),
  85 => 
  array (
    'parent_id' => '25',
    'cat_id' => '86',
    'grade' => '0',
  ),
  86 => 
  array (
    'parent_id' => '25',
    'cat_id' => '87',
    'grade' => '0',
  ),
  87 => 
  array (
    'parent_id' => '25',
    'cat_id' => '88',
    'grade' => '0',
  ),
  88 => 
  array (
    'parent_id' => '25',
    'cat_id' => '89',
    'grade' => '0',
  ),
  89 => 
  array (
    'parent_id' => '2',
    'cat_id' => '90',
    'grade' => '5',
  ),
  90 => 
  array (
    'parent_id' => '2',
    'cat_id' => '91',
    'grade' => '0',
  ),
  91 => 
  array (
    'parent_id' => '2',
    'cat_id' => '92',
    'grade' => '0',
  ),
  92 => 
  array (
    'parent_id' => '2',
    'cat_id' => '93',
    'grade' => '0',
  ),
  93 => 
  array (
    'parent_id' => '2',
    'cat_id' => '94',
    'grade' => '0',
  ),
  94 => 
  array (
    'parent_id' => '90',
    'cat_id' => '95',
    'grade' => '0',
  ),
  95 => 
  array (
    'parent_id' => '90',
    'cat_id' => '96',
    'grade' => '0',
  ),
  96 => 
  array (
    'parent_id' => '90',
    'cat_id' => '97',
    'grade' => '0',
  ),
  97 => 
  array (
    'parent_id' => '90',
    'cat_id' => '98',
    'grade' => '0',
  ),
  98 => 
  array (
    'parent_id' => '90',
    'cat_id' => '99',
    'grade' => '0',
  ),
  99 => 
  array (
    'parent_id' => '90',
    'cat_id' => '100',
    'grade' => '0',
  ),
  100 => 
  array (
    'parent_id' => '90',
    'cat_id' => '101',
    'grade' => '0',
  ),
  101 => 
  array (
    'parent_id' => '90',
    'cat_id' => '102',
    'grade' => '0',
  ),
  102 => 
  array (
    'parent_id' => '90',
    'cat_id' => '103',
    'grade' => '0',
  ),
  103 => 
  array (
    'parent_id' => '90',
    'cat_id' => '104',
    'grade' => '0',
  ),
  104 => 
  array (
    'parent_id' => '90',
    'cat_id' => '105',
    'grade' => '0',
  ),
  105 => 
  array (
    'parent_id' => '90',
    'cat_id' => '106',
    'grade' => '0',
  ),
  106 => 
  array (
    'parent_id' => '91',
    'cat_id' => '107',
    'grade' => '0',
  ),
  107 => 
  array (
    'parent_id' => '91',
    'cat_id' => '108',
    'grade' => '0',
  ),
  108 => 
  array (
    'parent_id' => '91',
    'cat_id' => '109',
    'grade' => '0',
  ),
  109 => 
  array (
    'parent_id' => '91',
    'cat_id' => '110',
    'grade' => '0',
  ),
  110 => 
  array (
    'parent_id' => '91',
    'cat_id' => '111',
    'grade' => '0',
  ),
  111 => 
  array (
    'parent_id' => '91',
    'cat_id' => '112',
    'grade' => '0',
  ),
  112 => 
  array (
    'parent_id' => '91',
    'cat_id' => '113',
    'grade' => '0',
  ),
  113 => 
  array (
    'parent_id' => '91',
    'cat_id' => '114',
    'grade' => '0',
  ),
  114 => 
  array (
    'parent_id' => '91',
    'cat_id' => '115',
    'grade' => '0',
  ),
  115 => 
  array (
    'parent_id' => '91',
    'cat_id' => '116',
    'grade' => '0',
  ),
  116 => 
  array (
    'parent_id' => '91',
    'cat_id' => '117',
    'grade' => '0',
  ),
  117 => 
  array (
    'parent_id' => '91',
    'cat_id' => '118',
    'grade' => '0',
  ),
  118 => 
  array (
    'parent_id' => '91',
    'cat_id' => '119',
    'grade' => '0',
  ),
  119 => 
  array (
    'parent_id' => '91',
    'cat_id' => '120',
    'grade' => '0',
  ),
  120 => 
  array (
    'parent_id' => '91',
    'cat_id' => '121',
    'grade' => '0',
  ),
  121 => 
  array (
    'parent_id' => '92',
    'cat_id' => '122',
    'grade' => '0',
  ),
  122 => 
  array (
    'parent_id' => '92',
    'cat_id' => '123',
    'grade' => '0',
  ),
  123 => 
  array (
    'parent_id' => '92',
    'cat_id' => '124',
    'grade' => '0',
  ),
  124 => 
  array (
    'parent_id' => '92',
    'cat_id' => '125',
    'grade' => '0',
  ),
  125 => 
  array (
    'parent_id' => '92',
    'cat_id' => '126',
    'grade' => '0',
  ),
  126 => 
  array (
    'parent_id' => '92',
    'cat_id' => '127',
    'grade' => '0',
  ),
  127 => 
  array (
    'parent_id' => '92',
    'cat_id' => '128',
    'grade' => '0',
  ),
  128 => 
  array (
    'parent_id' => '92',
    'cat_id' => '129',
    'grade' => '0',
  ),
  129 => 
  array (
    'parent_id' => '92',
    'cat_id' => '130',
    'grade' => '0',
  ),
  130 => 
  array (
    'parent_id' => '92',
    'cat_id' => '131',
    'grade' => '0',
  ),
  131 => 
  array (
    'parent_id' => '92',
    'cat_id' => '132',
    'grade' => '0',
  ),
  132 => 
  array (
    'parent_id' => '92',
    'cat_id' => '133',
    'grade' => '0',
  ),
  133 => 
  array (
    'parent_id' => '92',
    'cat_id' => '134',
    'grade' => '0',
  ),
  134 => 
  array (
    'parent_id' => '92',
    'cat_id' => '135',
    'grade' => '0',
  ),
  135 => 
  array (
    'parent_id' => '92',
    'cat_id' => '136',
    'grade' => '0',
  ),
  136 => 
  array (
    'parent_id' => '92',
    'cat_id' => '137',
    'grade' => '0',
  ),
  137 => 
  array (
    'parent_id' => '92',
    'cat_id' => '138',
    'grade' => '0',
  ),
  138 => 
  array (
    'parent_id' => '93',
    'cat_id' => '139',
    'grade' => '0',
  ),
  139 => 
  array (
    'parent_id' => '93',
    'cat_id' => '140',
    'grade' => '0',
  ),
  140 => 
  array (
    'parent_id' => '93',
    'cat_id' => '141',
    'grade' => '0',
  ),
  141 => 
  array (
    'parent_id' => '93',
    'cat_id' => '142',
    'grade' => '0',
  ),
  142 => 
  array (
    'parent_id' => '93',
    'cat_id' => '143',
    'grade' => '0',
  ),
  143 => 
  array (
    'parent_id' => '93',
    'cat_id' => '144',
    'grade' => '0',
  ),
  144 => 
  array (
    'parent_id' => '93',
    'cat_id' => '145',
    'grade' => '0',
  ),
  145 => 
  array (
    'parent_id' => '93',
    'cat_id' => '146',
    'grade' => '0',
  ),
  146 => 
  array (
    'parent_id' => '93',
    'cat_id' => '147',
    'grade' => '0',
  ),
  147 => 
  array (
    'parent_id' => '93',
    'cat_id' => '148',
    'grade' => '0',
  ),
  148 => 
  array (
    'parent_id' => '93',
    'cat_id' => '149',
    'grade' => '0',
  ),
  149 => 
  array (
    'parent_id' => '93',
    'cat_id' => '150',
    'grade' => '0',
  ),
  150 => 
  array (
    'parent_id' => '93',
    'cat_id' => '151',
    'grade' => '0',
  ),
  151 => 
  array (
    'parent_id' => '93',
    'cat_id' => '152',
    'grade' => '0',
  ),
  152 => 
  array (
    'parent_id' => '93',
    'cat_id' => '153',
    'grade' => '0',
  ),
  153 => 
  array (
    'parent_id' => '94',
    'cat_id' => '154',
    'grade' => '0',
  ),
  154 => 
  array (
    'parent_id' => '94',
    'cat_id' => '155',
    'grade' => '0',
  ),
  155 => 
  array (
    'parent_id' => '94',
    'cat_id' => '156',
    'grade' => '0',
  ),
  156 => 
  array (
    'parent_id' => '94',
    'cat_id' => '157',
    'grade' => '0',
  ),
  157 => 
  array (
    'parent_id' => '94',
    'cat_id' => '158',
    'grade' => '0',
  ),
  158 => 
  array (
    'parent_id' => '94',
    'cat_id' => '159',
    'grade' => '0',
  ),
  159 => 
  array (
    'parent_id' => '94',
    'cat_id' => '160',
    'grade' => '0',
  ),
  160 => 
  array (
    'parent_id' => '94',
    'cat_id' => '161',
    'grade' => '0',
  ),
  161 => 
  array (
    'parent_id' => '94',
    'cat_id' => '162',
    'grade' => '0',
  ),
  162 => 
  array (
    'parent_id' => '94',
    'cat_id' => '163',
    'grade' => '0',
  ),
  163 => 
  array (
    'parent_id' => '94',
    'cat_id' => '164',
    'grade' => '0',
  ),
  164 => 
  array (
    'parent_id' => '94',
    'cat_id' => '165',
    'grade' => '0',
  ),
  165 => 
  array (
    'parent_id' => '94',
    'cat_id' => '166',
    'grade' => '0',
  ),
  166 => 
  array (
    'parent_id' => '94',
    'cat_id' => '167',
    'grade' => '0',
  ),
  167 => 
  array (
    'parent_id' => '94',
    'cat_id' => '168',
    'grade' => '0',
  ),
  168 => 
  array (
    'parent_id' => '94',
    'cat_id' => '169',
    'grade' => '0',
  ),
  169 => 
  array (
    'parent_id' => '94',
    'cat_id' => '170',
    'grade' => '0',
  ),
  170 => 
  array (
    'parent_id' => '94',
    'cat_id' => '171',
    'grade' => '0',
  ),
  171 => 
  array (
    'parent_id' => '3',
    'cat_id' => '172',
    'grade' => '0',
  ),
  172 => 
  array (
    'parent_id' => '3',
    'cat_id' => '173',
    'grade' => '0',
  ),
  173 => 
  array (
    'parent_id' => '3',
    'cat_id' => '174',
    'grade' => '0',
  ),
  174 => 
  array (
    'parent_id' => '3',
    'cat_id' => '175',
    'grade' => '0',
  ),
  175 => 
  array (
    'parent_id' => '3',
    'cat_id' => '176',
    'grade' => '0',
  ),
  176 => 
  array (
    'parent_id' => '3',
    'cat_id' => '177',
    'grade' => '0',
  ),
  177 => 
  array (
    'parent_id' => '3',
    'cat_id' => '178',
    'grade' => '0',
  ),
  178 => 
  array (
    'parent_id' => '3',
    'cat_id' => '179',
    'grade' => '0',
  ),
  179 => 
  array (
    'parent_id' => '3',
    'cat_id' => '180',
    'grade' => '0',
  ),
  180 => 
  array (
    'parent_id' => '172',
    'cat_id' => '181',
    'grade' => '0',
  ),
  181 => 
  array (
    'parent_id' => '172',
    'cat_id' => '182',
    'grade' => '0',
  ),
  182 => 
  array (
    'parent_id' => '173',
    'cat_id' => '183',
    'grade' => '0',
  ),
  183 => 
  array (
    'parent_id' => '173',
    'cat_id' => '184',
    'grade' => '0',
  ),
  184 => 
  array (
    'parent_id' => '174',
    'cat_id' => '185',
    'grade' => '0',
  ),
  185 => 
  array (
    'parent_id' => '174',
    'cat_id' => '186',
    'grade' => '0',
  ),
  186 => 
  array (
    'parent_id' => '174',
    'cat_id' => '187',
    'grade' => '0',
  ),
  187 => 
  array (
    'parent_id' => '175',
    'cat_id' => '188',
    'grade' => '0',
  ),
  188 => 
  array (
    'parent_id' => '175',
    'cat_id' => '189',
    'grade' => '0',
  ),
  189 => 
  array (
    'parent_id' => '175',
    'cat_id' => '190',
    'grade' => '0',
  ),
  190 => 
  array (
    'parent_id' => '175',
    'cat_id' => '191',
    'grade' => '0',
  ),
  191 => 
  array (
    'parent_id' => '175',
    'cat_id' => '192',
    'grade' => '0',
  ),
  192 => 
  array (
    'parent_id' => '175',
    'cat_id' => '193',
    'grade' => '0',
  ),
  193 => 
  array (
    'parent_id' => '175',
    'cat_id' => '194',
    'grade' => '0',
  ),
  194 => 
  array (
    'parent_id' => '175',
    'cat_id' => '195',
    'grade' => '0',
  ),
  195 => 
  array (
    'parent_id' => '175',
    'cat_id' => '196',
    'grade' => '0',
  ),
  196 => 
  array (
    'parent_id' => '175',
    'cat_id' => '197',
    'grade' => '0',
  ),
  197 => 
  array (
    'parent_id' => '175',
    'cat_id' => '198',
    'grade' => '0',
  ),
  198 => 
  array (
    'parent_id' => '175',
    'cat_id' => '199',
    'grade' => '0',
  ),
  199 => 
  array (
    'parent_id' => '176',
    'cat_id' => '200',
    'grade' => '0',
  ),
  200 => 
  array (
    'parent_id' => '176',
    'cat_id' => '201',
    'grade' => '0',
  ),
  201 => 
  array (
    'parent_id' => '176',
    'cat_id' => '202',
    'grade' => '0',
  ),
  202 => 
  array (
    'parent_id' => '176',
    'cat_id' => '203',
    'grade' => '0',
  ),
  203 => 
  array (
    'parent_id' => '176',
    'cat_id' => '204',
    'grade' => '0',
  ),
  204 => 
  array (
    'parent_id' => '176',
    'cat_id' => '205',
    'grade' => '0',
  ),
  205 => 
  array (
    'parent_id' => '176',
    'cat_id' => '206',
    'grade' => '0',
  ),
  206 => 
  array (
    'parent_id' => '176',
    'cat_id' => '207',
    'grade' => '0',
  ),
  207 => 
  array (
    'parent_id' => '176',
    'cat_id' => '208',
    'grade' => '0',
  ),
  208 => 
  array (
    'parent_id' => '177',
    'cat_id' => '209',
    'grade' => '0',
  ),
  209 => 
  array (
    'parent_id' => '177',
    'cat_id' => '210',
    'grade' => '0',
  ),
  210 => 
  array (
    'parent_id' => '177',
    'cat_id' => '211',
    'grade' => '0',
  ),
  211 => 
  array (
    'parent_id' => '177',
    'cat_id' => '212',
    'grade' => '0',
  ),
  212 => 
  array (
    'parent_id' => '177',
    'cat_id' => '213',
    'grade' => '0',
  ),
  213 => 
  array (
    'parent_id' => '177',
    'cat_id' => '214',
    'grade' => '0',
  ),
  214 => 
  array (
    'parent_id' => '177',
    'cat_id' => '215',
    'grade' => '0',
  ),
  215 => 
  array (
    'parent_id' => '177',
    'cat_id' => '216',
    'grade' => '0',
  ),
  216 => 
  array (
    'parent_id' => '177',
    'cat_id' => '217',
    'grade' => '0',
  ),
  217 => 
  array (
    'parent_id' => '177',
    'cat_id' => '218',
    'grade' => '0',
  ),
  218 => 
  array (
    'parent_id' => '177',
    'cat_id' => '219',
    'grade' => '0',
  ),
  219 => 
  array (
    'parent_id' => '177',
    'cat_id' => '220',
    'grade' => '0',
  ),
  220 => 
  array (
    'parent_id' => '178',
    'cat_id' => '221',
    'grade' => '0',
  ),
  221 => 
  array (
    'parent_id' => '178',
    'cat_id' => '222',
    'grade' => '0',
  ),
  222 => 
  array (
    'parent_id' => '178',
    'cat_id' => '223',
    'grade' => '0',
  ),
  223 => 
  array (
    'parent_id' => '178',
    'cat_id' => '224',
    'grade' => '0',
  ),
  224 => 
  array (
    'parent_id' => '178',
    'cat_id' => '225',
    'grade' => '0',
  ),
  225 => 
  array (
    'parent_id' => '178',
    'cat_id' => '226',
    'grade' => '0',
  ),
  226 => 
  array (
    'parent_id' => '178',
    'cat_id' => '227',
    'grade' => '0',
  ),
  227 => 
  array (
    'parent_id' => '179',
    'cat_id' => '228',
    'grade' => '0',
  ),
  228 => 
  array (
    'parent_id' => '179',
    'cat_id' => '229',
    'grade' => '0',
  ),
  229 => 
  array (
    'parent_id' => '179',
    'cat_id' => '230',
    'grade' => '0',
  ),
  230 => 
  array (
    'parent_id' => '179',
    'cat_id' => '231',
    'grade' => '0',
  ),
  231 => 
  array (
    'parent_id' => '179',
    'cat_id' => '232',
    'grade' => '0',
  ),
  232 => 
  array (
    'parent_id' => '179',
    'cat_id' => '233',
    'grade' => '0',
  ),
  233 => 
  array (
    'parent_id' => '179',
    'cat_id' => '234',
    'grade' => '0',
  ),
  234 => 
  array (
    'parent_id' => '179',
    'cat_id' => '235',
    'grade' => '0',
  ),
  235 => 
  array (
    'parent_id' => '179',
    'cat_id' => '236',
    'grade' => '0',
  ),
  236 => 
  array (
    'parent_id' => '180',
    'cat_id' => '237',
    'grade' => '0',
  ),
  237 => 
  array (
    'parent_id' => '180',
    'cat_id' => '238',
    'grade' => '0',
  ),
  238 => 
  array (
    'parent_id' => '180',
    'cat_id' => '239',
    'grade' => '0',
  ),
  239 => 
  array (
    'parent_id' => '180',
    'cat_id' => '240',
    'grade' => '0',
  ),
  240 => 
  array (
    'parent_id' => '180',
    'cat_id' => '241',
    'grade' => '0',
  ),
  241 => 
  array (
    'parent_id' => '180',
    'cat_id' => '242',
    'grade' => '0',
  ),
  242 => 
  array (
    'parent_id' => '180',
    'cat_id' => '243',
    'grade' => '0',
  ),
  243 => 
  array (
    'parent_id' => '4',
    'cat_id' => '244',
    'grade' => '0',
  ),
  244 => 
  array (
    'parent_id' => '4',
    'cat_id' => '245',
    'grade' => '0',
  ),
  245 => 
  array (
    'parent_id' => '4',
    'cat_id' => '246',
    'grade' => '0',
  ),
  246 => 
  array (
    'parent_id' => '4',
    'cat_id' => '247',
    'grade' => '0',
  ),
  247 => 
  array (
    'parent_id' => '4',
    'cat_id' => '248',
    'grade' => '0',
  ),
  248 => 
  array (
    'parent_id' => '4',
    'cat_id' => '249',
    'grade' => '0',
  ),
  249 => 
  array (
    'parent_id' => '4',
    'cat_id' => '250',
    'grade' => '0',
  ),
  250 => 
  array (
    'parent_id' => '244',
    'cat_id' => '251',
    'grade' => '0',
  ),
  251 => 
  array (
    'parent_id' => '244',
    'cat_id' => '252',
    'grade' => '0',
  ),
  252 => 
  array (
    'parent_id' => '244',
    'cat_id' => '253',
    'grade' => '0',
  ),
  253 => 
  array (
    'parent_id' => '244',
    'cat_id' => '254',
    'grade' => '0',
  ),
  254 => 
  array (
    'parent_id' => '244',
    'cat_id' => '255',
    'grade' => '0',
  ),
  255 => 
  array (
    'parent_id' => '244',
    'cat_id' => '256',
    'grade' => '0',
  ),
  256 => 
  array (
    'parent_id' => '244',
    'cat_id' => '257',
    'grade' => '0',
  ),
  257 => 
  array (
    'parent_id' => '244',
    'cat_id' => '258',
    'grade' => '0',
  ),
  258 => 
  array (
    'parent_id' => '245',
    'cat_id' => '259',
    'grade' => '0',
  ),
  259 => 
  array (
    'parent_id' => '245',
    'cat_id' => '260',
    'grade' => '0',
  ),
  260 => 
  array (
    'parent_id' => '245',
    'cat_id' => '261',
    'grade' => '0',
  ),
  261 => 
  array (
    'parent_id' => '245',
    'cat_id' => '262',
    'grade' => '0',
  ),
  262 => 
  array (
    'parent_id' => '245',
    'cat_id' => '263',
    'grade' => '0',
  ),
  263 => 
  array (
    'parent_id' => '245',
    'cat_id' => '264',
    'grade' => '0',
  ),
  264 => 
  array (
    'parent_id' => '245',
    'cat_id' => '265',
    'grade' => '0',
  ),
  265 => 
  array (
    'parent_id' => '245',
    'cat_id' => '266',
    'grade' => '0',
  ),
  266 => 
  array (
    'parent_id' => '245',
    'cat_id' => '267',
    'grade' => '0',
  ),
  267 => 
  array (
    'parent_id' => '245',
    'cat_id' => '268',
    'grade' => '0',
  ),
  268 => 
  array (
    'parent_id' => '245',
    'cat_id' => '269',
    'grade' => '0',
  ),
  269 => 
  array (
    'parent_id' => '245',
    'cat_id' => '270',
    'grade' => '0',
  ),
  270 => 
  array (
    'parent_id' => '245',
    'cat_id' => '271',
    'grade' => '0',
  ),
  271 => 
  array (
    'parent_id' => '245',
    'cat_id' => '272',
    'grade' => '0',
  ),
  272 => 
  array (
    'parent_id' => '246',
    'cat_id' => '273',
    'grade' => '0',
  ),
  273 => 
  array (
    'parent_id' => '246',
    'cat_id' => '274',
    'grade' => '0',
  ),
  274 => 
  array (
    'parent_id' => '246',
    'cat_id' => '275',
    'grade' => '0',
  ),
  275 => 
  array (
    'parent_id' => '246',
    'cat_id' => '276',
    'grade' => '0',
  ),
  276 => 
  array (
    'parent_id' => '246',
    'cat_id' => '277',
    'grade' => '0',
  ),
  277 => 
  array (
    'parent_id' => '246',
    'cat_id' => '278',
    'grade' => '0',
  ),
  278 => 
  array (
    'parent_id' => '246',
    'cat_id' => '279',
    'grade' => '0',
  ),
  279 => 
  array (
    'parent_id' => '246',
    'cat_id' => '280',
    'grade' => '0',
  ),
  280 => 
  array (
    'parent_id' => '246',
    'cat_id' => '281',
    'grade' => '0',
  ),
  281 => 
  array (
    'parent_id' => '246',
    'cat_id' => '282',
    'grade' => '0',
  ),
  282 => 
  array (
    'parent_id' => '246',
    'cat_id' => '283',
    'grade' => '0',
  ),
  283 => 
  array (
    'parent_id' => '246',
    'cat_id' => '284',
    'grade' => '0',
  ),
  284 => 
  array (
    'parent_id' => '246',
    'cat_id' => '285',
    'grade' => '0',
  ),
  285 => 
  array (
    'parent_id' => '246',
    'cat_id' => '286',
    'grade' => '0',
  ),
  286 => 
  array (
    'parent_id' => '246',
    'cat_id' => '287',
    'grade' => '0',
  ),
  287 => 
  array (
    'parent_id' => '247',
    'cat_id' => '288',
    'grade' => '0',
  ),
  288 => 
  array (
    'parent_id' => '247',
    'cat_id' => '289',
    'grade' => '0',
  ),
  289 => 
  array (
    'parent_id' => '247',
    'cat_id' => '290',
    'grade' => '0',
  ),
  290 => 
  array (
    'parent_id' => '247',
    'cat_id' => '291',
    'grade' => '0',
  ),
  291 => 
  array (
    'parent_id' => '247',
    'cat_id' => '292',
    'grade' => '0',
  ),
  292 => 
  array (
    'parent_id' => '247',
    'cat_id' => '293',
    'grade' => '0',
  ),
  293 => 
  array (
    'parent_id' => '247',
    'cat_id' => '294',
    'grade' => '0',
  ),
  294 => 
  array (
    'parent_id' => '248',
    'cat_id' => '295',
    'grade' => '0',
  ),
  295 => 
  array (
    'parent_id' => '248',
    'cat_id' => '296',
    'grade' => '0',
  ),
  296 => 
  array (
    'parent_id' => '248',
    'cat_id' => '297',
    'grade' => '0',
  ),
  297 => 
  array (
    'parent_id' => '248',
    'cat_id' => '298',
    'grade' => '0',
  ),
  298 => 
  array (
    'parent_id' => '248',
    'cat_id' => '299',
    'grade' => '0',
  ),
  299 => 
  array (
    'parent_id' => '248',
    'cat_id' => '300',
    'grade' => '0',
  ),
  300 => 
  array (
    'parent_id' => '248',
    'cat_id' => '301',
    'grade' => '0',
  ),
  301 => 
  array (
    'parent_id' => '248',
    'cat_id' => '302',
    'grade' => '0',
  ),
  302 => 
  array (
    'parent_id' => '248',
    'cat_id' => '303',
    'grade' => '0',
  ),
  303 => 
  array (
    'parent_id' => '248',
    'cat_id' => '304',
    'grade' => '0',
  ),
  304 => 
  array (
    'parent_id' => '248',
    'cat_id' => '305',
    'grade' => '0',
  ),
  305 => 
  array (
    'parent_id' => '248',
    'cat_id' => '306',
    'grade' => '0',
  ),
  306 => 
  array (
    'parent_id' => '249',
    'cat_id' => '307',
    'grade' => '0',
  ),
  307 => 
  array (
    'parent_id' => '249',
    'cat_id' => '308',
    'grade' => '0',
  ),
  308 => 
  array (
    'parent_id' => '249',
    'cat_id' => '309',
    'grade' => '0',
  ),
  309 => 
  array (
    'parent_id' => '249',
    'cat_id' => '310',
    'grade' => '0',
  ),
  310 => 
  array (
    'parent_id' => '249',
    'cat_id' => '311',
    'grade' => '0',
  ),
  311 => 
  array (
    'parent_id' => '249',
    'cat_id' => '312',
    'grade' => '0',
  ),
  312 => 
  array (
    'parent_id' => '249',
    'cat_id' => '313',
    'grade' => '0',
  ),
  313 => 
  array (
    'parent_id' => '249',
    'cat_id' => '314',
    'grade' => '0',
  ),
  314 => 
  array (
    'parent_id' => '249',
    'cat_id' => '315',
    'grade' => '0',
  ),
  315 => 
  array (
    'parent_id' => '249',
    'cat_id' => '316',
    'grade' => '0',
  ),
  316 => 
  array (
    'parent_id' => '249',
    'cat_id' => '317',
    'grade' => '0',
  ),
  317 => 
  array (
    'parent_id' => '249',
    'cat_id' => '318',
    'grade' => '0',
  ),
  318 => 
  array (
    'parent_id' => '249',
    'cat_id' => '319',
    'grade' => '0',
  ),
  319 => 
  array (
    'parent_id' => '249',
    'cat_id' => '320',
    'grade' => '0',
  ),
  320 => 
  array (
    'parent_id' => '249',
    'cat_id' => '321',
    'grade' => '0',
  ),
  321 => 
  array (
    'parent_id' => '249',
    'cat_id' => '322',
    'grade' => '0',
  ),
  322 => 
  array (
    'parent_id' => '249',
    'cat_id' => '323',
    'grade' => '0',
  ),
  323 => 
  array (
    'parent_id' => '249',
    'cat_id' => '324',
    'grade' => '0',
  ),
  324 => 
  array (
    'parent_id' => '250',
    'cat_id' => '325',
    'grade' => '0',
  ),
  325 => 
  array (
    'parent_id' => '250',
    'cat_id' => '326',
    'grade' => '0',
  ),
  326 => 
  array (
    'parent_id' => '250',
    'cat_id' => '327',
    'grade' => '0',
  ),
  327 => 
  array (
    'parent_id' => '5',
    'cat_id' => '328',
    'grade' => '0',
  ),
  328 => 
  array (
    'parent_id' => '5',
    'cat_id' => '329',
    'grade' => '0',
  ),
  329 => 
  array (
    'parent_id' => '5',
    'cat_id' => '330',
    'grade' => '0',
  ),
  330 => 
  array (
    'parent_id' => '5',
    'cat_id' => '331',
    'grade' => '0',
  ),
  331 => 
  array (
    'parent_id' => '5',
    'cat_id' => '332',
    'grade' => '0',
  ),
  332 => 
  array (
    'parent_id' => '5',
    'cat_id' => '333',
    'grade' => '0',
  ),
  333 => 
  array (
    'parent_id' => '5',
    'cat_id' => '334',
    'grade' => '0',
  ),
  334 => 
  array (
    'parent_id' => '328',
    'cat_id' => '335',
    'grade' => '0',
  ),
  335 => 
  array (
    'parent_id' => '328',
    'cat_id' => '336',
    'grade' => '0',
  ),
  336 => 
  array (
    'parent_id' => '328',
    'cat_id' => '337',
    'grade' => '0',
  ),
  337 => 
  array (
    'parent_id' => '328',
    'cat_id' => '338',
    'grade' => '0',
  ),
  338 => 
  array (
    'parent_id' => '328',
    'cat_id' => '339',
    'grade' => '0',
  ),
  339 => 
  array (
    'parent_id' => '328',
    'cat_id' => '340',
    'grade' => '0',
  ),
  340 => 
  array (
    'parent_id' => '329',
    'cat_id' => '341',
    'grade' => '0',
  ),
  341 => 
  array (
    'parent_id' => '329',
    'cat_id' => '342',
    'grade' => '0',
  ),
  342 => 
  array (
    'parent_id' => '329',
    'cat_id' => '343',
    'grade' => '0',
  ),
  343 => 
  array (
    'parent_id' => '329',
    'cat_id' => '344',
    'grade' => '0',
  ),
  344 => 
  array (
    'parent_id' => '329',
    'cat_id' => '345',
    'grade' => '0',
  ),
  345 => 
  array (
    'parent_id' => '329',
    'cat_id' => '346',
    'grade' => '0',
  ),
  346 => 
  array (
    'parent_id' => '329',
    'cat_id' => '347',
    'grade' => '0',
  ),
  347 => 
  array (
    'parent_id' => '329',
    'cat_id' => '348',
    'grade' => '0',
  ),
  348 => 
  array (
    'parent_id' => '329',
    'cat_id' => '349',
    'grade' => '0',
  ),
  349 => 
  array (
    'parent_id' => '329',
    'cat_id' => '350',
    'grade' => '0',
  ),
  350 => 
  array (
    'parent_id' => '329',
    'cat_id' => '351',
    'grade' => '0',
  ),
  351 => 
  array (
    'parent_id' => '329',
    'cat_id' => '352',
    'grade' => '0',
  ),
  352 => 
  array (
    'parent_id' => '330',
    'cat_id' => '353',
    'grade' => '0',
  ),
  353 => 
  array (
    'parent_id' => '330',
    'cat_id' => '354',
    'grade' => '0',
  ),
  354 => 
  array (
    'parent_id' => '330',
    'cat_id' => '355',
    'grade' => '0',
  ),
  355 => 
  array (
    'parent_id' => '330',
    'cat_id' => '356',
    'grade' => '0',
  ),
  356 => 
  array (
    'parent_id' => '330',
    'cat_id' => '357',
    'grade' => '0',
  ),
  357 => 
  array (
    'parent_id' => '330',
    'cat_id' => '358',
    'grade' => '0',
  ),
  358 => 
  array (
    'parent_id' => '330',
    'cat_id' => '359',
    'grade' => '0',
  ),
  359 => 
  array (
    'parent_id' => '330',
    'cat_id' => '360',
    'grade' => '0',
  ),
  360 => 
  array (
    'parent_id' => '330',
    'cat_id' => '361',
    'grade' => '0',
  ),
  361 => 
  array (
    'parent_id' => '330',
    'cat_id' => '362',
    'grade' => '0',
  ),
  362 => 
  array (
    'parent_id' => '330',
    'cat_id' => '363',
    'grade' => '0',
  ),
  363 => 
  array (
    'parent_id' => '330',
    'cat_id' => '364',
    'grade' => '0',
  ),
  364 => 
  array (
    'parent_id' => '330',
    'cat_id' => '365',
    'grade' => '0',
  ),
  365 => 
  array (
    'parent_id' => '331',
    'cat_id' => '366',
    'grade' => '0',
  ),
  366 => 
  array (
    'parent_id' => '331',
    'cat_id' => '367',
    'grade' => '0',
  ),
  367 => 
  array (
    'parent_id' => '331',
    'cat_id' => '368',
    'grade' => '0',
  ),
  368 => 
  array (
    'parent_id' => '331',
    'cat_id' => '369',
    'grade' => '0',
  ),
  369 => 
  array (
    'parent_id' => '331',
    'cat_id' => '370',
    'grade' => '0',
  ),
  370 => 
  array (
    'parent_id' => '331',
    'cat_id' => '371',
    'grade' => '0',
  ),
  371 => 
  array (
    'parent_id' => '331',
    'cat_id' => '372',
    'grade' => '0',
  ),
  372 => 
  array (
    'parent_id' => '331',
    'cat_id' => '373',
    'grade' => '0',
  ),
  373 => 
  array (
    'parent_id' => '331',
    'cat_id' => '374',
    'grade' => '0',
  ),
  374 => 
  array (
    'parent_id' => '331',
    'cat_id' => '375',
    'grade' => '0',
  ),
  375 => 
  array (
    'parent_id' => '331',
    'cat_id' => '376',
    'grade' => '0',
  ),
  376 => 
  array (
    'parent_id' => '331',
    'cat_id' => '377',
    'grade' => '0',
  ),
  377 => 
  array (
    'parent_id' => '331',
    'cat_id' => '378',
    'grade' => '0',
  ),
  378 => 
  array (
    'parent_id' => '331',
    'cat_id' => '379',
    'grade' => '0',
  ),
  379 => 
  array (
    'parent_id' => '331',
    'cat_id' => '380',
    'grade' => '0',
  ),
  380 => 
  array (
    'parent_id' => '331',
    'cat_id' => '381',
    'grade' => '0',
  ),
  381 => 
  array (
    'parent_id' => '331',
    'cat_id' => '382',
    'grade' => '0',
  ),
  382 => 
  array (
    'parent_id' => '332',
    'cat_id' => '383',
    'grade' => '0',
  ),
  383 => 
  array (
    'parent_id' => '332',
    'cat_id' => '384',
    'grade' => '0',
  ),
  384 => 
  array (
    'parent_id' => '332',
    'cat_id' => '385',
    'grade' => '0',
  ),
  385 => 
  array (
    'parent_id' => '332',
    'cat_id' => '386',
    'grade' => '0',
  ),
  386 => 
  array (
    'parent_id' => '332',
    'cat_id' => '387',
    'grade' => '0',
  ),
  387 => 
  array (
    'parent_id' => '332',
    'cat_id' => '388',
    'grade' => '0',
  ),
  388 => 
  array (
    'parent_id' => '332',
    'cat_id' => '389',
    'grade' => '0',
  ),
  389 => 
  array (
    'parent_id' => '332',
    'cat_id' => '390',
    'grade' => '0',
  ),
  390 => 
  array (
    'parent_id' => '332',
    'cat_id' => '391',
    'grade' => '0',
  ),
  391 => 
  array (
    'parent_id' => '332',
    'cat_id' => '392',
    'grade' => '0',
  ),
  392 => 
  array (
    'parent_id' => '332',
    'cat_id' => '393',
    'grade' => '0',
  ),
  393 => 
  array (
    'parent_id' => '333',
    'cat_id' => '394',
    'grade' => '0',
  ),
  394 => 
  array (
    'parent_id' => '333',
    'cat_id' => '395',
    'grade' => '0',
  ),
  395 => 
  array (
    'parent_id' => '333',
    'cat_id' => '396',
    'grade' => '0',
  ),
  396 => 
  array (
    'parent_id' => '333',
    'cat_id' => '397',
    'grade' => '0',
  ),
  397 => 
  array (
    'parent_id' => '333',
    'cat_id' => '398',
    'grade' => '0',
  ),
  398 => 
  array (
    'parent_id' => '333',
    'cat_id' => '399',
    'grade' => '0',
  ),
  399 => 
  array (
    'parent_id' => '334',
    'cat_id' => '400',
    'grade' => '0',
  ),
  400 => 
  array (
    'parent_id' => '334',
    'cat_id' => '401',
    'grade' => '0',
  ),
  401 => 
  array (
    'parent_id' => '334',
    'cat_id' => '402',
    'grade' => '0',
  ),
  402 => 
  array (
    'parent_id' => '334',
    'cat_id' => '403',
    'grade' => '0',
  ),
  403 => 
  array (
    'parent_id' => '334',
    'cat_id' => '404',
    'grade' => '0',
  ),
  404 => 
  array (
    'parent_id' => '334',
    'cat_id' => '405',
    'grade' => '0',
  ),
  405 => 
  array (
    'parent_id' => '334',
    'cat_id' => '406',
    'grade' => '0',
  ),
  406 => 
  array (
    'parent_id' => '334',
    'cat_id' => '407',
    'grade' => '0',
  ),
  407 => 
  array (
    'parent_id' => '334',
    'cat_id' => '408',
    'grade' => '0',
  ),
  408 => 
  array (
    'parent_id' => '334',
    'cat_id' => '409',
    'grade' => '0',
  ),
  409 => 
  array (
    'parent_id' => '334',
    'cat_id' => '410',
    'grade' => '0',
  ),
  410 => 
  array (
    'parent_id' => '334',
    'cat_id' => '411',
    'grade' => '0',
  ),
  411 => 
  array (
    'parent_id' => '334',
    'cat_id' => '412',
    'grade' => '0',
  ),
  412 => 
  array (
    'parent_id' => '334',
    'cat_id' => '413',
    'grade' => '0',
  ),
  413 => 
  array (
    'parent_id' => '334',
    'cat_id' => '414',
    'grade' => '0',
  ),
  414 => 
  array (
    'parent_id' => '7',
    'cat_id' => '415',
    'grade' => '0',
  ),
  415 => 
  array (
    'parent_id' => '7',
    'cat_id' => '416',
    'grade' => '0',
  ),
  416 => 
  array (
    'parent_id' => '7',
    'cat_id' => '417',
    'grade' => '0',
  ),
  417 => 
  array (
    'parent_id' => '7',
    'cat_id' => '418',
    'grade' => '0',
  ),
  418 => 
  array (
    'parent_id' => '7',
    'cat_id' => '419',
    'grade' => '0',
  ),
  419 => 
  array (
    'parent_id' => '7',
    'cat_id' => '420',
    'grade' => '0',
  ),
  420 => 
  array (
    'parent_id' => '415',
    'cat_id' => '421',
    'grade' => '0',
  ),
  421 => 
  array (
    'parent_id' => '415',
    'cat_id' => '422',
    'grade' => '0',
  ),
  422 => 
  array (
    'parent_id' => '415',
    'cat_id' => '423',
    'grade' => '0',
  ),
  423 => 
  array (
    'parent_id' => '415',
    'cat_id' => '424',
    'grade' => '0',
  ),
  424 => 
  array (
    'parent_id' => '415',
    'cat_id' => '425',
    'grade' => '0',
  ),
  425 => 
  array (
    'parent_id' => '416',
    'cat_id' => '426',
    'grade' => '0',
  ),
  426 => 
  array (
    'parent_id' => '416',
    'cat_id' => '427',
    'grade' => '0',
  ),
  427 => 
  array (
    'parent_id' => '416',
    'cat_id' => '428',
    'grade' => '0',
  ),
  428 => 
  array (
    'parent_id' => '416',
    'cat_id' => '429',
    'grade' => '0',
  ),
  429 => 
  array (
    'parent_id' => '416',
    'cat_id' => '430',
    'grade' => '0',
  ),
  430 => 
  array (
    'parent_id' => '416',
    'cat_id' => '431',
    'grade' => '0',
  ),
  431 => 
  array (
    'parent_id' => '417',
    'cat_id' => '432',
    'grade' => '0',
  ),
  432 => 
  array (
    'parent_id' => '417',
    'cat_id' => '433',
    'grade' => '0',
  ),
  433 => 
  array (
    'parent_id' => '417',
    'cat_id' => '434',
    'grade' => '0',
  ),
  434 => 
  array (
    'parent_id' => '417',
    'cat_id' => '435',
    'grade' => '0',
  ),
  435 => 
  array (
    'parent_id' => '417',
    'cat_id' => '436',
    'grade' => '0',
  ),
  436 => 
  array (
    'parent_id' => '417',
    'cat_id' => '437',
    'grade' => '0',
  ),
  437 => 
  array (
    'parent_id' => '417',
    'cat_id' => '438',
    'grade' => '0',
  ),
  438 => 
  array (
    'parent_id' => '418',
    'cat_id' => '439',
    'grade' => '0',
  ),
  439 => 
  array (
    'parent_id' => '418',
    'cat_id' => '440',
    'grade' => '0',
  ),
  440 => 
  array (
    'parent_id' => '418',
    'cat_id' => '441',
    'grade' => '0',
  ),
  441 => 
  array (
    'parent_id' => '418',
    'cat_id' => '442',
    'grade' => '0',
  ),
  442 => 
  array (
    'parent_id' => '419',
    'cat_id' => '443',
    'grade' => '0',
  ),
  443 => 
  array (
    'parent_id' => '419',
    'cat_id' => '444',
    'grade' => '0',
  ),
  444 => 
  array (
    'parent_id' => '419',
    'cat_id' => '445',
    'grade' => '0',
  ),
  445 => 
  array (
    'parent_id' => '419',
    'cat_id' => '446',
    'grade' => '0',
  ),
  446 => 
  array (
    'parent_id' => '420',
    'cat_id' => '447',
    'grade' => '0',
  ),
  447 => 
  array (
    'parent_id' => '420',
    'cat_id' => '448',
    'grade' => '0',
  ),
  448 => 
  array (
    'parent_id' => '420',
    'cat_id' => '449',
    'grade' => '0',
  ),
  449 => 
  array (
    'parent_id' => '420',
    'cat_id' => '450',
    'grade' => '0',
  ),
  450 => 
  array (
    'parent_id' => '420',
    'cat_id' => '451',
    'grade' => '0',
  ),
  451 => 
  array (
    'parent_id' => '420',
    'cat_id' => '452',
    'grade' => '0',
  ),
  452 => 
  array (
    'parent_id' => '420',
    'cat_id' => '453',
    'grade' => '0',
  ),
  453 => 
  array (
    'parent_id' => '420',
    'cat_id' => '454',
    'grade' => '0',
  ),
  454 => 
  array (
    'parent_id' => '8',
    'cat_id' => '455',
    'grade' => '0',
  ),
  455 => 
  array (
    'parent_id' => '8',
    'cat_id' => '456',
    'grade' => '0',
  ),
  456 => 
  array (
    'parent_id' => '8',
    'cat_id' => '457',
    'grade' => '0',
  ),
  457 => 
  array (
    'parent_id' => '8',
    'cat_id' => '458',
    'grade' => '0',
  ),
  458 => 
  array (
    'parent_id' => '8',
    'cat_id' => '459',
    'grade' => '0',
  ),
  459 => 
  array (
    'parent_id' => '8',
    'cat_id' => '460',
    'grade' => '0',
  ),
  460 => 
  array (
    'parent_id' => '8',
    'cat_id' => '461',
    'grade' => '0',
  ),
  461 => 
  array (
    'parent_id' => '8',
    'cat_id' => '462',
    'grade' => '0',
  ),
  462 => 
  array (
    'parent_id' => '455',
    'cat_id' => '463',
    'grade' => '0',
  ),
  463 => 
  array (
    'parent_id' => '455',
    'cat_id' => '464',
    'grade' => '0',
  ),
  464 => 
  array (
    'parent_id' => '455',
    'cat_id' => '465',
    'grade' => '0',
  ),
  465 => 
  array (
    'parent_id' => '455',
    'cat_id' => '466',
    'grade' => '0',
  ),
  466 => 
  array (
    'parent_id' => '455',
    'cat_id' => '467',
    'grade' => '0',
  ),
  467 => 
  array (
    'parent_id' => '455',
    'cat_id' => '468',
    'grade' => '0',
  ),
  468 => 
  array (
    'parent_id' => '455',
    'cat_id' => '469',
    'grade' => '0',
  ),
  469 => 
  array (
    'parent_id' => '455',
    'cat_id' => '470',
    'grade' => '0',
  ),
  470 => 
  array (
    'parent_id' => '455',
    'cat_id' => '471',
    'grade' => '0',
  ),
  471 => 
  array (
    'parent_id' => '455',
    'cat_id' => '472',
    'grade' => '0',
  ),
  472 => 
  array (
    'parent_id' => '455',
    'cat_id' => '473',
    'grade' => '0',
  ),
  473 => 
  array (
    'parent_id' => '455',
    'cat_id' => '474',
    'grade' => '0',
  ),
  474 => 
  array (
    'parent_id' => '455',
    'cat_id' => '475',
    'grade' => '0',
  ),
  475 => 
  array (
    'parent_id' => '455',
    'cat_id' => '476',
    'grade' => '0',
  ),
  476 => 
  array (
    'parent_id' => '455',
    'cat_id' => '477',
    'grade' => '0',
  ),
  477 => 
  array (
    'parent_id' => '455',
    'cat_id' => '478',
    'grade' => '0',
  ),
  478 => 
  array (
    'parent_id' => '455',
    'cat_id' => '479',
    'grade' => '0',
  ),
  479 => 
  array (
    'parent_id' => '455',
    'cat_id' => '480',
    'grade' => '0',
  ),
  480 => 
  array (
    'parent_id' => '455',
    'cat_id' => '481',
    'grade' => '0',
  ),
  481 => 
  array (
    'parent_id' => '456',
    'cat_id' => '482',
    'grade' => '0',
  ),
  482 => 
  array (
    'parent_id' => '456',
    'cat_id' => '483',
    'grade' => '0',
  ),
  483 => 
  array (
    'parent_id' => '456',
    'cat_id' => '484',
    'grade' => '0',
  ),
  484 => 
  array (
    'parent_id' => '456',
    'cat_id' => '485',
    'grade' => '0',
  ),
  485 => 
  array (
    'parent_id' => '456',
    'cat_id' => '486',
    'grade' => '0',
  ),
  486 => 
  array (
    'parent_id' => '456',
    'cat_id' => '487',
    'grade' => '0',
  ),
  487 => 
  array (
    'parent_id' => '456',
    'cat_id' => '488',
    'grade' => '0',
  ),
  488 => 
  array (
    'parent_id' => '456',
    'cat_id' => '489',
    'grade' => '0',
  ),
  489 => 
  array (
    'parent_id' => '456',
    'cat_id' => '490',
    'grade' => '0',
  ),
  490 => 
  array (
    'parent_id' => '456',
    'cat_id' => '491',
    'grade' => '0',
  ),
  491 => 
  array (
    'parent_id' => '456',
    'cat_id' => '492',
    'grade' => '0',
  ),
  492 => 
  array (
    'parent_id' => '456',
    'cat_id' => '493',
    'grade' => '0',
  ),
  493 => 
  array (
    'parent_id' => '456',
    'cat_id' => '494',
    'grade' => '0',
  ),
  494 => 
  array (
    'parent_id' => '457',
    'cat_id' => '495',
    'grade' => '0',
  ),
  495 => 
  array (
    'parent_id' => '457',
    'cat_id' => '496',
    'grade' => '0',
  ),
  496 => 
  array (
    'parent_id' => '457',
    'cat_id' => '497',
    'grade' => '0',
  ),
  497 => 
  array (
    'parent_id' => '457',
    'cat_id' => '498',
    'grade' => '0',
  ),
  498 => 
  array (
    'parent_id' => '457',
    'cat_id' => '499',
    'grade' => '0',
  ),
  499 => 
  array (
    'parent_id' => '457',
    'cat_id' => '500',
    'grade' => '0',
  ),
  500 => 
  array (
    'parent_id' => '457',
    'cat_id' => '501',
    'grade' => '0',
  ),
  501 => 
  array (
    'parent_id' => '457',
    'cat_id' => '502',
    'grade' => '0',
  ),
  502 => 
  array (
    'parent_id' => '458',
    'cat_id' => '503',
    'grade' => '0',
  ),
  503 => 
  array (
    'parent_id' => '458',
    'cat_id' => '504',
    'grade' => '0',
  ),
  504 => 
  array (
    'parent_id' => '458',
    'cat_id' => '505',
    'grade' => '0',
  ),
  505 => 
  array (
    'parent_id' => '458',
    'cat_id' => '506',
    'grade' => '0',
  ),
  506 => 
  array (
    'parent_id' => '458',
    'cat_id' => '507',
    'grade' => '0',
  ),
  507 => 
  array (
    'parent_id' => '458',
    'cat_id' => '508',
    'grade' => '0',
  ),
  508 => 
  array (
    'parent_id' => '459',
    'cat_id' => '509',
    'grade' => '0',
  ),
  509 => 
  array (
    'parent_id' => '459',
    'cat_id' => '510',
    'grade' => '0',
  ),
  510 => 
  array (
    'parent_id' => '459',
    'cat_id' => '511',
    'grade' => '0',
  ),
  511 => 
  array (
    'parent_id' => '459',
    'cat_id' => '512',
    'grade' => '0',
  ),
  512 => 
  array (
    'parent_id' => '459',
    'cat_id' => '513',
    'grade' => '0',
  ),
  513 => 
  array (
    'parent_id' => '459',
    'cat_id' => '514',
    'grade' => '0',
  ),
  514 => 
  array (
    'parent_id' => '459',
    'cat_id' => '515',
    'grade' => '0',
  ),
  515 => 
  array (
    'parent_id' => '459',
    'cat_id' => '516',
    'grade' => '0',
  ),
  516 => 
  array (
    'parent_id' => '459',
    'cat_id' => '517',
    'grade' => '0',
  ),
  517 => 
  array (
    'parent_id' => '459',
    'cat_id' => '518',
    'grade' => '0',
  ),
  518 => 
  array (
    'parent_id' => '460',
    'cat_id' => '519',
    'grade' => '0',
  ),
  519 => 
  array (
    'parent_id' => '460',
    'cat_id' => '520',
    'grade' => '0',
  ),
  520 => 
  array (
    'parent_id' => '460',
    'cat_id' => '521',
    'grade' => '0',
  ),
  521 => 
  array (
    'parent_id' => '460',
    'cat_id' => '522',
    'grade' => '0',
  ),
  522 => 
  array (
    'parent_id' => '460',
    'cat_id' => '523',
    'grade' => '0',
  ),
  523 => 
  array (
    'parent_id' => '460',
    'cat_id' => '524',
    'grade' => '0',
  ),
  524 => 
  array (
    'parent_id' => '460',
    'cat_id' => '525',
    'grade' => '0',
  ),
  525 => 
  array (
    'parent_id' => '461',
    'cat_id' => '526',
    'grade' => '0',
  ),
  526 => 
  array (
    'parent_id' => '461',
    'cat_id' => '527',
    'grade' => '0',
  ),
  527 => 
  array (
    'parent_id' => '461',
    'cat_id' => '528',
    'grade' => '0',
  ),
  528 => 
  array (
    'parent_id' => '461',
    'cat_id' => '529',
    'grade' => '0',
  ),
  529 => 
  array (
    'parent_id' => '462',
    'cat_id' => '530',
    'grade' => '0',
  ),
  530 => 
  array (
    'parent_id' => '462',
    'cat_id' => '531',
    'grade' => '0',
  ),
  531 => 
  array (
    'parent_id' => '462',
    'cat_id' => '532',
    'grade' => '0',
  ),
  532 => 
  array (
    'parent_id' => '462',
    'cat_id' => '533',
    'grade' => '0',
  ),
  533 => 
  array (
    'parent_id' => '462',
    'cat_id' => '534',
    'grade' => '0',
  ),
  534 => 
  array (
    'parent_id' => '462',
    'cat_id' => '535',
    'grade' => '0',
  ),
  535 => 
  array (
    'parent_id' => '462',
    'cat_id' => '536',
    'grade' => '0',
  ),
  536 => 
  array (
    'parent_id' => '462',
    'cat_id' => '537',
    'grade' => '0',
  ),
  537 => 
  array (
    'parent_id' => '462',
    'cat_id' => '538',
    'grade' => '0',
  ),
  538 => 
  array (
    'parent_id' => '462',
    'cat_id' => '539',
    'grade' => '0',
  ),
  539 => 
  array (
    'parent_id' => '462',
    'cat_id' => '540',
    'grade' => '0',
  ),
  540 => 
  array (
    'parent_id' => '462',
    'cat_id' => '541',
    'grade' => '0',
  ),
  541 => 
  array (
    'parent_id' => '9',
    'cat_id' => '542',
    'grade' => '0',
  ),
  542 => 
  array (
    'parent_id' => '9',
    'cat_id' => '543',
    'grade' => '0',
  ),
  543 => 
  array (
    'parent_id' => '9',
    'cat_id' => '544',
    'grade' => '0',
  ),
  544 => 
  array (
    'parent_id' => '9',
    'cat_id' => '545',
    'grade' => '0',
  ),
  545 => 
  array (
    'parent_id' => '9',
    'cat_id' => '546',
    'grade' => '0',
  ),
  546 => 
  array (
    'parent_id' => '9',
    'cat_id' => '547',
    'grade' => '0',
  ),
  547 => 
  array (
    'parent_id' => '542',
    'cat_id' => '548',
    'grade' => '0',
  ),
  548 => 
  array (
    'parent_id' => '542',
    'cat_id' => '549',
    'grade' => '0',
  ),
  549 => 
  array (
    'parent_id' => '542',
    'cat_id' => '550',
    'grade' => '0',
  ),
  550 => 
  array (
    'parent_id' => '542',
    'cat_id' => '551',
    'grade' => '0',
  ),
  551 => 
  array (
    'parent_id' => '542',
    'cat_id' => '552',
    'grade' => '0',
  ),
  552 => 
  array (
    'parent_id' => '542',
    'cat_id' => '553',
    'grade' => '0',
  ),
  553 => 
  array (
    'parent_id' => '542',
    'cat_id' => '554',
    'grade' => '0',
  ),
  554 => 
  array (
    'parent_id' => '542',
    'cat_id' => '555',
    'grade' => '0',
  ),
  555 => 
  array (
    'parent_id' => '542',
    'cat_id' => '556',
    'grade' => '0',
  ),
  556 => 
  array (
    'parent_id' => '542',
    'cat_id' => '557',
    'grade' => '0',
  ),
  557 => 
  array (
    'parent_id' => '542',
    'cat_id' => '558',
    'grade' => '0',
  ),
  558 => 
  array (
    'parent_id' => '543',
    'cat_id' => '559',
    'grade' => '0',
  ),
  559 => 
  array (
    'parent_id' => '543',
    'cat_id' => '560',
    'grade' => '0',
  ),
  560 => 
  array (
    'parent_id' => '543',
    'cat_id' => '561',
    'grade' => '0',
  ),
  561 => 
  array (
    'parent_id' => '543',
    'cat_id' => '562',
    'grade' => '0',
  ),
  562 => 
  array (
    'parent_id' => '543',
    'cat_id' => '563',
    'grade' => '0',
  ),
  563 => 
  array (
    'parent_id' => '543',
    'cat_id' => '564',
    'grade' => '0',
  ),
  564 => 
  array (
    'parent_id' => '543',
    'cat_id' => '565',
    'grade' => '0',
  ),
  565 => 
  array (
    'parent_id' => '543',
    'cat_id' => '566',
    'grade' => '0',
  ),
  566 => 
  array (
    'parent_id' => '543',
    'cat_id' => '567',
    'grade' => '0',
  ),
  567 => 
  array (
    'parent_id' => '543',
    'cat_id' => '568',
    'grade' => '0',
  ),
  568 => 
  array (
    'parent_id' => '543',
    'cat_id' => '569',
    'grade' => '0',
  ),
  569 => 
  array (
    'parent_id' => '543',
    'cat_id' => '570',
    'grade' => '0',
  ),
  570 => 
  array (
    'parent_id' => '544',
    'cat_id' => '571',
    'grade' => '0',
  ),
  571 => 
  array (
    'parent_id' => '544',
    'cat_id' => '572',
    'grade' => '0',
  ),
  572 => 
  array (
    'parent_id' => '544',
    'cat_id' => '573',
    'grade' => '0',
  ),
  573 => 
  array (
    'parent_id' => '544',
    'cat_id' => '574',
    'grade' => '0',
  ),
  574 => 
  array (
    'parent_id' => '544',
    'cat_id' => '575',
    'grade' => '0',
  ),
  575 => 
  array (
    'parent_id' => '544',
    'cat_id' => '576',
    'grade' => '0',
  ),
  576 => 
  array (
    'parent_id' => '544',
    'cat_id' => '577',
    'grade' => '0',
  ),
  577 => 
  array (
    'parent_id' => '544',
    'cat_id' => '578',
    'grade' => '0',
  ),
  578 => 
  array (
    'parent_id' => '544',
    'cat_id' => '579',
    'grade' => '0',
  ),
  579 => 
  array (
    'parent_id' => '544',
    'cat_id' => '580',
    'grade' => '0',
  ),
  580 => 
  array (
    'parent_id' => '545',
    'cat_id' => '581',
    'grade' => '0',
  ),
  581 => 
  array (
    'parent_id' => '545',
    'cat_id' => '582',
    'grade' => '0',
  ),
  582 => 
  array (
    'parent_id' => '545',
    'cat_id' => '583',
    'grade' => '0',
  ),
  583 => 
  array (
    'parent_id' => '545',
    'cat_id' => '584',
    'grade' => '0',
  ),
  584 => 
  array (
    'parent_id' => '545',
    'cat_id' => '585',
    'grade' => '0',
  ),
  585 => 
  array (
    'parent_id' => '545',
    'cat_id' => '586',
    'grade' => '0',
  ),
  586 => 
  array (
    'parent_id' => '546',
    'cat_id' => '587',
    'grade' => '0',
  ),
  587 => 
  array (
    'parent_id' => '546',
    'cat_id' => '588',
    'grade' => '0',
  ),
  588 => 
  array (
    'parent_id' => '546',
    'cat_id' => '589',
    'grade' => '0',
  ),
  589 => 
  array (
    'parent_id' => '546',
    'cat_id' => '590',
    'grade' => '0',
  ),
  590 => 
  array (
    'parent_id' => '9',
    'cat_id' => '591',
    'grade' => '0',
  ),
  591 => 
  array (
    'parent_id' => '546',
    'cat_id' => '592',
    'grade' => '0',
  ),
  592 => 
  array (
    'parent_id' => '546',
    'cat_id' => '593',
    'grade' => '0',
  ),
  593 => 
  array (
    'parent_id' => '546',
    'cat_id' => '594',
    'grade' => '0',
  ),
  594 => 
  array (
    'parent_id' => '546',
    'cat_id' => '595',
    'grade' => '0',
  ),
  595 => 
  array (
    'parent_id' => '546',
    'cat_id' => '596',
    'grade' => '0',
  ),
  596 => 
  array (
    'parent_id' => '546',
    'cat_id' => '597',
    'grade' => '0',
  ),
  597 => 
  array (
    'parent_id' => '546',
    'cat_id' => '598',
    'grade' => '0',
  ),
  598 => 
  array (
    'parent_id' => '591',
    'cat_id' => '599',
    'grade' => '0',
  ),
  599 => 
  array (
    'parent_id' => '591',
    'cat_id' => '600',
    'grade' => '0',
  ),
  600 => 
  array (
    'parent_id' => '591',
    'cat_id' => '601',
    'grade' => '0',
  ),
  601 => 
  array (
    'parent_id' => '591',
    'cat_id' => '602',
    'grade' => '0',
  ),
  602 => 
  array (
    'parent_id' => '591',
    'cat_id' => '603',
    'grade' => '0',
  ),
  603 => 
  array (
    'parent_id' => '591',
    'cat_id' => '604',
    'grade' => '0',
  ),
  604 => 
  array (
    'parent_id' => '591',
    'cat_id' => '605',
    'grade' => '0',
  ),
  605 => 
  array (
    'parent_id' => '591',
    'cat_id' => '606',
    'grade' => '0',
  ),
  606 => 
  array (
    'parent_id' => '591',
    'cat_id' => '607',
    'grade' => '0',
  ),
  607 => 
  array (
    'parent_id' => '591',
    'cat_id' => '608',
    'grade' => '0',
  ),
  608 => 
  array (
    'parent_id' => '591',
    'cat_id' => '609',
    'grade' => '0',
  ),
  609 => 
  array (
    'parent_id' => '591',
    'cat_id' => '610',
    'grade' => '0',
  ),
  610 => 
  array (
    'parent_id' => '591',
    'cat_id' => '611',
    'grade' => '0',
  ),
  611 => 
  array (
    'parent_id' => '591',
    'cat_id' => '612',
    'grade' => '0',
  ),
  612 => 
  array (
    'parent_id' => '591',
    'cat_id' => '613',
    'grade' => '0',
  ),
  613 => 
  array (
    'parent_id' => '591',
    'cat_id' => '614',
    'grade' => '0',
  ),
  614 => 
  array (
    'parent_id' => '591',
    'cat_id' => '615',
    'grade' => '0',
  ),
  615 => 
  array (
    'parent_id' => '591',
    'cat_id' => '616',
    'grade' => '0',
  ),
  616 => 
  array (
    'parent_id' => '591',
    'cat_id' => '617',
    'grade' => '0',
  ),
  617 => 
  array (
    'parent_id' => '591',
    'cat_id' => '618',
    'grade' => '0',
  ),
  618 => 
  array (
    'parent_id' => '547',
    'cat_id' => '619',
    'grade' => '0',
  ),
  619 => 
  array (
    'parent_id' => '547',
    'cat_id' => '620',
    'grade' => '0',
  ),
  620 => 
  array (
    'parent_id' => '547',
    'cat_id' => '621',
    'grade' => '0',
  ),
  621 => 
  array (
    'parent_id' => '547',
    'cat_id' => '622',
    'grade' => '0',
  ),
  622 => 
  array (
    'parent_id' => '547',
    'cat_id' => '623',
    'grade' => '0',
  ),
  623 => 
  array (
    'parent_id' => '547',
    'cat_id' => '624',
    'grade' => '0',
  ),
  624 => 
  array (
    'parent_id' => '547',
    'cat_id' => '625',
    'grade' => '0',
  ),
  625 => 
  array (
    'parent_id' => '547',
    'cat_id' => '626',
    'grade' => '0',
  ),
  626 => 
  array (
    'parent_id' => '547',
    'cat_id' => '627',
    'grade' => '0',
  ),
  627 => 
  array (
    'parent_id' => '547',
    'cat_id' => '628',
    'grade' => '0',
  ),
  628 => 
  array (
    'parent_id' => '547',
    'cat_id' => '629',
    'grade' => '0',
  ),
  629 => 
  array (
    'parent_id' => '547',
    'cat_id' => '630',
    'grade' => '0',
  ),
  630 => 
  array (
    'parent_id' => '10',
    'cat_id' => '631',
    'grade' => '0',
  ),
  631 => 
  array (
    'parent_id' => '10',
    'cat_id' => '632',
    'grade' => '0',
  ),
  632 => 
  array (
    'parent_id' => '10',
    'cat_id' => '633',
    'grade' => '0',
  ),
  633 => 
  array (
    'parent_id' => '10',
    'cat_id' => '634',
    'grade' => '0',
  ),
  634 => 
  array (
    'parent_id' => '10',
    'cat_id' => '635',
    'grade' => '0',
  ),
  635 => 
  array (
    'parent_id' => '631',
    'cat_id' => '636',
    'grade' => '0',
  ),
  636 => 
  array (
    'parent_id' => '631',
    'cat_id' => '637',
    'grade' => '0',
  ),
  637 => 
  array (
    'parent_id' => '631',
    'cat_id' => '638',
    'grade' => '0',
  ),
  638 => 
  array (
    'parent_id' => '631',
    'cat_id' => '639',
    'grade' => '0',
  ),
  639 => 
  array (
    'parent_id' => '631',
    'cat_id' => '640',
    'grade' => '0',
  ),
  640 => 
  array (
    'parent_id' => '631',
    'cat_id' => '641',
    'grade' => '0',
  ),
  641 => 
  array (
    'parent_id' => '631',
    'cat_id' => '642',
    'grade' => '0',
  ),
  642 => 
  array (
    'parent_id' => '631',
    'cat_id' => '643',
    'grade' => '0',
  ),
  643 => 
  array (
    'parent_id' => '631',
    'cat_id' => '644',
    'grade' => '0',
  ),
  644 => 
  array (
    'parent_id' => '631',
    'cat_id' => '645',
    'grade' => '0',
  ),
  645 => 
  array (
    'parent_id' => '631',
    'cat_id' => '646',
    'grade' => '0',
  ),
  646 => 
  array (
    'parent_id' => '631',
    'cat_id' => '647',
    'grade' => '0',
  ),
  647 => 
  array (
    'parent_id' => '631',
    'cat_id' => '648',
    'grade' => '0',
  ),
  648 => 
  array (
    'parent_id' => '631',
    'cat_id' => '649',
    'grade' => '0',
  ),
  649 => 
  array (
    'parent_id' => '631',
    'cat_id' => '650',
    'grade' => '0',
  ),
  650 => 
  array (
    'parent_id' => '631',
    'cat_id' => '651',
    'grade' => '0',
  ),
  651 => 
  array (
    'parent_id' => '632',
    'cat_id' => '652',
    'grade' => '0',
  ),
  652 => 
  array (
    'parent_id' => '632',
    'cat_id' => '653',
    'grade' => '0',
  ),
  653 => 
  array (
    'parent_id' => '632',
    'cat_id' => '654',
    'grade' => '0',
  ),
  654 => 
  array (
    'parent_id' => '632',
    'cat_id' => '655',
    'grade' => '0',
  ),
  655 => 
  array (
    'parent_id' => '632',
    'cat_id' => '656',
    'grade' => '0',
  ),
  656 => 
  array (
    'parent_id' => '632',
    'cat_id' => '657',
    'grade' => '0',
  ),
  657 => 
  array (
    'parent_id' => '632',
    'cat_id' => '658',
    'grade' => '0',
  ),
  658 => 
  array (
    'parent_id' => '632',
    'cat_id' => '659',
    'grade' => '0',
  ),
  659 => 
  array (
    'parent_id' => '632',
    'cat_id' => '660',
    'grade' => '0',
  ),
  660 => 
  array (
    'parent_id' => '632',
    'cat_id' => '661',
    'grade' => '0',
  ),
  661 => 
  array (
    'parent_id' => '633',
    'cat_id' => '662',
    'grade' => '0',
  ),
  662 => 
  array (
    'parent_id' => '633',
    'cat_id' => '663',
    'grade' => '0',
  ),
  663 => 
  array (
    'parent_id' => '633',
    'cat_id' => '664',
    'grade' => '0',
  ),
  664 => 
  array (
    'parent_id' => '633',
    'cat_id' => '665',
    'grade' => '0',
  ),
  665 => 
  array (
    'parent_id' => '633',
    'cat_id' => '666',
    'grade' => '0',
  ),
  666 => 
  array (
    'parent_id' => '633',
    'cat_id' => '667',
    'grade' => '0',
  ),
  667 => 
  array (
    'parent_id' => '634',
    'cat_id' => '668',
    'grade' => '0',
  ),
  668 => 
  array (
    'parent_id' => '634',
    'cat_id' => '669',
    'grade' => '0',
  ),
  669 => 
  array (
    'parent_id' => '634',
    'cat_id' => '670',
    'grade' => '0',
  ),
  670 => 
  array (
    'parent_id' => '634',
    'cat_id' => '671',
    'grade' => '0',
  ),
  671 => 
  array (
    'parent_id' => '634',
    'cat_id' => '672',
    'grade' => '0',
  ),
  672 => 
  array (
    'parent_id' => '634',
    'cat_id' => '673',
    'grade' => '0',
  ),
  673 => 
  array (
    'parent_id' => '634',
    'cat_id' => '674',
    'grade' => '0',
  ),
  674 => 
  array (
    'parent_id' => '634',
    'cat_id' => '675',
    'grade' => '0',
  ),
  675 => 
  array (
    'parent_id' => '634',
    'cat_id' => '676',
    'grade' => '0',
  ),
  676 => 
  array (
    'parent_id' => '634',
    'cat_id' => '677',
    'grade' => '0',
  ),
  677 => 
  array (
    'parent_id' => '634',
    'cat_id' => '678',
    'grade' => '0',
  ),
  678 => 
  array (
    'parent_id' => '634',
    'cat_id' => '679',
    'grade' => '0',
  ),
  679 => 
  array (
    'parent_id' => '635',
    'cat_id' => '680',
    'grade' => '0',
  ),
  680 => 
  array (
    'parent_id' => '635',
    'cat_id' => '681',
    'grade' => '0',
  ),
  681 => 
  array (
    'parent_id' => '635',
    'cat_id' => '682',
    'grade' => '0',
  ),
  682 => 
  array (
    'parent_id' => '635',
    'cat_id' => '683',
    'grade' => '0',
  ),
  683 => 
  array (
    'parent_id' => '635',
    'cat_id' => '684',
    'grade' => '0',
  ),
  684 => 
  array (
    'parent_id' => '635',
    'cat_id' => '685',
    'grade' => '0',
  ),
  685 => 
  array (
    'parent_id' => '635',
    'cat_id' => '686',
    'grade' => '0',
  ),
  686 => 
  array (
    'parent_id' => '635',
    'cat_id' => '687',
    'grade' => '0',
  ),
  687 => 
  array (
    'parent_id' => '11',
    'cat_id' => '688',
    'grade' => '0',
  ),
  688 => 
  array (
    'parent_id' => '11',
    'cat_id' => '689',
    'grade' => '0',
  ),
  689 => 
  array (
    'parent_id' => '11',
    'cat_id' => '690',
    'grade' => '0',
  ),
  690 => 
  array (
    'parent_id' => '11',
    'cat_id' => '691',
    'grade' => '0',
  ),
  691 => 
  array (
    'parent_id' => '11',
    'cat_id' => '692',
    'grade' => '0',
  ),
  692 => 
  array (
    'parent_id' => '11',
    'cat_id' => '693',
    'grade' => '0',
  ),
  693 => 
  array (
    'parent_id' => '11',
    'cat_id' => '694',
    'grade' => '0',
  ),
  694 => 
  array (
    'parent_id' => '11',
    'cat_id' => '695',
    'grade' => '0',
  ),
  695 => 
  array (
    'parent_id' => '12',
    'cat_id' => '696',
    'grade' => '0',
  ),
  696 => 
  array (
    'parent_id' => '12',
    'cat_id' => '697',
    'grade' => '0',
  ),
  697 => 
  array (
    'parent_id' => '12',
    'cat_id' => '698',
    'grade' => '0',
  ),
  698 => 
  array (
    'parent_id' => '12',
    'cat_id' => '699',
    'grade' => '0',
  ),
  699 => 
  array (
    'parent_id' => '12',
    'cat_id' => '700',
    'grade' => '0',
  ),
  700 => 
  array (
    'parent_id' => '12',
    'cat_id' => '701',
    'grade' => '0',
  ),
  701 => 
  array (
    'parent_id' => '12',
    'cat_id' => '702',
    'grade' => '0',
  ),
  702 => 
  array (
    'parent_id' => '12',
    'cat_id' => '703',
    'grade' => '0',
  ),
  703 => 
  array (
    'parent_id' => '12',
    'cat_id' => '704',
    'grade' => '0',
  ),
  704 => 
  array (
    'parent_id' => '13',
    'cat_id' => '705',
    'grade' => '0',
  ),
  705 => 
  array (
    'parent_id' => '13',
    'cat_id' => '706',
    'grade' => '0',
  ),
  706 => 
  array (
    'parent_id' => '13',
    'cat_id' => '707',
    'grade' => '0',
  ),
  707 => 
  array (
    'parent_id' => '13',
    'cat_id' => '708',
    'grade' => '0',
  ),
  708 => 
  array (
    'parent_id' => '13',
    'cat_id' => '709',
    'grade' => '0',
  ),
  709 => 
  array (
    'parent_id' => '13',
    'cat_id' => '710',
    'grade' => '0',
  ),
  710 => 
  array (
    'parent_id' => '6',
    'cat_id' => '711',
    'grade' => '0',
  ),
  711 => 
  array (
    'parent_id' => '6',
    'cat_id' => '712',
    'grade' => '0',
  ),
  712 => 
  array (
    'parent_id' => '6',
    'cat_id' => '713',
    'grade' => '0',
  ),
  713 => 
  array (
    'parent_id' => '6',
    'cat_id' => '714',
    'grade' => '0',
  ),
  714 => 
  array (
    'parent_id' => '6',
    'cat_id' => '715',
    'grade' => '0',
  ),
  715 => 
  array (
    'parent_id' => '711',
    'cat_id' => '716',
    'grade' => '0',
  ),
  716 => 
  array (
    'parent_id' => '711',
    'cat_id' => '717',
    'grade' => '0',
  ),
  717 => 
  array (
    'parent_id' => '711',
    'cat_id' => '718',
    'grade' => '0',
  ),
  718 => 
  array (
    'parent_id' => '711',
    'cat_id' => '719',
    'grade' => '0',
  ),
  719 => 
  array (
    'parent_id' => '711',
    'cat_id' => '720',
    'grade' => '0',
  ),
  720 => 
  array (
    'parent_id' => '711',
    'cat_id' => '721',
    'grade' => '0',
  ),
  721 => 
  array (
    'parent_id' => '711',
    'cat_id' => '722',
    'grade' => '0',
  ),
  722 => 
  array (
    'parent_id' => '711',
    'cat_id' => '723',
    'grade' => '0',
  ),
  723 => 
  array (
    'parent_id' => '711',
    'cat_id' => '724',
    'grade' => '0',
  ),
  724 => 
  array (
    'parent_id' => '711',
    'cat_id' => '725',
    'grade' => '0',
  ),
  725 => 
  array (
    'parent_id' => '711',
    'cat_id' => '726',
    'grade' => '0',
  ),
  726 => 
  array (
    'parent_id' => '711',
    'cat_id' => '727',
    'grade' => '0',
  ),
  727 => 
  array (
    'parent_id' => '711',
    'cat_id' => '728',
    'grade' => '0',
  ),
  728 => 
  array (
    'parent_id' => '711',
    'cat_id' => '729',
    'grade' => '0',
  ),
  729 => 
  array (
    'parent_id' => '711',
    'cat_id' => '730',
    'grade' => '0',
  ),
  730 => 
  array (
    'parent_id' => '711',
    'cat_id' => '731',
    'grade' => '0',
  ),
  731 => 
  array (
    'parent_id' => '711',
    'cat_id' => '732',
    'grade' => '0',
  ),
  732 => 
  array (
    'parent_id' => '711',
    'cat_id' => '733',
    'grade' => '0',
  ),
  733 => 
  array (
    'parent_id' => '711',
    'cat_id' => '734',
    'grade' => '0',
  ),
  734 => 
  array (
    'parent_id' => '711',
    'cat_id' => '735',
    'grade' => '0',
  ),
  735 => 
  array (
    'parent_id' => '711',
    'cat_id' => '736',
    'grade' => '0',
  ),
  736 => 
  array (
    'parent_id' => '711',
    'cat_id' => '737',
    'grade' => '0',
  ),
  737 => 
  array (
    'parent_id' => '711',
    'cat_id' => '738',
    'grade' => '0',
  ),
  738 => 
  array (
    'parent_id' => '711',
    'cat_id' => '739',
    'grade' => '0',
  ),
  739 => 
  array (
    'parent_id' => '711',
    'cat_id' => '740',
    'grade' => '0',
  ),
  740 => 
  array (
    'parent_id' => '711',
    'cat_id' => '741',
    'grade' => '0',
  ),
  741 => 
  array (
    'parent_id' => '711',
    'cat_id' => '742',
    'grade' => '0',
  ),
  742 => 
  array (
    'parent_id' => '711',
    'cat_id' => '743',
    'grade' => '0',
  ),
  743 => 
  array (
    'parent_id' => '711',
    'cat_id' => '744',
    'grade' => '0',
  ),
  744 => 
  array (
    'parent_id' => '711',
    'cat_id' => '745',
    'grade' => '0',
  ),
  745 => 
  array (
    'parent_id' => '711',
    'cat_id' => '746',
    'grade' => '0',
  ),
  746 => 
  array (
    'parent_id' => '711',
    'cat_id' => '747',
    'grade' => '0',
  ),
  747 => 
  array (
    'parent_id' => '711',
    'cat_id' => '748',
    'grade' => '0',
  ),
  748 => 
  array (
    'parent_id' => '712',
    'cat_id' => '749',
    'grade' => '0',
  ),
  749 => 
  array (
    'parent_id' => '712',
    'cat_id' => '750',
    'grade' => '0',
  ),
  750 => 
  array (
    'parent_id' => '712',
    'cat_id' => '751',
    'grade' => '0',
  ),
  751 => 
  array (
    'parent_id' => '712',
    'cat_id' => '752',
    'grade' => '0',
  ),
  752 => 
  array (
    'parent_id' => '712',
    'cat_id' => '753',
    'grade' => '0',
  ),
  753 => 
  array (
    'parent_id' => '712',
    'cat_id' => '754',
    'grade' => '0',
  ),
  754 => 
  array (
    'parent_id' => '712',
    'cat_id' => '755',
    'grade' => '0',
  ),
  755 => 
  array (
    'parent_id' => '712',
    'cat_id' => '756',
    'grade' => '0',
  ),
  756 => 
  array (
    'parent_id' => '712',
    'cat_id' => '757',
    'grade' => '0',
  ),
  757 => 
  array (
    'parent_id' => '712',
    'cat_id' => '758',
    'grade' => '0',
  ),
  758 => 
  array (
    'parent_id' => '712',
    'cat_id' => '759',
    'grade' => '0',
  ),
  759 => 
  array (
    'parent_id' => '712',
    'cat_id' => '760',
    'grade' => '0',
  ),
  760 => 
  array (
    'parent_id' => '712',
    'cat_id' => '761',
    'grade' => '0',
  ),
  761 => 
  array (
    'parent_id' => '712',
    'cat_id' => '762',
    'grade' => '0',
  ),
  762 => 
  array (
    'parent_id' => '712',
    'cat_id' => '763',
    'grade' => '0',
  ),
  763 => 
  array (
    'parent_id' => '712',
    'cat_id' => '764',
    'grade' => '0',
  ),
  764 => 
  array (
    'parent_id' => '712',
    'cat_id' => '765',
    'grade' => '0',
  ),
  765 => 
  array (
    'parent_id' => '712',
    'cat_id' => '766',
    'grade' => '0',
  ),
  766 => 
  array (
    'parent_id' => '712',
    'cat_id' => '767',
    'grade' => '0',
  ),
  767 => 
  array (
    'parent_id' => '712',
    'cat_id' => '768',
    'grade' => '0',
  ),
  768 => 
  array (
    'parent_id' => '712',
    'cat_id' => '769',
    'grade' => '0',
  ),
  769 => 
  array (
    'parent_id' => '712',
    'cat_id' => '770',
    'grade' => '0',
  ),
  770 => 
  array (
    'parent_id' => '712',
    'cat_id' => '771',
    'grade' => '0',
  ),
  771 => 
  array (
    'parent_id' => '712',
    'cat_id' => '772',
    'grade' => '0',
  ),
  772 => 
  array (
    'parent_id' => '712',
    'cat_id' => '773',
    'grade' => '0',
  ),
  773 => 
  array (
    'parent_id' => '712',
    'cat_id' => '774',
    'grade' => '0',
  ),
  774 => 
  array (
    'parent_id' => '712',
    'cat_id' => '775',
    'grade' => '0',
  ),
  775 => 
  array (
    'parent_id' => '712',
    'cat_id' => '776',
    'grade' => '0',
  ),
  776 => 
  array (
    'parent_id' => '713',
    'cat_id' => '777',
    'grade' => '0',
  ),
  777 => 
  array (
    'parent_id' => '713',
    'cat_id' => '778',
    'grade' => '0',
  ),
  778 => 
  array (
    'parent_id' => '713',
    'cat_id' => '779',
    'grade' => '0',
  ),
  779 => 
  array (
    'parent_id' => '713',
    'cat_id' => '780',
    'grade' => '0',
  ),
  780 => 
  array (
    'parent_id' => '713',
    'cat_id' => '781',
    'grade' => '0',
  ),
  781 => 
  array (
    'parent_id' => '713',
    'cat_id' => '782',
    'grade' => '0',
  ),
  782 => 
  array (
    'parent_id' => '713',
    'cat_id' => '783',
    'grade' => '0',
  ),
  783 => 
  array (
    'parent_id' => '713',
    'cat_id' => '784',
    'grade' => '0',
  ),
  784 => 
  array (
    'parent_id' => '713',
    'cat_id' => '785',
    'grade' => '0',
  ),
  785 => 
  array (
    'parent_id' => '713',
    'cat_id' => '786',
    'grade' => '0',
  ),
  786 => 
  array (
    'parent_id' => '713',
    'cat_id' => '787',
    'grade' => '0',
  ),
  787 => 
  array (
    'parent_id' => '713',
    'cat_id' => '788',
    'grade' => '0',
  ),
  788 => 
  array (
    'parent_id' => '713',
    'cat_id' => '789',
    'grade' => '0',
  ),
  789 => 
  array (
    'parent_id' => '713',
    'cat_id' => '790',
    'grade' => '0',
  ),
  790 => 
  array (
    'parent_id' => '713',
    'cat_id' => '791',
    'grade' => '0',
  ),
  791 => 
  array (
    'parent_id' => '713',
    'cat_id' => '792',
    'grade' => '0',
  ),
  792 => 
  array (
    'parent_id' => '713',
    'cat_id' => '793',
    'grade' => '0',
  ),
  793 => 
  array (
    'parent_id' => '713',
    'cat_id' => '794',
    'grade' => '0',
  ),
  794 => 
  array (
    'parent_id' => '713',
    'cat_id' => '795',
    'grade' => '0',
  ),
  795 => 
  array (
    'parent_id' => '713',
    'cat_id' => '796',
    'grade' => '0',
  ),
  796 => 
  array (
    'parent_id' => '713',
    'cat_id' => '797',
    'grade' => '0',
  ),
  797 => 
  array (
    'parent_id' => '714',
    'cat_id' => '798',
    'grade' => '0',
  ),
  798 => 
  array (
    'parent_id' => '714',
    'cat_id' => '799',
    'grade' => '0',
  ),
  799 => 
  array (
    'parent_id' => '714',
    'cat_id' => '800',
    'grade' => '0',
  ),
  800 => 
  array (
    'parent_id' => '714',
    'cat_id' => '801',
    'grade' => '0',
  ),
  801 => 
  array (
    'parent_id' => '714',
    'cat_id' => '802',
    'grade' => '0',
  ),
  802 => 
  array (
    'parent_id' => '714',
    'cat_id' => '803',
    'grade' => '0',
  ),
  803 => 
  array (
    'parent_id' => '714',
    'cat_id' => '804',
    'grade' => '0',
  ),
  804 => 
  array (
    'parent_id' => '714',
    'cat_id' => '805',
    'grade' => '0',
  ),
  805 => 
  array (
    'parent_id' => '714',
    'cat_id' => '806',
    'grade' => '0',
  ),
  806 => 
  array (
    'parent_id' => '714',
    'cat_id' => '807',
    'grade' => '0',
  ),
  807 => 
  array (
    'parent_id' => '714',
    'cat_id' => '808',
    'grade' => '0',
  ),
  808 => 
  array (
    'parent_id' => '714',
    'cat_id' => '809',
    'grade' => '0',
  ),
  809 => 
  array (
    'parent_id' => '714',
    'cat_id' => '810',
    'grade' => '0',
  ),
  810 => 
  array (
    'parent_id' => '714',
    'cat_id' => '811',
    'grade' => '0',
  ),
  811 => 
  array (
    'parent_id' => '715',
    'cat_id' => '812',
    'grade' => '0',
  ),
  812 => 
  array (
    'parent_id' => '715',
    'cat_id' => '813',
    'grade' => '0',
  ),
  813 => 
  array (
    'parent_id' => '715',
    'cat_id' => '814',
    'grade' => '0',
  ),
  814 => 
  array (
    'parent_id' => '715',
    'cat_id' => '815',
    'grade' => '0',
  ),
  815 => 
  array (
    'parent_id' => '715',
    'cat_id' => '816',
    'grade' => '0',
  ),
  816 => 
  array (
    'parent_id' => '715',
    'cat_id' => '817',
    'grade' => '0',
  ),
  817 => 
  array (
    'parent_id' => '715',
    'cat_id' => '818',
    'grade' => '0',
  ),
  818 => 
  array (
    'parent_id' => '715',
    'cat_id' => '819',
    'grade' => '0',
  ),
  819 => 
  array (
    'parent_id' => '715',
    'cat_id' => '820',
    'grade' => '0',
  ),
  820 => 
  array (
    'parent_id' => '688',
    'cat_id' => '821',
    'grade' => '0',
  ),
  821 => 
  array (
    'parent_id' => '688',
    'cat_id' => '822',
    'grade' => '0',
  ),
  822 => 
  array (
    'parent_id' => '14',
    'cat_id' => '823',
    'grade' => '0',
  ),
  823 => 
  array (
    'parent_id' => '14',
    'cat_id' => '824',
    'grade' => '0',
  ),
  824 => 
  array (
    'parent_id' => '14',
    'cat_id' => '825',
    'grade' => '0',
  ),
  825 => 
  array (
    'parent_id' => '14',
    'cat_id' => '826',
    'grade' => '0',
  ),
  826 => 
  array (
    'parent_id' => '14',
    'cat_id' => '827',
    'grade' => '0',
  ),
  827 => 
  array (
    'parent_id' => '14',
    'cat_id' => '828',
    'grade' => '0',
  ),
  828 => 
  array (
    'parent_id' => '14',
    'cat_id' => '829',
    'grade' => '0',
  ),
  829 => 
  array (
    'parent_id' => '689',
    'cat_id' => '830',
    'grade' => '0',
  ),
  830 => 
  array (
    'parent_id' => '689',
    'cat_id' => '831',
    'grade' => '0',
  ),
  831 => 
  array (
    'parent_id' => '689',
    'cat_id' => '832',
    'grade' => '0',
  ),
  832 => 
  array (
    'parent_id' => '689',
    'cat_id' => '833',
    'grade' => '0',
  ),
  833 => 
  array (
    'parent_id' => '689',
    'cat_id' => '834',
    'grade' => '0',
  ),
  834 => 
  array (
    'parent_id' => '689',
    'cat_id' => '835',
    'grade' => '0',
  ),
  835 => 
  array (
    'parent_id' => '689',
    'cat_id' => '836',
    'grade' => '0',
  ),
  836 => 
  array (
    'parent_id' => '689',
    'cat_id' => '837',
    'grade' => '0',
  ),
  837 => 
  array (
    'parent_id' => '690',
    'cat_id' => '838',
    'grade' => '0',
  ),
  838 => 
  array (
    'parent_id' => '690',
    'cat_id' => '839',
    'grade' => '0',
  ),
  839 => 
  array (
    'parent_id' => '690',
    'cat_id' => '840',
    'grade' => '0',
  ),
  840 => 
  array (
    'parent_id' => '690',
    'cat_id' => '841',
    'grade' => '0',
  ),
  841 => 
  array (
    'parent_id' => '691',
    'cat_id' => '842',
    'grade' => '0',
  ),
  842 => 
  array (
    'parent_id' => '691',
    'cat_id' => '843',
    'grade' => '0',
  ),
  843 => 
  array (
    'parent_id' => '691',
    'cat_id' => '844',
    'grade' => '0',
  ),
  844 => 
  array (
    'parent_id' => '691',
    'cat_id' => '845',
    'grade' => '0',
  ),
  845 => 
  array (
    'parent_id' => '691',
    'cat_id' => '846',
    'grade' => '0',
  ),
  846 => 
  array (
    'parent_id' => '691',
    'cat_id' => '847',
    'grade' => '0',
  ),
  847 => 
  array (
    'parent_id' => '691',
    'cat_id' => '848',
    'grade' => '0',
  ),
  848 => 
  array (
    'parent_id' => '691',
    'cat_id' => '849',
    'grade' => '0',
  ),
  849 => 
  array (
    'parent_id' => '692',
    'cat_id' => '850',
    'grade' => '0',
  ),
  850 => 
  array (
    'parent_id' => '692',
    'cat_id' => '851',
    'grade' => '0',
  ),
  851 => 
  array (
    'parent_id' => '692',
    'cat_id' => '852',
    'grade' => '0',
  ),
  852 => 
  array (
    'parent_id' => '692',
    'cat_id' => '853',
    'grade' => '0',
  ),
  853 => 
  array (
    'parent_id' => '692',
    'cat_id' => '854',
    'grade' => '0',
  ),
  854 => 
  array (
    'parent_id' => '692',
    'cat_id' => '855',
    'grade' => '0',
  ),
  855 => 
  array (
    'parent_id' => '692',
    'cat_id' => '856',
    'grade' => '0',
  ),
  856 => 
  array (
    'parent_id' => '693',
    'cat_id' => '857',
    'grade' => '0',
  ),
  857 => 
  array (
    'parent_id' => '693',
    'cat_id' => '858',
    'grade' => '0',
  ),
  858 => 
  array (
    'parent_id' => '693',
    'cat_id' => '859',
    'grade' => '0',
  ),
  859 => 
  array (
    'parent_id' => '693',
    'cat_id' => '860',
    'grade' => '0',
  ),
  860 => 
  array (
    'parent_id' => '693',
    'cat_id' => '861',
    'grade' => '0',
  ),
  861 => 
  array (
    'parent_id' => '693',
    'cat_id' => '862',
    'grade' => '0',
  ),
  862 => 
  array (
    'parent_id' => '693',
    'cat_id' => '863',
    'grade' => '0',
  ),
  863 => 
  array (
    'parent_id' => '693',
    'cat_id' => '864',
    'grade' => '0',
  ),
  864 => 
  array (
    'parent_id' => '693',
    'cat_id' => '865',
    'grade' => '0',
  ),
  865 => 
  array (
    'parent_id' => '694',
    'cat_id' => '866',
    'grade' => '0',
  ),
  866 => 
  array (
    'parent_id' => '694',
    'cat_id' => '867',
    'grade' => '0',
  ),
  867 => 
  array (
    'parent_id' => '694',
    'cat_id' => '868',
    'grade' => '0',
  ),
  868 => 
  array (
    'parent_id' => '695',
    'cat_id' => '869',
    'grade' => '0',
  ),
  869 => 
  array (
    'parent_id' => '695',
    'cat_id' => '870',
    'grade' => '0',
  ),
  870 => 
  array (
    'parent_id' => '695',
    'cat_id' => '871',
    'grade' => '0',
  ),
  871 => 
  array (
    'parent_id' => '695',
    'cat_id' => '872',
    'grade' => '0',
  ),
  872 => 
  array (
    'parent_id' => '695',
    'cat_id' => '873',
    'grade' => '0',
  ),
  873 => 
  array (
    'parent_id' => '695',
    'cat_id' => '874',
    'grade' => '0',
  ),
  874 => 
  array (
    'parent_id' => '696',
    'cat_id' => '875',
    'grade' => '0',
  ),
  875 => 
  array (
    'parent_id' => '696',
    'cat_id' => '876',
    'grade' => '0',
  ),
  876 => 
  array (
    'parent_id' => '696',
    'cat_id' => '877',
    'grade' => '0',
  ),
  877 => 
  array (
    'parent_id' => '696',
    'cat_id' => '878',
    'grade' => '0',
  ),
  878 => 
  array (
    'parent_id' => '696',
    'cat_id' => '879',
    'grade' => '0',
  ),
  879 => 
  array (
    'parent_id' => '696',
    'cat_id' => '880',
    'grade' => '0',
  ),
  880 => 
  array (
    'parent_id' => '697',
    'cat_id' => '881',
    'grade' => '0',
  ),
  881 => 
  array (
    'parent_id' => '697',
    'cat_id' => '882',
    'grade' => '0',
  ),
  882 => 
  array (
    'parent_id' => '697',
    'cat_id' => '883',
    'grade' => '0',
  ),
  883 => 
  array (
    'parent_id' => '697',
    'cat_id' => '884',
    'grade' => '0',
  ),
  884 => 
  array (
    'parent_id' => '697',
    'cat_id' => '885',
    'grade' => '0',
  ),
  885 => 
  array (
    'parent_id' => '697',
    'cat_id' => '886',
    'grade' => '0',
  ),
  886 => 
  array (
    'parent_id' => '698',
    'cat_id' => '887',
    'grade' => '0',
  ),
  887 => 
  array (
    'parent_id' => '698',
    'cat_id' => '888',
    'grade' => '0',
  ),
  888 => 
  array (
    'parent_id' => '698',
    'cat_id' => '889',
    'grade' => '0',
  ),
  889 => 
  array (
    'parent_id' => '698',
    'cat_id' => '890',
    'grade' => '0',
  ),
  890 => 
  array (
    'parent_id' => '698',
    'cat_id' => '891',
    'grade' => '0',
  ),
  891 => 
  array (
    'parent_id' => '698',
    'cat_id' => '892',
    'grade' => '0',
  ),
  892 => 
  array (
    'parent_id' => '698',
    'cat_id' => '893',
    'grade' => '0',
  ),
  893 => 
  array (
    'parent_id' => '699',
    'cat_id' => '894',
    'grade' => '0',
  ),
  894 => 
  array (
    'parent_id' => '699',
    'cat_id' => '895',
    'grade' => '0',
  ),
  895 => 
  array (
    'parent_id' => '699',
    'cat_id' => '896',
    'grade' => '0',
  ),
  896 => 
  array (
    'parent_id' => '699',
    'cat_id' => '897',
    'grade' => '0',
  ),
  897 => 
  array (
    'parent_id' => '699',
    'cat_id' => '898',
    'grade' => '0',
  ),
  898 => 
  array (
    'parent_id' => '699',
    'cat_id' => '899',
    'grade' => '0',
  ),
  899 => 
  array (
    'parent_id' => '699',
    'cat_id' => '900',
    'grade' => '0',
  ),
  900 => 
  array (
    'parent_id' => '699',
    'cat_id' => '901',
    'grade' => '0',
  ),
  901 => 
  array (
    'parent_id' => '699',
    'cat_id' => '902',
    'grade' => '0',
  ),
  902 => 
  array (
    'parent_id' => '699',
    'cat_id' => '903',
    'grade' => '0',
  ),
  903 => 
  array (
    'parent_id' => '700',
    'cat_id' => '904',
    'grade' => '0',
  ),
  904 => 
  array (
    'parent_id' => '700',
    'cat_id' => '905',
    'grade' => '0',
  ),
  905 => 
  array (
    'parent_id' => '700',
    'cat_id' => '906',
    'grade' => '0',
  ),
  906 => 
  array (
    'parent_id' => '700',
    'cat_id' => '907',
    'grade' => '0',
  ),
  907 => 
  array (
    'parent_id' => '700',
    'cat_id' => '908',
    'grade' => '0',
  ),
  908 => 
  array (
    'parent_id' => '700',
    'cat_id' => '909',
    'grade' => '0',
  ),
  909 => 
  array (
    'parent_id' => '700',
    'cat_id' => '910',
    'grade' => '0',
  ),
  910 => 
  array (
    'parent_id' => '700',
    'cat_id' => '911',
    'grade' => '0',
  ),
  911 => 
  array (
    'parent_id' => '700',
    'cat_id' => '912',
    'grade' => '0',
  ),
  912 => 
  array (
    'parent_id' => '700',
    'cat_id' => '913',
    'grade' => '0',
  ),
  913 => 
  array (
    'parent_id' => '700',
    'cat_id' => '914',
    'grade' => '0',
  ),
  914 => 
  array (
    'parent_id' => '700',
    'cat_id' => '915',
    'grade' => '0',
  ),
  915 => 
  array (
    'parent_id' => '701',
    'cat_id' => '916',
    'grade' => '0',
  ),
  916 => 
  array (
    'parent_id' => '701',
    'cat_id' => '917',
    'grade' => '0',
  ),
  917 => 
  array (
    'parent_id' => '701',
    'cat_id' => '918',
    'grade' => '0',
  ),
  918 => 
  array (
    'parent_id' => '701',
    'cat_id' => '919',
    'grade' => '0',
  ),
  919 => 
  array (
    'parent_id' => '701',
    'cat_id' => '920',
    'grade' => '0',
  ),
  920 => 
  array (
    'parent_id' => '701',
    'cat_id' => '921',
    'grade' => '0',
  ),
  921 => 
  array (
    'parent_id' => '701',
    'cat_id' => '922',
    'grade' => '0',
  ),
  922 => 
  array (
    'parent_id' => '702',
    'cat_id' => '923',
    'grade' => '0',
  ),
  923 => 
  array (
    'parent_id' => '702',
    'cat_id' => '924',
    'grade' => '0',
  ),
  924 => 
  array (
    'parent_id' => '702',
    'cat_id' => '925',
    'grade' => '0',
  ),
  925 => 
  array (
    'parent_id' => '702',
    'cat_id' => '926',
    'grade' => '0',
  ),
  926 => 
  array (
    'parent_id' => '702',
    'cat_id' => '927',
    'grade' => '0',
  ),
  927 => 
  array (
    'parent_id' => '702',
    'cat_id' => '928',
    'grade' => '0',
  ),
  928 => 
  array (
    'parent_id' => '703',
    'cat_id' => '929',
    'grade' => '0',
  ),
  929 => 
  array (
    'parent_id' => '703',
    'cat_id' => '930',
    'grade' => '0',
  ),
  930 => 
  array (
    'parent_id' => '703',
    'cat_id' => '931',
    'grade' => '0',
  ),
  931 => 
  array (
    'parent_id' => '703',
    'cat_id' => '932',
    'grade' => '0',
  ),
  932 => 
  array (
    'parent_id' => '703',
    'cat_id' => '933',
    'grade' => '0',
  ),
  933 => 
  array (
    'parent_id' => '703',
    'cat_id' => '934',
    'grade' => '0',
  ),
  934 => 
  array (
    'parent_id' => '702',
    'cat_id' => '935',
    'grade' => '0',
  ),
  935 => 
  array (
    'parent_id' => '702',
    'cat_id' => '936',
    'grade' => '0',
  ),
  936 => 
  array (
    'parent_id' => '705',
    'cat_id' => '937',
    'grade' => '0',
  ),
  937 => 
  array (
    'parent_id' => '705',
    'cat_id' => '938',
    'grade' => '0',
  ),
  938 => 
  array (
    'parent_id' => '705',
    'cat_id' => '939',
    'grade' => '0',
  ),
  939 => 
  array (
    'parent_id' => '705',
    'cat_id' => '940',
    'grade' => '0',
  ),
  940 => 
  array (
    'parent_id' => '705',
    'cat_id' => '941',
    'grade' => '0',
  ),
  941 => 
  array (
    'parent_id' => '705',
    'cat_id' => '942',
    'grade' => '0',
  ),
  942 => 
  array (
    'parent_id' => '705',
    'cat_id' => '943',
    'grade' => '0',
  ),
  943 => 
  array (
    'parent_id' => '705',
    'cat_id' => '944',
    'grade' => '0',
  ),
  944 => 
  array (
    'parent_id' => '705',
    'cat_id' => '945',
    'grade' => '0',
  ),
  945 => 
  array (
    'parent_id' => '705',
    'cat_id' => '946',
    'grade' => '0',
  ),
  946 => 
  array (
    'parent_id' => '705',
    'cat_id' => '947',
    'grade' => '0',
  ),
  947 => 
  array (
    'parent_id' => '705',
    'cat_id' => '948',
    'grade' => '0',
  ),
  948 => 
  array (
    'parent_id' => '706',
    'cat_id' => '949',
    'grade' => '0',
  ),
  949 => 
  array (
    'parent_id' => '706',
    'cat_id' => '950',
    'grade' => '0',
  ),
  950 => 
  array (
    'parent_id' => '706',
    'cat_id' => '951',
    'grade' => '0',
  ),
  951 => 
  array (
    'parent_id' => '706',
    'cat_id' => '952',
    'grade' => '0',
  ),
  952 => 
  array (
    'parent_id' => '706',
    'cat_id' => '953',
    'grade' => '0',
  ),
  953 => 
  array (
    'parent_id' => '706',
    'cat_id' => '954',
    'grade' => '0',
  ),
  954 => 
  array (
    'parent_id' => '706',
    'cat_id' => '955',
    'grade' => '0',
  ),
  955 => 
  array (
    'parent_id' => '706',
    'cat_id' => '956',
    'grade' => '0',
  ),
  956 => 
  array (
    'parent_id' => '706',
    'cat_id' => '957',
    'grade' => '0',
  ),
  957 => 
  array (
    'parent_id' => '706',
    'cat_id' => '958',
    'grade' => '0',
  ),
  958 => 
  array (
    'parent_id' => '706',
    'cat_id' => '959',
    'grade' => '0',
  ),
  959 => 
  array (
    'parent_id' => '706',
    'cat_id' => '960',
    'grade' => '0',
  ),
  960 => 
  array (
    'parent_id' => '706',
    'cat_id' => '961',
    'grade' => '0',
  ),
  961 => 
  array (
    'parent_id' => '706',
    'cat_id' => '962',
    'grade' => '0',
  ),
  962 => 
  array (
    'parent_id' => '706',
    'cat_id' => '963',
    'grade' => '0',
  ),
  963 => 
  array (
    'parent_id' => '706',
    'cat_id' => '964',
    'grade' => '0',
  ),
  964 => 
  array (
    'parent_id' => '706',
    'cat_id' => '965',
    'grade' => '0',
  ),
  965 => 
  array (
    'parent_id' => '707',
    'cat_id' => '966',
    'grade' => '0',
  ),
  966 => 
  array (
    'parent_id' => '707',
    'cat_id' => '967',
    'grade' => '0',
  ),
  967 => 
  array (
    'parent_id' => '707',
    'cat_id' => '968',
    'grade' => '0',
  ),
  968 => 
  array (
    'parent_id' => '707',
    'cat_id' => '969',
    'grade' => '0',
  ),
  969 => 
  array (
    'parent_id' => '707',
    'cat_id' => '970',
    'grade' => '0',
  ),
  970 => 
  array (
    'parent_id' => '707',
    'cat_id' => '971',
    'grade' => '0',
  ),
  971 => 
  array (
    'parent_id' => '707',
    'cat_id' => '972',
    'grade' => '0',
  ),
  972 => 
  array (
    'parent_id' => '707',
    'cat_id' => '973',
    'grade' => '0',
  ),
  973 => 
  array (
    'parent_id' => '707',
    'cat_id' => '974',
    'grade' => '0',
  ),
  974 => 
  array (
    'parent_id' => '707',
    'cat_id' => '975',
    'grade' => '0',
  ),
  975 => 
  array (
    'parent_id' => '708',
    'cat_id' => '976',
    'grade' => '0',
  ),
  976 => 
  array (
    'parent_id' => '708',
    'cat_id' => '977',
    'grade' => '0',
  ),
  977 => 
  array (
    'parent_id' => '708',
    'cat_id' => '978',
    'grade' => '0',
  ),
  978 => 
  array (
    'parent_id' => '708',
    'cat_id' => '979',
    'grade' => '0',
  ),
  979 => 
  array (
    'parent_id' => '708',
    'cat_id' => '980',
    'grade' => '0',
  ),
  980 => 
  array (
    'parent_id' => '709',
    'cat_id' => '981',
    'grade' => '0',
  ),
  981 => 
  array (
    'parent_id' => '709',
    'cat_id' => '982',
    'grade' => '0',
  ),
  982 => 
  array (
    'parent_id' => '709',
    'cat_id' => '983',
    'grade' => '0',
  ),
  983 => 
  array (
    'parent_id' => '709',
    'cat_id' => '984',
    'grade' => '0',
  ),
  984 => 
  array (
    'parent_id' => '709',
    'cat_id' => '985',
    'grade' => '0',
  ),
  985 => 
  array (
    'parent_id' => '709',
    'cat_id' => '986',
    'grade' => '0',
  ),
  986 => 
  array (
    'parent_id' => '709',
    'cat_id' => '987',
    'grade' => '0',
  ),
  987 => 
  array (
    'parent_id' => '710',
    'cat_id' => '988',
    'grade' => '0',
  ),
  988 => 
  array (
    'parent_id' => '710',
    'cat_id' => '989',
    'grade' => '0',
  ),
  989 => 
  array (
    'parent_id' => '710',
    'cat_id' => '990',
    'grade' => '0',
  ),
  990 => 
  array (
    'parent_id' => '710',
    'cat_id' => '991',
    'grade' => '0',
  ),
  991 => 
  array (
    'parent_id' => '710',
    'cat_id' => '992',
    'grade' => '0',
  ),
  992 => 
  array (
    'parent_id' => '0',
    'cat_id' => '996',
    'grade' => '0',
  ),
  993 => 
  array (
    'parent_id' => '996',
    'cat_id' => '997',
    'grade' => '0',
  ),
  994 => 
  array (
    'parent_id' => '997',
    'cat_id' => '998',
    'grade' => '0',
  ),
);
?>