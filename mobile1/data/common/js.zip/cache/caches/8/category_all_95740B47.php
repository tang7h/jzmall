<?php exit;?>a:3:{s:8:"template";a:4:{i:0;s:64:"/mnt/wwwroot/kehunewbigjd/mobile/themes/default/category_all.dwt";i:1;s:71:"/mnt/wwwroot/kehunewbigjd/mobile/themes/default/library/page_header.lbi";i:2;s:69:"/mnt/wwwroot/kehunewbigjd/mobile/themes/default/library/page_menu.lbi";i:3;s:71:"/mnt/wwwroot/kehunewbigjd/mobile/themes/default/library/page_footer.lbi";}s:7:"expires";i:1419912210;s:8:"maketime";i:1419908610;}<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>香水彩妆_个护化妆_136分钟到货的网上商城 - Powered by ECTouch.cn 触屏版</title>
<!--<link rel="stylesheet" href="/kehunewbigjd/mobile/data/common/bootstrap/css/bootstrap.min.css">-->
<link rel="stylesheet" href="/kehunewbigjd/mobile/data/common/bootstrap/css/font-awesome.min.css">
<link rel="stylesheet" href="/kehunewbigjd/mobile/themes/default/css/ectouch.css">
<link rel="stylesheet" href="/kehunewbigjd/mobile/themes/default/css/photoswipe.css"></head><body><header id="header">
  <div class="header_l header_return"> <a href="javascript:history.go(-1);"><span></span></a></div>
  <h1>商品分类</h1>
  <div class="header_r header_search"> <a class="new-a-jd" onClick="showSearch()"><span></span></a></div>
  <div id="search_box"> <div class="new-jd-tab">
  <div class="new-tbl-type"> 
    <a href="/kehunewbigjd/mobile/index.php?m=default&c=index&a=index" class="new-tbl-cell"><span class="icon">首页</span>
    <p style="color:#6e6e6e;">首页</p>
    </a> <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all" class="new-tbl-cell"><span class="icon icon2">分类搜索</span>
    <p style="color:#6e6e6e;">分类搜索</p>
    </a> <a href="/kehunewbigjd/mobile/index.php?m=default&c=flow&a=cart" class="new-tbl-cell"><span class="icon icon3">购物车</span>
    <p style="color:#6e6e6e;">购物车</p>
    </a> <a href="/kehunewbigjd/mobile/index.php?m=default&c=user&a=index" class="new-tbl-cell"><span class="icon icon4">我的京东</span>
    <p style="color:#6e6e6e;">我的京东</p>
    </a> </div>
</div>
<a class="Touming" onClick="closeSearch()"></a>  </div>
</header>
<div class="list p-sort radius">
  <div class="mc">
    <ul>
       
       
      <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=index&id=447">
      <li class="first"> <strong class="name1">香水</strong> <span class="menu-botton-arrow"></span> </li>
      </a> 
       
       
       
      <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=index&id=448">
      <li class="first"> <strong class="name1">底妆</strong> <span class="menu-botton-arrow"></span> </li>
      </a> 
       
       
       
      <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=index&id=449">
      <li class="first"> <strong class="name1">腮红</strong> <span class="menu-botton-arrow"></span> </li>
      </a> 
       
       
       
      <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=index&id=450">
      <li class="first"> <strong class="name1">眼部</strong> <span class="menu-botton-arrow"></span> </li>
      </a> 
       
       
       
      <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=index&id=451">
      <li class="first"> <strong class="name1">唇部</strong> <span class="menu-botton-arrow"></span> </li>
      </a> 
       
       
       
      <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=index&id=452">
      <li class="first"> <strong class="name1">美甲</strong> <span class="menu-botton-arrow"></span> </li>
      </a> 
       
       
       
      <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=index&id=453">
      <li class="first"> <strong class="name1">美容工具</strong> <span class="menu-botton-arrow"></span> </li>
      </a> 
       
       
       
      <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=index&id=454">
      <li class="first"> <strong class="name1">套装</strong> <span class="menu-botton-arrow"></span> </li>
      </a> 
       
          </ul>
  </div>
</div>
<div id="content" class="login-area">
  <div class="login">
  	<font id="ECS_MEMBERZONE">554fcae493e564ee0dc75bdf2ebf94camember_info|a:1:{s:4:"name";s:11:"member_info";}554fcae493e564ee0dc75bdf2ebf94ca </font>
    <span><span class="new-fr"><a href="#top">回到顶部</a></span></span>
  </div>
  <p class="version"> <a href="#"> 电脑版 </a> <a href="#"> 触屏版 </a> <a href="#"> 苹果客户端 </a> <a class="#"> Android客户端 </a> </p>
  <p class="region"> 
     
    ICP备案证书号: <a href="#" target="_blank"> 京ICP证070359号 </a> 
     
    &copy; 2005-2014 136商城 版权所有，并保留所有权利。 </p>
  <div class="favLink region"> <a href="#"> powered by ecmoban </a> </div>
</div>
<input type="hidden" value="" id="fixed" />
<script type="text/javascript" src="/kehunewbigjd/mobile/data/common/js/jquery.min.js" ></script> 
<script type="text/javascript" src="/kehunewbigjd/mobile/data/common/js/jquery.json.js" ></script> 
<script type="text/javascript" src="/kehunewbigjd/mobile/data/common/js/common.js"></script> 
<script type="text/javascript" src="/kehunewbigjd/mobile/data/common/js/jquery.more.js"></script> 
<script type="text/javascript" src="/kehunewbigjd/mobile/data/common/js/utils.js" ></script> 
<script src="/kehunewbigjd/mobile/themes/default/js/TouchSlide.1.1.js"></script> 
<script src="/kehunewbigjd/mobile/themes/default/js/ectouch.js"></script> 
<script type="text/javascript" src="/kehunewbigjd/mobile/data/common/js/location.js" ></script>
<!--<script src="/kehunewbigjd/mobile/themes/default/js/simple-inheritance.min.js"></script> -->
<!--<script src="/kehunewbigjd/mobile/themes/default/js/code-photoswipe-1.0.11.min.js"></script> -->
<script src="/kehunewbigjd/mobile/data/common/bootstrap/js/bootstrap.min.js"></script> 
<!--<script src="/kehunewbigjd/mobile/themes/default/js/jquery.scrollUp.min.js"></script> -->
<script type="text/javascript" src="/kehunewbigjd/mobile/data/common/js/validform.js" ></script> 
<script language="javascript">
	/*banner滚动图片*/
		TouchSlide({
			slideCell : "#focus",
			titCell : ".hd ul", // 开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
			mainCell : ".bd ul",
			effect : "left",
			autoPlay : true, // 自动播放
			autoPage : true, // 自动分页
			switchLoad : "_src" // 切换加载，真实图片路径为"_src"
		});
	/*弹出评论层并隐藏其他层*/
	function openSearch(){
		 //document.getElementById("search_box").style.display = "none";
			$("#search_box").show();
	}
	function closeSearch(){
			$("#search_box").hide();
	}
</script> </body></html>