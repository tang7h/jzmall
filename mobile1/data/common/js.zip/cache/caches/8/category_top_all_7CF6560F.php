<?php exit;?>a:3:{s:8:"template";a:4:{i:0;s:68:"/mnt/wwwroot/kehunewbigjd/mobile/themes/default/category_top_all.dwt";i:1;s:71:"/mnt/wwwroot/kehunewbigjd/mobile/themes/default/library/page_header.lbi";i:2;s:69:"/mnt/wwwroot/kehunewbigjd/mobile/themes/default/library/page_menu.lbi";i:3;s:71:"/mnt/wwwroot/kehunewbigjd/mobile/themes/default/library/page_footer.lbi";}s:7:"expires";i:1419857186;s:8:"maketime";i:1419853586;}<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>所有分类_136分钟到货的网上商城 - Powered by ECTouch.cn 触屏版</title>
<!--<link rel="stylesheet" href="/kehunewbigjd/mobile/data/common/bootstrap/css/bootstrap.min.css">-->
<link rel="stylesheet" href="/kehunewbigjd/mobile/data/common/bootstrap/css/font-awesome.min.css">
<link rel="stylesheet" href="/kehunewbigjd/mobile/themes/default/css/ectouch.css">
<link rel="stylesheet" href="/kehunewbigjd/mobile/themes/default/css/photoswipe.css"></head><body><header id="header">
  <div class="header_l header_return"> <a href="javascript:history.go(-1);"><span></span></a></div>
  <h1>商品分类</h1>
  <div class="header_r header_search"> <a class="new-a-jd" onClick="showSearch()"><span></span></a></div>
  <div id="search_box"> <div class="new-jd-tab">
  <div class="new-tbl-type"> 
    <a href="/kehunewbigjd/mobile/index.php?m=default&c=index&a=index" class="new-tbl-cell"><span class="icon">首页</span>
    <p style="color:#6e6e6e;">首页</p>
    </a> <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all" class="new-tbl-cell"><span class="icon icon2">分类搜索</span>
    <p style="color:#6e6e6e;">分类搜索</p>
    </a> <a href="/kehunewbigjd/mobile/index.php?m=default&c=flow&a=cart" class="new-tbl-cell"><span class="icon icon3">购物车</span>
    <p style="color:#6e6e6e;">购物车</p>
    </a> <a href="/kehunewbigjd/mobile/index.php?m=default&c=user&a=index" class="new-tbl-cell"><span class="icon icon4">我的京东</span>
    <p style="color:#6e6e6e;">我的京东</p>
    </a> </div>
</div>
<a class="Touming" onClick="closeSearch()"></a>  </div>
</header>
<div class="new-cate-srch">
  <div class="new-srch-box">
    <form method="post" action="/kehunewbigjd/mobile/index.php?m=default&c=category&a=index" name="searchForm" id="searchForm_id">
      <input placeholder="请输入搜索关键词！" name="keywords" type="text" id="keywordBox" class="new-srch-input" style="color:#999999;" />
      <a href="javascript:void(0);" target="_self" class="new-s-close"></a>
      <button class="new-s-srch" type="submit" onclick="return check('keywordBox')"><span></span></button>
    </form>
  </div>
</div>
<div class="clist">
  <ul class="new-category-lst">
        <li class="crow level1"> 
            <div class="crow_row">
        <div class="crow_icon"><span class="icon"></span></div>
        <div class="crow_title">  <span>图书、音像、数字商品</span>  </div>
        <div>&nbsp;</div>
      </div>
      <ul class="clist_sub clearfix" style="opacity: 1; display: none;">
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=22"><span class="new-bar"></span>科技</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=15"><span class="new-bar"></span>电子书</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=16"><span class="new-bar"></span>数字音乐</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=17"><span class="new-bar"></span>音像</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=18"><span class="new-bar"></span>文艺</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=19"><span class="new-bar"></span>人文社科</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=20"><span class="new-bar"></span>经管励志</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=21"><span class="new-bar"></span>生活</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=23"><span class="new-bar"></span>少儿</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=24"><span class="new-bar"></span>教育</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=25"><span class="new-bar"></span>其它</a> 
           
           
        </li>
         
              </ul>
       
    </li>
        <li class="crow level1"> 
            <div class="crow_row">
        <div class="crow_icon"><span class="icon"></span></div>
        <div class="crow_title">  <span>家用电器</span>  </div>
        <div>&nbsp;</div>
      </div>
      <ul class="clist_sub clearfix" style="opacity: 1; display: none;">
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=90"><span class="new-bar"></span>大 家 电</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=93"><span class="new-bar"></span>个护健康</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=92"><span class="new-bar"></span>厨房电器</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=91"><span class="new-bar"></span>生活电器</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=94"><span class="new-bar"></span>五金家装</a> 
           
           
        </li>
         
              </ul>
       
    </li>
        <li class="crow level1"> 
            <div class="crow_row">
        <div class="crow_icon"><span class="icon"></span></div>
        <div class="crow_title">  <span>手机、数码、京东通信</span>  </div>
        <div>&nbsp;</div>
      </div>
      <ul class="clist_sub clearfix" style="opacity: 1; display: none;">
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=172"><span class="new-bar"></span>手机通讯</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=173"><span class="new-bar"></span>京东通信</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=174"><span class="new-bar"></span>运营商</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=175"><span class="new-bar"></span>手机配件</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=176"><span class="new-bar"></span>摄影摄像</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=177"><span class="new-bar"></span>数码配件</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=178"><span class="new-bar"></span>时尚影音</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=179"><span class="new-bar"></span>智能设备</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=180"><span class="new-bar"></span>电子教育</a> 
           
           
        </li>
         
              </ul>
       
    </li>
        <li class="crow level1"> 
            <div class="crow_row">
        <div class="crow_icon"><span class="icon"></span></div>
        <div class="crow_title">  <span>电脑、办公</span>  </div>
        <div>&nbsp;</div>
      </div>
      <ul class="clist_sub clearfix" style="opacity: 1; display: none;">
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=244"><span class="new-bar"></span>电脑整机</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=245"><span class="new-bar"></span>电脑配件</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=246"><span class="new-bar"></span>外设产品</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=247"><span class="new-bar"></span>网络产品</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=248"><span class="new-bar"></span>办公打印</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=249"><span class="new-bar"></span>办公文仪</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=250"><span class="new-bar"></span>服务产品</a> 
           
           
        </li>
         
              </ul>
       
    </li>
        <li class="crow level1"> 
            <div class="crow_row">
        <div class="crow_icon"><span class="icon"></span></div>
        <div class="crow_title">  <span>家居、家具、家装、厨具</span>  </div>
        <div>&nbsp;</div>
      </div>
      <ul class="clist_sub clearfix" style="opacity: 1; display: none;">
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=330"><span class="new-bar"></span>家纺</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=328"><span class="new-bar"></span>厨具</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=329"><span class="new-bar"></span>家装建材</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=331"><span class="new-bar"></span>家具</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=332"><span class="new-bar"></span>灯具</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=333"><span class="new-bar"></span>生活日用</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=334"><span class="new-bar"></span>家装软饰</a> 
           
           
        </li>
         
              </ul>
       
    </li>
        <li class="crow level1"> 
            <div class="crow_row">
        <div class="crow_icon"><span class="icon"></span></div>
        <div class="crow_title">  <span>服饰内衣、珠宝首饰</span>  </div>
        <div>&nbsp;</div>
      </div>
      <ul class="clist_sub clearfix" style="opacity: 1; display: none;">
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=711"><span class="new-bar"></span>女装</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=712"><span class="new-bar"></span>男装</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=713"><span class="new-bar"></span>内衣</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=714"><span class="new-bar"></span>服饰配件</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=715"><span class="new-bar"></span>珠宝首饰</a> 
           
           
        </li>
         
              </ul>
       
    </li>
        <li class="crow level1"> 
            <div class="crow_row">
        <div class="crow_icon"><span class="icon"></span></div>
        <div class="crow_title">  <span>个护化妆</span>  </div>
        <div>&nbsp;</div>
      </div>
      <ul class="clist_sub clearfix" style="opacity: 1; display: none;">
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=415"><span class="new-bar"></span>面部护肤</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=416"><span class="new-bar"></span>洗发护发</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=417"><span class="new-bar"></span>身体护肤</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=418"><span class="new-bar"></span>口腔护理</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=419"><span class="new-bar"></span>女性护理</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=420"><span class="new-bar"></span>香水彩妆</a> 
           
           
        </li>
         
              </ul>
       
    </li>
        <li class="crow level1"> 
            <div class="crow_row">
        <div class="crow_icon"><span class="icon"></span></div>
        <div class="crow_title">  <span>鞋靴、箱包、钟表、奢侈品</span>  </div>
        <div>&nbsp;</div>
      </div>
      <ul class="clist_sub clearfix" style="opacity: 1; display: none;">
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=455"><span class="new-bar"></span>时尚女鞋</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=456"><span class="new-bar"></span>流行男鞋</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=457"><span class="new-bar"></span>潮流女包</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=458"><span class="new-bar"></span>精品男包</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=459"><span class="new-bar"></span>功能箱包</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=460"><span class="new-bar"></span>奢侈品</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=461"><span class="new-bar"></span>钟表</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=462"><span class="new-bar"></span>礼品</a> 
           
           
        </li>
         
              </ul>
       
    </li>
        <li class="crow level1"> 
            <div class="crow_row">
        <div class="crow_icon"><span class="icon"></span></div>
        <div class="crow_title">  <span>运动户外</span>  </div>
        <div>&nbsp;</div>
      </div>
      <ul class="clist_sub clearfix" style="opacity: 1; display: none;">
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=542"><span class="new-bar"></span>运动鞋包</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=543"><span class="new-bar"></span>运动服饰</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=544"><span class="new-bar"></span>健身训练</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=545"><span class="new-bar"></span>骑行运动</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=546"><span class="new-bar"></span>体育用品</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=547"><span class="new-bar"></span>户外装备</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=591"><span class="new-bar"></span>户外鞋服</a> 
           
           
        </li>
         
              </ul>
       
    </li>
        <li class="crow level1"> 
            <div class="crow_row">
        <div class="crow_icon"><span class="icon"></span></div>
        <div class="crow_title">  <span>汽车用品</span>  </div>
        <div>&nbsp;</div>
      </div>
      <ul class="clist_sub clearfix" style="opacity: 1; display: none;">
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=631"><span class="new-bar"></span>维修保养</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=632"><span class="new-bar"></span>车载电器</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=633"><span class="new-bar"></span>美容清洗</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=634"><span class="new-bar"></span>汽车装饰</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=635"><span class="new-bar"></span>安全自驾</a> 
           
           
        </li>
         
              </ul>
       
    </li>
        <li class="crow level1"> 
            <div class="crow_row">
        <div class="crow_icon"><span class="icon"></span></div>
        <div class="crow_title">  <span>母婴、玩具乐器</span>  </div>
        <div>&nbsp;</div>
      </div>
      <ul class="clist_sub clearfix" style="opacity: 1; display: none;">
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=688"><span class="new-bar"></span>奶粉</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=689"><span class="new-bar"></span>营养辅食</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=690"><span class="new-bar"></span>尿裤湿巾</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=691"><span class="new-bar"></span>洗护用品</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=692"><span class="new-bar"></span>喂养用品</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=693"><span class="new-bar"></span>童车童床</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=694"><span class="new-bar"></span>安全座椅</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=695"><span class="new-bar"></span>寝居服饰</a> 
           
           
        </li>
         
              </ul>
       
    </li>
        <li class="crow level1"> 
            <div class="crow_row">
        <div class="crow_icon"><span class="icon"></span></div>
        <div class="crow_title">  <span>食品饮料、酒类、生鲜</span>  </div>
        <div>&nbsp;</div>
      </div>
      <ul class="clist_sub clearfix" style="opacity: 1; display: none;">
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=696"><span class="new-bar"></span>中外名酒</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=697"><span class="new-bar"></span>进口食品</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=698"><span class="new-bar"></span>休闲食品</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=699"><span class="new-bar"></span>地方特产</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=700"><span class="new-bar"></span>茗茶</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=701"><span class="new-bar"></span>饮料冲调</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=702"><span class="new-bar"></span>粮油调味</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=703"><span class="new-bar"></span>生鲜食品</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=index&id=704"><span class="new-bar"></span>食品礼券</a> 
           
           
        </li>
         
              </ul>
       
    </li>
        <li class="crow level1"> 
            <div class="crow_row">
        <div class="crow_icon"><span class="icon"></span></div>
        <div class="crow_title">  <span>营养保健</span>  </div>
        <div>&nbsp;</div>
      </div>
      <ul class="clist_sub clearfix" style="opacity: 1; display: none;">
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=705"><span class="new-bar"></span>营养健康</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=706"><span class="new-bar"></span>营养成分</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=707"><span class="new-bar"></span>传统滋补</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=708"><span class="new-bar"></span>成人用品</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=709"><span class="new-bar"></span>保健器械</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=all&id=710"><span class="new-bar"></span>急救卫生</a> 
           
           
        </li>
         
              </ul>
       
    </li>
        <li class="crow level1"> 
            <div class="crow_row">
        <div class="crow_icon"><span class="icon"></span></div>
        <div class="crow_title">  <span>彩票、旅行、充值、票务</span>  </div>
        <div>&nbsp;</div>
      </div>
      <ul class="clist_sub clearfix" style="opacity: 1; display: none;">
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=index&id=823"><span class="new-bar"></span>彩票</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=index&id=824"><span class="new-bar"></span>通讯充值</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=index&id=825"><span class="new-bar"></span>游戏</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=index&id=826"><span class="new-bar"></span>便利生活</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=index&id=827"><span class="new-bar"></span>演出票务</a> 
           
           
         
         
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=index&id=828"><span class="new-bar"></span>保险</a> 
           
           
        </li>
         
         
                <li class="new-category2-li"> 
           
           
          <a href="/kehunewbigjd/mobile/index.php?m=default&c=category&a=index&id=829"><span class="new-bar"></span>教育培训</a> 
           
           
        </li>
         
              </ul>
       
    </li>
      </ul>
</div>
<div id="content" class="login-area">
  <div class="login">
  	<font id="ECS_MEMBERZONE">554fcae493e564ee0dc75bdf2ebf94camember_info|a:1:{s:4:"name";s:11:"member_info";}554fcae493e564ee0dc75bdf2ebf94ca </font>
    <span><span class="new-fr"><a href="#top">回到顶部</a></span></span>
  </div>
  <p class="version"> <a href="#"> 电脑版 </a> <a href="#"> 触屏版 </a> <a href="#"> 苹果客户端 </a> <a class="#"> Android客户端 </a> </p>
  <p class="region"> 
     
    ICP备案证书号: <a href="#" target="_blank"> 京ICP证070359号 </a> 
     
    &copy; 2005-2014 136商城 版权所有，并保留所有权利。 </p>
  <div class="favLink region"> <a href="#"> powered by ecmoban </a> </div>
</div>
<input type="hidden" value="" id="fixed" />
<script type="text/javascript" src="/kehunewbigjd/mobile/data/common/js/jquery.min.js" ></script> 
<script type="text/javascript" src="/kehunewbigjd/mobile/data/common/js/jquery.json.js" ></script> 
<script type="text/javascript" src="/kehunewbigjd/mobile/data/common/js/common.js"></script> 
<script type="text/javascript" src="/kehunewbigjd/mobile/data/common/js/jquery.more.js"></script> 
<script type="text/javascript" src="/kehunewbigjd/mobile/data/common/js/utils.js" ></script> 
<script src="/kehunewbigjd/mobile/themes/default/js/TouchSlide.1.1.js"></script> 
<script src="/kehunewbigjd/mobile/themes/default/js/ectouch.js"></script> 
<script type="text/javascript" src="/kehunewbigjd/mobile/data/common/js/location.js" ></script>
<!--<script src="/kehunewbigjd/mobile/themes/default/js/simple-inheritance.min.js"></script> -->
<!--<script src="/kehunewbigjd/mobile/themes/default/js/code-photoswipe-1.0.11.min.js"></script> -->
<script src="/kehunewbigjd/mobile/data/common/bootstrap/js/bootstrap.min.js"></script> 
<!--<script src="/kehunewbigjd/mobile/themes/default/js/jquery.scrollUp.min.js"></script> -->
<script type="text/javascript" src="/kehunewbigjd/mobile/data/common/js/validform.js" ></script> 
<script language="javascript">
	/*banner滚动图片*/
		TouchSlide({
			slideCell : "#focus",
			titCell : ".hd ul", // 开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
			mainCell : ".bd ul",
			effect : "left",
			autoPlay : true, // 自动播放
			autoPage : true, // 自动分页
			switchLoad : "_src" // 切换加载，真实图片路径为"_src"
		});
	/*弹出评论层并隐藏其他层*/
	function openSearch(){
		 //document.getElementById("search_box").style.display = "none";
			$("#search_box").show();
	}
	function closeSearch(){
			$("#search_box").hide();
	}
</script> </body></html>