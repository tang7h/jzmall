<div id="page">
  <header id="header">
    <div class="header_l header_return"> <a onClick="javascript:history.go(-1);"><span></span></a></div>
    <h1><?php echo $this->_var['title']; ?></h1>
    <div class="header_r header_search"> <a class="new-a-jd" onClick="showSearch()"><span></span></a></div>
    <div id="search_box">
      <?php echo $this->fetch('library/page_menu.lbi'); ?> </div>
  </header>
</div>
<section class="wrap" style="border-bottom:0;">
  <form action="<?php echo url('flow/done');?>" method="post" name="theForm" id="theForm" onSubmit="return checkOrderForm(this)">
    <script type="text/javascript">
        var flow_no_payment = "<?php echo $this->_var['lang']['flow_no_payment']; ?>";
        var flow_no_shipping = "<?php echo $this->_var['lang']['flow_no_shipping']; ?>";
        </script>
    <section class="order_box padd1 radius10" style="padding-top:0">
      <div class="in">
        <div class="title"><?php echo $this->_var['lang']['consignee_info']; ?></div>
        <div class="table_box table_box1">
          <div class="Info"> <a href="<?php echo url('flow/consignee');?>" style="padding-left:10px;"> <span class="text"><?php echo htmlspecialchars($this->_var['consignee']['consignee']); ?><span class="phone-num"><?php echo $this->_var['consignee']['tel']; ?></span></span> <span class="text2"><?php echo htmlspecialchars($this->_var['consignee']['address']); ?></span> </a> <span class="icon-arr"></span> </div>
        </div>
      </div>
    </section>
    
	
    <section class="order_box padd1">
      <div class="title"><?php echo $this->_var['lang']['payment_method']; ?><span class="span1 radius5"><?php echo $this->_var['lang']['require_field']; ?></span></div>
      <div class="table_box table_box2">
        <div class="Info InfoBox"> 
          <?php if ($this->_var['is_exchange_goods'] != 1 || $this->_var['total']['real_goods_count'] != 0): ?>
          <dl style="border:0;">
            <dd class="dd2 selectPayment" id="selected2"><?php echo $this->_var['lang']['select_payment_method']; ?></dd>
            <i class="icon-arr icon-arr-bottom icon-arr-Top"></i>
          </dl>
          <div class="dl_box" id="payment" style="display:none; border-top:1px solid #f3f3f3;"> 
            <?php $_from = $this->_var['payment_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'payment');if (count($_from)):
    foreach ($_from AS $this->_var['payment']):
?>
            <p>
              <input type="radio" class="radio" name="payment" id="payment_<?php echo $this->_var['payment']['pay_id']; ?>" value="<?php echo $this->_var['payment']['pay_id']; ?>" <?php if ($this->_var['order']['pay_id'] == $this->_var['payment']['pay_id']): ?>checked<?php endif; ?> isCod="<?php echo $this->_var['payment']['is_cod']; ?>" onclick="selectPayment(this)" <?php if ($this->_var['cod_disabled'] && $this->_var['payment']['is_cod'] == "1"): ?>disabled="true"<?php endif; ?> style="vertical-align:middle" />
              <label for="payment_<?php echo $this->_var['payment']['pay_id']; ?>"> <?php echo $this->_var['payment']['pay_name']; ?> [<?php echo $this->_var['payment']['format_pay_fee']; ?>]</label>
            </p>
            <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
          </div>
          <?php else: ?>
          <input name = "payment" type="radio" value = "-1" checked="checked"  style="display:none"/>
          <?php endif; ?> 
        </div>
      </div>
    </section>
    <section class="order_box padd1">
    <?php if ($this->_var['inv_content_list']): ?>
      <div class="title"><?php echo $this->_var['lang']['invoice']; ?></div>
      <div class="table_box table_box2">
        <div class="Info InfoBox"> <span class="text f_l"><?php echo $this->_var['lang']['is_invoice']; ?></span>
          <spam class="f_r selectPayment">
          <span class="modRadio fl" style="margin-top:3px;"> <?php if ($this->_var['order']['need_inv'] == 1): ?><i class="fr"></i> <ins><?php echo $this->_var['lang']['yes']; ?></ins><?php else: ?><i class="fl"></i> <ins><?php echo $this->_var['lang']['no']; ?></ins> </span> </span> <i style="background:#fff;"></i><?php endif; ?> 
           <input id="ECS_NEEDINV" class="input" type="hidden" value="0"  name="need_inv">
        </div>
        <div class="dl_box" id="inviype_box" style="<?php if ($this->_var['order']['need_inv'] == 0): ?>display:none;<?php endif; ?> padding:0 30px 0 10px; border-bottom:1px solid #f3f3f3;"> 
          
          <dl style="line-height: 40px;">
            <dd class="c333"><?php echo $this->_var['lang']['invoice_type']; ?></dd>
            <dd> 
              <?php if ($this->_var['inv_type_list']): ?> 
              <?php echo $this->_var['lang']['invoice_type']; ?>
              <select name="inv_type" id="ECS_INVTYPE"  onchange="changeNeedInv(1)" style="border:1px solid #ccc;">
                    <?php echo $this->html_options(array('options'=>$this->_var['inv_type_list'],'selected'=>$this->_var['order']['inv_type'])); ?>
              </select>
              <?php endif; ?> 
            </dd>
          </dl>
          <dl style="line-height: 40px;">
            <dd class="c333"><?php echo $this->_var['lang']['invoice_title']; ?></dd>
            <dd>
              <input name="inv_payee" type="text"  class="input" id="ECS_INVPAYEE" size="20" value="<?php echo $this->_var['order']['inv_payee']; ?>" onblur="changeNeedInv(1)" />
            </dd>
          </dl>
          <dl style="line-height: 40px;">
            <dd class="c333"> <?php echo $this->_var['lang']['invoice_content']; ?> </dd>
            <dd>
              <select name="inv_content" id="ECS_INVCONTENT"  onchange="changeNeedInv(1)" style="border:1px solid #ccc;">
                

                <?php echo $this->html_options(array('values'=>$this->_var['inv_content_list'],'output'=>$this->_var['inv_content_list'],'selected'=>$this->_var['order']['inv_content'])); ?>
                   
              </select>
            </dd>
          </dl>
          
        </div>
      </div>
      <?php endif; ?> 
    </section>
    <section class="order_box padd1" style="padding:0; border-bottom:1px solid #f3f3f3;">
      <div class="title"><?php echo $this->_var['lang']['use_bonus']; ?></div>
      <div class="table_box table_box2"> 
        
        <?php if ($this->_var['allow_use_bonus']): ?>
        <div class="Info InfoBox">
          <dl style="border:0;">
            <dd class="dd2 selectPayment" id="selected4"><?php echo $this->_var['lang']['no_select']; ?></dd>
            <i class="icon-arr icon-arr-bottom icon-arr-Top"></i>
          </dl>
          <div class="dl_box" id="bonus_box" style="display:none;"> 
           <p>
              <input name="bonus" type="radio" id="bonus_<?php echo $this->_var['bonus']['bonus_id']; ?>" class="radio" value="0" <?php if ($this->_var['order']['bonus_id'] == 0): ?>selected<?php endif; ?> onclick="changeBonus(this)" />
              <label for="bonus_<?php echo $this->_var['bonus']['bonus_id']; ?>"> <?php echo $this->_var['lang']['no_use_bonus']; ?></label>
            </p>
            <?php $_from = $this->_var['bonus_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'bonus');if (count($_from)):
    foreach ($_from AS $this->_var['bonus']):
?>
            <p>
              <input name="bonus" type="radio" id="bonus_<?php echo $this->_var['bonus']['bonus_id']; ?>" class="radio" value="<?php echo $this->_var['bonus']['bonus_id']; ?>"  onclick="changeBonus(this)" />
              <label for="bonus_<?php echo $this->_var['bonus']['bonus_id']; ?>"> <?php echo $this->_var['bonus']['type_name']; ?>[<?php echo $this->_var['bonus']['bonus_money_formated']; ?>]</label>
            </p>
            <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
          </div>
          <?php endif; ?> 
        </div>
      </div>
    </section>
    <section class="order_box padd1" style="padding:0; border-bottom:1px solid #f3f3f3;">
      <div class="title"><?php echo $this->_var['lang']['goods_package']; ?></div>
      <div class="table_box table_box2"> 
        
        <?php if ($this->_var['pack_list']): ?>
        <div class="Info InfoBox">
          <dl style="border:0;">
            <dd class="dd2 selectPayment" id="selected5"><?php echo $this->_var['lang']['no_select']; ?></dd>
            <i class="icon-arr icon-arr-bottom icon-arr-Top"></i>
          </dl>
          <div class="dl_box" id="package_box" style="display:none; border-top:1px solid #f3f3f3;">
            <p>
              <input type="radio" class="radio"  name="pack" id="pack_<?php echo $this->_var['pack']['pack_id']; ?>" value="0" <?php if ($this->_var['order']['pack_id'] == 0): ?>checked="true"<?php endif; ?> onclick="selectPack(this)" style="vertical-align:middle;" />
              <label for="pack_<?php echo $this->_var['pack']['pack_id']; ?>"> <?php echo $this->_var['lang']['no_pack']; ?></label>
            </p>
            <?php $_from = $this->_var['pack_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'pack');if (count($_from)):
    foreach ($_from AS $this->_var['pack']):
?>
            <p>
              <input type="radio" class="radio" name="pack" id="pack_<?php echo $this->_var['pack']['pack_id']; ?>" value="<?php echo $this->_var['pack']['pack_id']; ?>" <?php if ($this->_var['order']['pack_id'] == $this->_var['pack']['pack_id']): ?>checked="true"<?php endif; ?> onclick="selectPack(this)" style="vertical-align:middle;" />
              <label for="pack_<?php echo $this->_var['pack']['pack_id']; ?>"> <?php echo $this->_var['pack']['pack_name']; ?>[<?php echo $this->_var['pack']['format_pack_fee']; ?>]</label>
            </p>
            <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
          </div>
          <?php endif; ?> 
        </div>
      </div>
    </section>
    <section class="order_box padd1" style="padding:0; border-bottom:1px solid #f3f3f3;">
      <div class="title"><?php echo $this->_var['lang']['goods_card']; ?></div>
      <div class="table_box table_box2"> 
        
        <?php if ($this->_var['card_list']): ?>
        <div class="Info InfoBox">
          <dl style="border:0;">
            <dd class="dd2 selectPayment" id="selected6"><?php echo $this->_var['lang']['no_select']; ?></dd>
            <i class="icon-arr icon-arr-bottom icon-arr-Top"></i>
          </dl>
          <div class="dl_box" id="card_box" style="display:none; padding:0px 30px 0px 10px; border-top:1px solid #f3f3f3;">
            <p>
              <input type="radio" class="radio"  name="card" id="card_<?php echo $this->_var['card']['card_id']; ?>" value="0" <?php if ($this->_var['order']['card_id'] == 0): ?>checked="true"<?php endif; ?> onclick="selectCard(this)" style="vertical-align:middle;" />
              <label for="card_<?php echo $this->_var['card']['card_id']; ?>"> <?php echo $this->_var['lang']['no_card']; ?></label>
            </p>
            <?php $_from = $this->_var['card_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'card');if (count($_from)):
    foreach ($_from AS $this->_var['card']):
?>
            <p>
              <input type="radio" class="radio"  name="card"  id="card_<?php echo $this->_var['card']['card_id']; ?>" value="<?php echo $this->_var['card']['card_id']; ?>" <?php if ($this->_var['order']['card_id'] == $this->_var['card']['card_id']): ?>checked="true"<?php endif; ?> onclick="selectCard(this)" style="vertical-align:middle;"  />
              <label for="card_<?php echo $this->_var['card']['card_id']; ?>"> <?php echo $this->_var['card']['card_name']; ?>[<?php echo $this->_var['card']['format_card_fee']; ?>]</label>
            </p>
            <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
          </div>
          <?php endif; ?> 
        </div>
      </div>
    </section>
     <?php if ($this->_var['allow_use_surplus']): ?> 
    <section class="order_box padd1" style="padding:0;">
      <div class="title"><?php echo $this->_var['lang']['use_surplus']; ?></div>
      <div class="table_box table_box2">
        <div class="Info InfoBox">
          <input placeholder="<?php echo $this->_var['lang']['your_surplus']; ?><?php echo empty($this->_var['your_surplus']) ? '0' : $this->_var['your_surplus']; ?>"  id="ECS_SURPLUS" name="surplus" type="text"  onblur="changeSurplus(this.value)" <?php if ($this->_var['disable_surplus']): ?>disabled="disabled"<?php endif; ?> size="20" style=" width:100%; padding:8px 0;"  />
          </dl>
        </div>
      </div>
    </section>
    <?php endif; ?> 
    <?php if ($this->_var['allow_use_integral']): ?> 
     <section class="order_box padd1" style="padding:0;">
      <div class="title"><?php echo $this->_var['lang']['use_integral']; ?></div>
      <div class="table_box table_box2">
        <div class="Info InfoBox">
          <input placeholder="<?php echo $this->_var['lang']['can_use_integral']; ?>:<?php echo empty($this->_var['your_integral']) ? '0' : $this->_var['your_integral']; ?> <?php echo $this->_var['points_name']; ?>，<?php echo $this->_var['lang']['noworder_can_integral']; ?><?php echo $this->_var['order_max_integral']; ?>  <?php echo $this->_var['points_name']; ?>." name="surplus" type="text"  onblur="changeIntegral(this.value)" size="20" style=" width:100%; padding:8px 0;"  />
          </dl>
        </div>
      </div>
    </section> 
    <?php endif; ?> 
    <section class="order_box padd1" style="padding:0;">
      <div class="title"><?php echo $this->_var['lang']['order_postscript']; ?></div>
      <div class="table_box table_box2">
        <div class="Info InfoBox">
          <input placeholder="<?php echo $this->_var['lang']['please_order_postscript']; ?>" name="inv_payee" type="text"   size="20" style=" width:100%; padding:8px 0;"  />
          </dl>
        </div>
      </div>
    </section>
    <section class="order_box padd1 radius10" style="padding-top:0;padding-bottom:0;">
      <div class="title"><?php echo $this->_var['lang']['goods_list']; ?><?php if ($this->_var['allow_edit_cart']): ?><a href="<?php echo url('flow/index');?>" class="modify radius5"><?php echo $this->_var['lang']['modify']; ?></a><?php endif; ?></div>
      <div class="table_box table_box3">
        <div class="Info InfoBox"> 
          <?php $_from = $this->_var['seller_cart']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('idx', 'cart');if (count($_from)):
    foreach ($_from AS $this->_var['idx'] => $this->_var['cart']):
?>
		  <div style="border: #C9C7C7 double 1px;margin-bottom: 5px;padding: 8px;">
		  <?php $_from = $this->_var['cart']['goods_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'goods');if (count($_from)):
    foreach ($_from AS $this->_var['goods']):
?>
          <dl>
            <dd class="dd1 w60"> 
              <?php if ($this->_var['goods']['goods_id'] > 0 && $this->_var['goods']['extension_code'] == 'package_buy'): ?> 
              <a href="javascript:void(0)" onClick="setSuitShow(<?php echo $this->_var['goods']['goods_id']; ?>)" ><?php echo $this->_var['goods']['goods_name']; ?><span style="color:#FF0000;">（<?php echo $this->_var['lang']['remark_package']; ?>）</span></a> 
              <?php else: ?> 
              <a href="<?php echo url('goods/index',array('id'=>$this->_var['goods']['goods_id']));?>" target="_blank" ><?php echo $this->_var['goods']['goods_name']; ?></a> 
              <?php if ($this->_var['goods']['parent_id'] > 0): ?> 
              <span style="color:#FF0000">（<?php echo $this->_var['lang']['accessories']; ?>）</span> 
              <?php elseif ($this->_var['goods']['is_gift']): ?> 
              <span style="color:#FF0000">（<?php echo $this->_var['lang']['largess']; ?>）</span> 
              <?php endif; ?> 
              <?php endif; ?> 
              <?php if ($this->_var['goods']['is_shipping']): ?>(<span style="color:#FF0000"><?php echo $this->_var['lang']['free_goods']; ?></span>)<?php endif; ?> 
            </dd>
            <dd class="dd2 w10 c999"> x <?php echo $this->_var['goods']['goods_number']; ?> </dd>
            <dd class="dd3 w30"> <?php echo $this->_var['goods']['formated_subtotal']; ?> </dd>
          </dl>
		  <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
		  <?php if ($this->_var['cart']['seller']): ?><a style="display: inline;" href="<?php echo Url('sellerstore/index',array('sid'=>$this->_var['cart']['seller']['id']));?>"><?php echo $this->_var['cart']['seller']['shop_name']; ?></a><?php else: ?>网站自营<?php endif; ?>&nbsp;|&nbsp;</span>
            <select name="shipping" onchange="changeShipping(this,<?php echo $this->_var['idx']; ?>);">
            <option value="0" supportCod="0" insure="0">选择配送方式</option>
            <?php $_from = $this->_var['cart']['shippings']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'shipping');if (count($_from)):
    foreach ($_from AS $this->_var['shipping']):
?>
            <option value="<?php echo $this->_var['shipping']['shipping_id']; ?>" supportCod="<?php echo $this->_var['shipping']['support_cod']; ?>" insure="<?php echo $this->_var['shipping']['insure']; ?>"><?php echo $this->_var['shipping']['shipping_name']; ?>&nbsp;<?php if ($this->_var['shipping']['shipping_fee'] > 0): ?><?php echo $this->_var['shipping']['format_shipping_fee']; ?><?php else: ?>免邮<?php endif; ?></option>
            <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
            </select>&nbsp;<input type="checkbox" value="0" onclick="select_Insure(this.checked,<?php echo $this->_var['idx']; ?>)" id="ECS_NEEDINSURE_<?php echo $this->_var['idx']; ?>" name="need_insure" disabled="true" style="display:none">
			

		  
			
		  <?php if ($this->_var['cart']['wheat_coin'] > 0): ?>
		  <dl>
            <dd class="dd1 w60"> 
              <input type="checkbox" name="use_coin" onclick="select_Coin(this.checked,'coin_<?php echo $this->_var['idx']; ?>',<?php echo $this->_var['idx']; ?>)"/>使用商城券<input type="text" value="0" disabled="true" id="coin_<?php echo $this->_var['idx']; ?>" onkeyup="change_coin(this,this.value,<?php echo $this->_var['cart']['wheat_coin']; ?>,'coin_f<?php echo $this->_var['idx']; ?>',<?php echo $this->_var['idx']; ?>);"  size="5"/>(您有<?php echo $this->_var['user_wheat_coin']; ?>个商城券，此处最多可用<?php echo $this->_var['cart']['wheat_coin']; ?>个)&nbsp;&nbsp;<font id="coin_f<?php echo $this->_var['idx']; ?>" style="font-weight:bold; font-size:14px;">￥- 0.00</font>
            </dd>
          </dl>
		  <?php endif; ?>
		  </div>
          <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
        </div>
        <div class="totle"> <span class="bg-border"><span class="icon"></span></span>
          <div class="InfoBox"><?php echo $this->fetch('library/order_total.lbi'); ?></div>
          <span class="bg-border2"></span> </div>
      </div>
    </section>
    <div class="InfoBox" style="padding:0 10px;">
      <input type="submit" name="submit" value="<?php echo $this->_var['lang']['order_submit']; ?>" class="c-btn3" />
      <input type="hidden" name="step" value="done" />
    </div>
  </form>
</section>
<script type="text/javascript">
function select_Coin(is_coin,coin_name,seller_id)
{
	if(is_coin)
	{
		document.getElementById(coin_name).disabled = false;
		document.getElementById(coin_name).focus();
	}
	else
	{
		document.getElementById(coin_name).disabled = true;
		document.getElementById(coin_name).value=0;
		document.getElementById(coin_name).blur();
		$.get("<?php echo url('flow/use_coin');?>", {sub_coin: 0,seller_id:seller_id}, function(data) {orderShippingSelectedResponse(data);}, 'json');
	}
}
function change_coin(obj,coin,max_coin,coin_font,seller_id)
{
	if(coin><?php echo $this->_var['user_wheat_coin']; ?>)
	{
		alert('您没有足够的商城券');
		obj.value=0;	
		document.getElementById(coin_font).innerHTML='￥ - 0.00';
		$.get("<?php echo url('flow/use_coin');?>", {sub_coin: 0,seller_id:seller_id}, function(data) {orderShippingSelectedResponse(data);}, 'json');
		return;
	}
	else if(coin>max_coin)
	{
		alert('您购买的物品只能用'+max_coin+'个以内的商城券');
		obj.value=0;
		document.getElementById(coin_font).innerHTML='￥ - 0.00';
		$.get("<?php echo url('flow/use_coin');?>", {sub_coin: 0,seller_id:seller_id}, function(data) {orderShippingSelectedResponse(data);}, 'json');
		return;
	}
	else if(coin<0||(coin.indexOf('.')>=0)||!parseInt(coin))
	{
		alert('商城券的个数必须为大于等于0的整数');
		obj.value=0;
		document.getElementById(coin_font).innerHTML='￥ - 0.00';
		$.get("<?php echo url('flow/use_coin');?>", {sub_coin: 0,seller_id:seller_id}, function(data) {orderShippingSelectedResponse(data);}, 'json');
		return;
	}
	else
	{
		var sub_coin=(coin*<?php echo $this->_var['wheat_coin_v']; ?>);
		document.getElementById(coin_font).innerHTML='￥ - '+sub_coin.toFixed(2);
		$.get("<?php echo url('flow/use_coin');?>", {sub_coin: sub_coin,seller_id:seller_id}, function(data) {orderShippingSelectedResponse(data);}, 'json');
		
	}
}
</script>