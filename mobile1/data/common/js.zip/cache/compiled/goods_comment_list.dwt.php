<?php echo $this->fetch('library/page_header.lbi'); ?>
<header id="header">
  <div class="header_l header_return"> <a onclick="javascript:history.go(-1);"><span></span></a></div>
  <h1><?php echo $this->_var['lang']['goods_comment']; ?></h1>
  <div class="header_r header_search"> <a class="new-a-jd" onClick="showSearch()"></a></div>
  <div id="search_box">
    <?php echo $this->fetch('library/page_menu.lbi'); ?>
  </div>
</header>
<div class="s-detail" id="ECS_COMMENT">
<?php echo $this->fetch('library/comments.lbi'); ?>
</div>
<div class="blank"></div>
<?php echo $this->fetch('library/page_footer.lbi'); ?>
</body>
</html>