<?php echo $this->fetch('library/page_header.lbi'); ?>
<header id="header">
  <div class="header_l header_return"> <a onclick="javascript:history.go(-1);"><span></span></a></div>
  <h1> <?php echo $this->_var['lang']['label_message']; ?> </h1>
</header>
<div class="InfoBox">
  <section class="wrap message_list" style="border-bottom:0;">
    <section id="J_ItemList">
      <section class="order_box padd1 radius10 single_item"> </section>
      <a href="javascript:;" style="text-align:center" class="get_more"></a> </section>
    <section class="order_box padd1 radius10">
      <form action="<?php echo url('user/service');?>" method="post" enctype="multipart/form-data" name="formMsg" onSubmit="return submitMsg()">
        <table width="100%" border="0" cellpadding="5" cellspacing="0" class="ectouch_table">
          <?php if ($this->_var['order_info']): ?>
          <tr>
            <td> <?php echo $this->_var['lang']['order_number']; ?> <a href ="<?php echo $this->_var['order_info']['url']; ?>"><img src="themes//images/note.gif" /><?php echo $this->_var['order_info']['order_sn']; ?></a>
              <input name="msg_type" type="hidden" value="5" />
              <input name="order_id" type="hidden" value="<?php echo $this->_var['order_info']['order_id']; ?>" class="inputBg_touch" /></td>
          </tr>
          <?php else: ?>
          <tr>
            <td style="padding:5px 0;"><input name="msg_type" type="radio" value="0" checked="checked" />
              <?php echo $this->_var['lang']['type']['0']; ?>
              <input type="radio" name="msg_type" value="1" />
              <?php echo $this->_var['lang']['type']['1']; ?>
              <input type="radio" name="msg_type" value="2" />
              <?php echo $this->_var['lang']['type']['2']; ?>
              <input type="radio" name="msg_type" value="3" />
              <?php echo $this->_var['lang']['type']['3']; ?>
              <input type="radio" name="msg_type" value="4" />
              <?php echo $this->_var['lang']['type']['4']; ?> </td>
          </tr>
          <?php endif; ?>
          <tr>
            <td style="padding:5px 0;"><input name="msg_title" type="text" placeholder="<?php echo $this->_var['lang']['message_title']; ?>" class="inputBg_touch" style="width:99%;" /></td>
          </tr>
          <tr>
            <td style="padding:5px 0;"><textarea name="msg_content" placeholder="<?php echo $this->_var['lang']['message_content']; ?>" cols="50" rows="4" wrap="virtual" style="border: 1px #DDD solid; width: 99%;"></textarea></td>
          </tr>
          <tr>
            <td style="padding:5px 0;"><input type="hidden" name="act" value="act_add_message" />
              <input type="submit" value="<?php echo $this->_var['lang']['submit']; ?>" class="c-btn4" /></td>
          </tr>
        </table>
      </form>
    </section>
  </section>
</div>
<?php echo $this->fetch('library/page_footer.lbi'); ?> 
<script type="text/javascript">
get_asynclist('<?php echo url("user/msg_list");?>' , '__TPL__/images/loader.gif');
</script>
</body></html>