<?php echo $this->fetch('library/page_header.lbi'); ?>
<header id="header">
  <div class="header_l header_return"> <a onclick="javascript:history.go(-1);"><span></span></a></div>
  <h1> <?php echo $this->_var['lang']['consignee_info']; ?> </h1>
</header>
<section class="wrap" style="border-bottom:0;">
  <div class="InfoBox" id="J_ItemList"> 
    <section class="order_box padd1 radius10 single_item" >
    </section>
    <a href="javascript:;" class="get_more"></a>  
    <a href="<?php echo url('user/add_address');?>" class="c-btn4"><?php echo $this->_var['lang']['add_address']; ?></a> </div>
</section>
<?php echo $this->fetch('library/page_footer.lbi'); ?> 
<script type="text/javascript">
get_asynclist('<?php echo url("user/address_list");?>' , '__TPL__/images/loader.gif');
</script> 
