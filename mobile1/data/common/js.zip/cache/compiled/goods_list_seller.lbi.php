<div class="filter" style="position: static;  top: 0px;  width:100%;    ">
  <form method="GET" class="sort" name="listform">
    <ul class="filter-inner">
        <li class="<?php if ($this->_var['sort'] == 'goods_id' && $this->_var['order'] == 'DESC'): ?>filter-cur<?php endif; ?>"><a href="<?php echo url('Sellergoods/index',array('id'=>$this->_var['id'],'sid'=>$this->_var['store']['id'],'display'=>$this->_var['display'],'brand'=>$this->_var['brand_id'],'price_min'=>$this->_var['price_min'],'price_max'=>$this->_var['price_max'],'filter_attr'=>$this->_var['filter_attr'], 'sort'=>'goods_id', 'order'=> 'DESC', 'keywords'=>$this->_var['keywords']));?>"><span class="new-bar"></span><span class="new-icon-down"></span><?php echo $this->_var['lang']['sort_default']; ?></a></li>
      <li class="<?php if ($this->_var['sort'] == 'click_count' && $this->_var['order'] == 'DESC'): ?>filter-cur<?php elseif ($this->_var['sort'] == 'click_count' && $this->_var['order'] == 'ASC'): ?>filter-cur<?php endif; ?>"><a href="<?php echo url('Sellergoods/index',array('id'=>$this->_var['id'],'sid'=>$this->_var['store']['id'],'display'=>$this->_var['display'],'brand'=>$this->_var['brand_id'],'price_min'=>$this->_var['price_min'],'price_max'=>$this->_var['price_max'],'filter_attr'=>$this->_var['filter_attr'], 'sort'=>'click_count', 'order'=> ($this->_var['sort']=='click_count' && $this->_var['order']=='ASC')?'DESC':'ASC', 'keywords'=>$this->_var['keywords']));?>"><span class="new-bar"></span><span class="new-icon-down"></span><?php echo $this->_var['lang']['sort_popularity']; ?></a></li>
      <li class="<?php if ($this->_var['sort'] == 'sales_volume' && $this->_var['order'] == 'DESC'): ?>filter-cur<?php elseif ($this->_var['sort'] == 'sales_volume' && $this->_var['order'] == 'ASC'): ?>filter-cur<?php endif; ?>"> <a href="<?php echo url('Sellergoods/index',array('id'=>$this->_var['id'],'sid'=>$this->_var['store']['id'],'display'=>$this->_var['display'],'brand'=>$this->_var['brand_id'],'price_min'=>$this->_var['price_min'],'price_max'=>$this->_var['price_max'],'filter_attr'=>$this->_var['filter_attr'], 'sort'=>'sales_volume', 'order'=> ($this->_var['sort']=='sales_volume' && $this->_var['order']=='ASC')?'DESC':'ASC', 'keywords'=>$this->_var['keywords']));?>"><span class="new-bar"></span><span class="new-icon-down"></span><?php echo $this->_var['lang']['sort_sales']; ?></a></li>
      <li class="<?php if ($this->_var['sort'] == 'shop_price' && $this->_var['order'] == 'DESC'): ?>filter-cur<?php elseif ($this->_var['sort'] == 'shop_price' && $this->_var['order'] == 'ASC'): ?>filter-cur<?php endif; ?>"><a href="<?php echo url('Sellergoods/index',array('id'=>$this->_var['id'],'sid'=>$this->_var['store']['id'],'display'=>$this->_var['display'],'brand'=>$this->_var['brand_id'],'price_min'=>$this->_var['price_min'],'price_max'=>$this->_var['price_max'],'filter_attr'=>$this->_var['filter_attr'], 'sort'=>'shop_price', 'order'=> ($this->_var['sort']=='shop_price' && $this->_var['order']=='ASC')?'DESC':'ASC', 'keywords'=>$this->_var['keywords']));?>"><span class="new-bar"></span><span class="new-icon-down"></span><?php echo $this->_var['lang']['sort_price']; ?> <?php if ($this->_var['sort'] == 'shop_price' && $this->_var['order'] == 'ASC'): ?>↑<?php endif; ?>
        <?php if ($this->_var['sort'] == 'shop_price' && $this->_var['order'] == 'DESC'): ?>↓<?php endif; ?></a> </li>
      <!--<li class="filter-navBtn"><a href="javascript:;" class="j_filterBtn disabled" id="btn_filter" f="1"><span class="new-bar"></span>筛选<span class="RightSanjiao"></span></a></li>-->
    </ul>
    <input type="hidden" name="cid" value="<?php echo $this->_var['category']; ?>" />
    <input type="hidden" name="display" value="<?php echo $this->_var['display']; ?>" id="display" />
    <input type="hidden" name="brand" value="<?php echo $this->_var['brand_id']; ?>" />
    <input type="hidden" name="price_min" value="<?php echo $this->_var['price_min']; ?>" />
    <input type="hidden" name="price_max" value="<?php echo $this->_var['price_max']; ?>" />
    <input type="hidden" name="filter_attr" value="<?php echo $this->_var['filter_attr']; ?>" />
    <input type="hidden" name="page" value="<?php echo $this->_var['page']; ?>" />
    <input type="hidden" name="sort" value="<?php echo $this->_var['sort']; ?>" />
    <input type="hidden" name="order" value="<?php echo $this->_var['order']; ?>" />
  </form> 
</div>
<div class="GoodsList" id="J_ItemList" style="opacity:1;"> 
  <div class="product flex_in single_item GoodsListBox">
  </div>
  <a href="javascript:;" class="get_more"></a> 
</div>