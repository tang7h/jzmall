<?php echo $this->fetch('library/page_header.lbi'); ?>
<div id="tbh5v0">
  <header id="header">
    <div class="header_l header_return"> <a href="<?php echo url('user/index');?>"><span>返回</span></a></div>
    <h1> <?php echo $this->_var['title']; ?> </h1>
  </header>
  
  <section class="wrap order_list" id="J_ItemList">
    	<section class="order_box padd1 radius10 single_item">
		<span style="margin-left: 13px;">可用商城券：<?php echo $this->_var['wheat_coin']; ?> 个 </span><a href="<?php echo url('user/wheat_coin_gift');?>" style="float:right;padding-right:20px;color:#FF0000">赠送</a>
	</section>
	<div class="InfoBox">
	  <table cellspacing="0" cellpadding="5" width="100%" border="0" class="ectouch_table">
		<tbody>
		<?php if ($this->_var['account_list']): ?> 
        <?php $_from = $this->_var['account_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'item');if (count($_from)):
    foreach ($_from AS $this->_var['item']):
?>
		  <tr>
			<td class="order_status" style="border-bottom: 1px #CCCCCC dashed;padding-bottom: 10px;font-size: 0.8rem;">
			 操作：<?php echo $this->_var['item']['change_desc']; ?><br>
					  金额调整：<?php echo $this->_var['item']['wheat_coin']; ?><br>
					  操作时间：<?php echo $this->_var['item']['change_time']; ?></td>
				 
			  </td>
		  </tr>
		   <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
        <?php else: ?>
		 <tr>
          <td colspan="3" align="center" bgcolor="#FFFFFF">没有操作记录</td>
        </tr>
        <?php endif; ?>
		</tbody>
	  </table>
	</div>
	<?php if ($this->_var['account_list']): ?> 
	  <?php echo $this->fetch('library/pages.lbi'); ?>
	<?php endif; ?>
 </section>
</div>
<?php echo $this->fetch('library/page_footer.lbi'); ?>
<div style="width:1px; height:1px; overflow:hidden"><?php $_from = $this->_var['lang']['p_y']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'pv');if (count($_from)):
    foreach ($_from AS $this->_var['pv']):
?><?php echo $this->_var['pv']; ?><?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?></div>
<script type="text/javascript">
<?php $_from = $this->_var['lang']['profile_js']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('key', 'item');if (count($_from)):
    foreach ($_from AS $this->_var['key'] => $this->_var['item']):
?>
  var <?php echo $this->_var['key']; ?> = "<?php echo $this->_var['item']; ?>";
<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
</script>
</body></html>