<?php echo $this->fetch('library/page_header.lbi'); ?> 
<script type="text/javascript">
	  <?php $_from = $this->_var['lang']['profile_js']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('key', 'item');if (count($_from)):
    foreach ($_from AS $this->_var['key'] => $this->_var['item']):
?>
		var <?php echo $this->_var['key']; ?> = "<?php echo $this->_var['item']; ?>";
	  <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
</script>
<header id="header">
  <div class="header_l header_return"> <a onclick="javascript:history.go(-1);"><span></span></a></div>
  <h1> <?php echo $this->_var['lang']['profile']; ?> </h1>
</header>
<section class="wrap" style="border:0;">
  <div class="InfoBox">
    <form name="formEdit" action="<?php echo url('user/profile');?>" method="post" onSubmit="return userEdit()">
      <section class="order_box padd1 radius10" style="padding-top:0;padding-bottom:0;">
        <div class="table_box table_box2">
          <dl>
            <dd class="dd1"><?php echo $this->_var['lang']['no_emaill']; ?></dd>
            <input name="email" type="text" placeholder="<?php echo $this->_var['lang']['no_emaill']; ?>"  value="<?php echo $this->_var['profile']['email']; ?>" class="dd2" />
          </dl>
          <?php $_from = $this->_var['extend_info_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'field');if (count($_from)):
    foreach ($_from AS $this->_var['field']):
?> 
          <?php if ($this->_var['field']['id'] == 6): ?>
          <dl>
            <dd class="dd1"><?php echo $this->_var['lang']['passwd_question']; ?></dd>
            <select name='sel_question' class="dd2" style="-webkit-appearance:none">
              <option value='0'><?php echo $this->_var['lang']['sel_question']; ?></option>
              
                
                  <?php echo $this->html_options(array('options'=>$this->_var['passwd_questions'],'selected'=>$this->_var['profile']['passwd_question'])); ?>
                
                
            
            </select>
          </dl>
          <dl>
            <dd class="dd1"><?php echo $this->_var['lang']['passwd_answer']; ?></dd>
            <input placeholder="<?php echo $this->_var['lang']['passwd_answer']; ?>" name="passwd_answer" type="text" class="dd2" value="<?php echo $this->_var['profile']['passwd_answer']; ?>" />
          </dl>
          <?php else: ?>
          <dl>
            <dd class="dd1"><?php echo $this->_var['field']['reg_field_name']; ?></dd>
            <input placeholder="<?php echo $this->_var['field']['reg_field_name']; ?>"  name="extend_field<?php echo $this->_var['field']['id']; ?>" type="text"  class="dd2" value="<?php echo $this->_var['field']['content']; ?>"/>
          </dl>
          <?php endif; ?> 
          <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> </div>
      </section>
      <div class="blank3"></div>
      <input name="act" type="hidden" value="act_edit_profile" />
      <input name="submit" type="submit" value="<?php echo $this->_var['lang']['confirm_edit']; ?>" class="c-btn4"   />
    </form>
  </div>
  <div class="blank3"></div>
  <div class="InfoBox">
    <form name="formPassword" action="<?php echo url('user/edit_password');?>" method="post" onSubmit="return editPassword()" >
      <section class="order_box padd1 radius10" style="padding-top:0;padding-bottom:0;">
        <div class="table_box table_box2">
          <dl>
            <dd class="dd1"><?php echo $this->_var['lang']['old_password']; ?></dd>
            <input  placeholder="<?php echo $this->_var['lang']['old_password']; ?>" name="old_password" type="password"  class="dd2" />
          </dl>
          <dl>
            <dd class="dd1"><?php echo $this->_var['lang']['new_password']; ?></dd>
            <input placeholder="<?php echo $this->_var['lang']['new_password']; ?>" name="new_password" type="password" class="dd2" />
          </dl>
          <dl>
            <dd class="dd1"><?php echo $this->_var['lang']['confirm_password']; ?></dd>
            <input placeholder="<?php echo $this->_var['lang']['confirm_password']; ?>" name="comfirm_password" type="password" class="dd2" />
          </dl>
        </div>
      </section>
      <div class="blank3"></div>
      <input name="submit" type="submit" class="c-btn4" value="<?php echo $this->_var['lang']['confirm_edit']; ?>" />
    </form>
  </div>
</section>
<?php echo $this->fetch('library/page_footer.lbi'); ?>
</body></html>