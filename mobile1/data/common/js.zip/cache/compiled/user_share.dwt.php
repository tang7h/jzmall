<?php echo $this->fetch('library/page_header.lbi'); ?>
<header id="header">
  <div class="header_l header_return"> <a onclick="javascript:history.go(-1);"><span></span></a></div>
  <h1> <?php echo $this->_var['lang']['label_message']; ?> </h1>
</header>
<?php if ($this->_var['share']['on'] == 1): ?> 
<?php if (! $this->_var['goodsid'] || $this->_var['goodsid'] == 0): ?>
<div class="InfoBox">
  <section class="order_box padd1 radius10 single_item">
    <table width="100%" border="0" cellpadding="1" cellspacing="0" class="ectouch_table">
      <tr align="left">
        <td style="padding:5px 0;"><?php echo $this->_var['affiliate_intro']; ?></td>
      </tr>
    </table>
  </section>
  <section class="order_box padd1 radius10 single_item">
    <table width="100%" border="0" cellpadding="5" cellspacing="0" class="ectouch_table">
      <tr align="center">
        <td style="padding:5px 0;"><?php echo $this->_var['lang']['affiliate_lever']; ?></td>
        <td><?php echo $this->_var['lang']['affiliate_num']; ?></td>
        <td><?php echo $this->_var['lang']['level_point']; ?></td>
        <td><?php echo $this->_var['lang']['level_money']; ?></td>
      </tr>
      <?php $_from = $this->_var['affdb']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('level', 'val');$this->_foreach['affdb'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['affdb']['total'] > 0):
    foreach ($_from AS $this->_var['level'] => $this->_var['val']):
        $this->_foreach['affdb']['iteration']++;
?>
      <tr align="center">
        <td><?php echo $this->_var['level']; ?></td>
        <td><?php echo $this->_var['val']['num']; ?></td>
        <td><?php echo $this->_var['val']['point']; ?></td>
        <td><?php echo $this->_var['val']['money']; ?></td>
      </tr>
      <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
    </table>
  </section>
  <section class="order_box padd1 radius10 single_item"> 
      <table width="100%" border="0" cellpadding="5" cellspacing="1" bgcolor="#dddddd" class="u-table">
    <tr>
        <td >
        	<div class="bdsharebuttonbox" data-tag="share_1" style="width:12em;margin:0 auto;">
				<a class="bds_qzone" data-cmd="qzone" href="#"></a>
				<a class="bds_tsina" data-cmd="tsina"></a>
				<a class="bds_bdhome" data-cmd="bdhome"></a>
				<a class="bds_renren" data-cmd="renren"></a>
			</div>
        </td>
    </tr>
  </table>
    <table width="100%" border="0" cellpadding="5" cellspacing="0" class="ectouch_table">
      <tr align="center">
        <td style="padding:5px 0;">推荐代码：<a href="<?php echo $this->_var['shopurl']; ?>?u=<?php echo $this->_var['userid']; ?>" target="_blank" class="f6" style="line-height:1.5;"><?php echo $this->_var['shopname']; ?></a> 可调用在线分享</td>
      </tr>
    </table>
   
  </section>
</div>
<?php endif; ?> 
<?php endif; ?> 
<script>
	window._bd_share_config = {
		common : {
			bdText : '<?php echo $this->_var['shopdesc']; ?>',
			bdUrl : '<?php echo $this->_var['shopurl']; ?>',
			bdPic : '<?php echo $this->_var['shopurl_qr']; ?>'
		},
		share : [{
			"bdSize" : 32
		}]
	}
	with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?cdnversion='+~(-new Date()/36e5)];
</script>
<?php echo $this->fetch('library/page_footer.lbi'); ?> 
</body></html>