<?php echo $this->fetch('library/page_header.lbi'); ?>
<div id="page">
  <header id="header">
    <div class="header_l header_return"> <a onClick="javascript:history.go(-1);"><span></span></a></div>
    <h1><?php echo $this->_var['lang']['shopping_cart']; ?></h1>
    <div class="header_r header_search"> <a class="new-a-jd" onClick="showSearch()"><span></span></a></div>
    <div id="search_box">
      <?php echo $this->fetch('library/page_menu.lbi'); ?> </div>
     </div>
  </header>
</div>
<slidercontent>
  <div style="display:block;color:red;margin-top:0.5em;margin-left:0.5em" id="errorMessage" class="err_msg"></div>
  <div class="new-ct" id="J_ItemList">
      <div class="addr-add"> <a class="btn-addr" href="<?php echo url('flow/consignee');?>">+<?php echo $this->_var['lang']['add_address']; ?></a> </div>
      <div style="display:block;color:red;margin-bottom:0.5em;margin-top:0.5em;" id="errorMessage" class="err_msg"></div>
      <div class="addr-info single_item"></div>
      <a href="javascript:;" style="text-align:center" class="get_more"></a>
  </div>
</slidercontent>
<?php echo $this->fetch('library/page_footer.lbi'); ?> 
<script type="text/javascript" src="__PUBLIC__/js/jquery.more.js"></script> 
<script type="text/javascript">
get_asynclist("<?php echo url('flow/consignee_list');?>" , '__TPL__/images/loader.gif');
</script>
</body></html>