<?php echo $this->fetch('library/page_header.lbi'); ?>
<div id="page" style="right: 0px; left: 0px; display: block;">
  <header id="header">
    <div class="header_l header_return"> <a onClick="javascript:history.go(-1);"><span></span></a></div>
    <h1><?php echo $this->_var['lang']['activity_list']; ?></h1>
    <div class="header_r header_search"> <a class="new-a-jd" onClick="showSearch()"><span></span></a></div>
    <div id="search_box">
      <?php echo $this->fetch('library/page_menu.lbi'); ?>
  </div>
  </header>
  <section class="order_box padd1 radius10 single_item">
    <div class="ActList "> 
       <ul id="J_ItemList" >
   	     <li class="single_item"></li>
         <a href="javascript:;" class="get_more"></a>
    	<ul>
    </div>
  </section>
  <?php echo $this->fetch('library/page_footer.lbi'); ?> </div>
<script type="text/javascript">
get_asynclist("<?php echo url('activity/asynclist', array('page'=>$this->_var['page'], 'sort'=>$this->_var['sort'], 'order'=>$this->_var['order']));?>" , '__TPL__/images/loader.gif');
</script> 
</body></html>
</body>
</html>