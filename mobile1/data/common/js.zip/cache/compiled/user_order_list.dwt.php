<?php echo $this->fetch('library/page_header.lbi'); ?>
<header id="header">
  <div class="header_l header_return"> <a onclick="javascript:history.go(-1);"><span></span></a></div>
  <h1> <?php echo $this->_var['lang']['label_order']; ?> </h1>
</header>
<section class="wrap order_list" id="J_ItemList">
  <section class="order_box padd1 radius10 single_item">
  </section>
  <a href="javascript:;" class="get_more"></a> </section>
  <?php echo $this->fetch('library/page_footer.lbi'); ?>
<script type="text/javascript">
<?php $_from = $this->_var['lang']['merge_order_js']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('key', 'item');if (count($_from)):
    foreach ($_from AS $this->_var['key'] => $this->_var['item']):
?>
        var <?php echo $this->_var['key']; ?> = "<?php echo $this->_var['item']; ?>";
<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
get_asynclist("<?php echo url('user/async_order_list',array('pay'=>$this->_var['pay']));?>" , '__TPL__/images/loader.gif');
</script>
</body></html>