<section class="list-pagination">
<?php if ($this->_var['page']['styleid'] == 0): ?>
    <div class="pagenav-wrapper" id="J_PageNavWrap" style="">
      <div class="pagenav-content">
        <div class="pagenav new-tbl-type" id="J_PageNav">
          <div class="<?php if ($this->_var['page']['page_first']): ?>p-first<?php else: ?>p-prev p-gray<?php endif; ?> new-tbl-type" > 
              <?php if ($this->_var['page']['page_first']): ?>
              <a href="<?php echo $this->_var['page']['page_first']; ?>">首页</a>
              <?php else: ?>
               <a  class="no">首页</a> 
              <?php endif; ?>
          </div>
          <div class="<?php if ($this->_var['page']['page_prev']): ?>p-prev<?php else: ?>p-prev p-gray<?php endif; ?>">  
              <?php if ($this->_var['page']['page_prev']): ?>
              <a href="<?php echo $this->_var['page']['page_prev']; ?>" >&lt;上一页</a>
              <?php else: ?>
              <a class="no">&lt;上一页</a>   
              <?php endif; ?>
          </div>
          <div class="pagenav-cur">
            <div class="pagenav-text"> <span><?php echo $this->_var['page']['page']; ?>/<?php echo $this->_var['page']['page_count']; ?></span> <i></i> </div>
            <select name="page" class="pagenav-select" onchange="window.location.href=this.options[this.selectedIndex].value" >
            <?php if ($this->_var['page']['page_number']): ?>
            <?php $_from = $this->_var['page']['page_number']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('key', 'item_0_04031600_1419406053');if (count($_from)):
    foreach ($_from AS $this->_var['key'] => $this->_var['item_0_04031600_1419406053']):
?>
              <option value="<?php echo $this->_var['item_0_04031600_1419406053']; ?>" <?php if ($this->_var['page']['page'] == $this->_var['key']): ?>selected=true<?php endif; ?>><?php echo $this->_var['key']; ?></option>
            <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
            <?php endif; ?>
            </select>
          </div>
          <div class="<?php if ($this->_var['page']['page_next']): ?>p-next<?php else: ?>p-next p-gray<?php endif; ?>" > 
          	<?php if ($this->_var['page']['page_next']): ?>
              <a  href="<?php echo $this->_var['page']['page_next']; ?>" >下一页&gt;</a>
              <?php else: ?>
              <a class="no">下一页&gt;</a> 
              <?php endif; ?>
          </div>
          <div class="<?php if ($this->_var['page']['page_last']): ?>p-end<?php else: ?>p-end p-gray<?php endif; ?>" >
           <?php if ($this->_var['page']['page_last']): ?>
           <a href="<?php echo $this->_var['page']['page_last']; ?>"><?php echo $this->_var['lang']['page_last']; ?></a>
           <?php else: ?>
           <a class="no">末页</a> 
           <?php endif; ?>
           </div>
        </div>
      </div>
    </div>


<?php else: ?>

<div class="pagenav-wrapper" id="J_PageNavWrap" style="float:right">
    <div class="pagenav" id="J_PageNav" style="display:flex; text-align:center; ">
    <span class="" style="margin-right:10px;line-height:2.5em;height:2.5em;"><?php echo $this->_var['lang']['pager_1']; ?><b><?php echo $this->_var['page']['record_count']; ?></b> <?php echo $this->_var['lang']['pager_2']; ?></span>
    <?php if ($this->_var['page']['page_first']): ?><div class="p-prev"><a href="<?php echo $this->_var['page']['page_first']; ?>"><?php echo $this->_var['lang']['page_first']; ?> ...</a></div><?php endif; ?>
    <?php if ($this->_var['page']['page_prev']): ?><div class="p-prev"><a class="prev" href="<?php echo $this->_var['page']['page_prev']; ?>"><?php echo $this->_var['lang']['page_prev']; ?></a></div><?php endif; ?>
    <?php if ($this->_var['page']['page_count'] != 1): ?>
      <?php $_from = $this->_var['page']['page_number']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('key', 'item_0_04168600_1419406053');if (count($_from)):
    foreach ($_from AS $this->_var['key'] => $this->_var['item_0_04168600_1419406053']):
?>
        <?php if ($this->_var['page']['page'] == $this->_var['key']): ?>
        <div class="p-prev " style="background:none;cursor:default;"><a class="page_now"><?php echo $this->_var['key']; ?></a></div>
        <?php else: ?>
        <div class="p-prev"><a href="<?php echo $this->_var['item_0_04168600_1419406053']; ?>"><?php echo $this->_var['key']; ?></a></div>
        <?php endif; ?>
      <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
    <?php endif; ?>

    <?php if ($this->_var['page']['page_next']): ?><div class="p-prev"><a class="next" href="<?php echo $this->_var['page']['page_next']; ?>"><?php echo $this->_var['lang']['page_next']; ?></a></div><?php endif; ?>
    <?php if ($this->_var['page']['page_last']): ?><div class="p-prev"><a class="last" href="<?php echo $this->_var['page']['page_last']; ?>">...<?php echo $this->_var['lang']['page_last']; ?></a></div><?php endif; ?>
    </div>
</div>
<div class="blank1"></div>
<?php endif; ?>
</section>