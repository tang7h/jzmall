<?php echo $this->fetch('library/page_header.lbi'); ?>
<div id="page">
  <header id="header">
  <div class="header_l header_return"> <a href="javascript:history.go(-1);"><span></span></a></div>
  <h1><?php echo $this->_var['lang']['user_center']; ?></h1>
  <div class="header_r header_search"> <a class="new-a-jd" onClick="showSearch()"><span></span></a></div>
  <div id="search_box">
    <?php echo $this->fetch('library/page_menu.lbi'); ?>
  </div>
</header>
</div>
<div class="new-ct">
	<div class="new-user-infobox">
    	<a class="new-user-photo"><img  src="__TPL__/images/get_avatar.png"></a>
        <div class="new-bg-img">
        	<div class="new-user-info">
            	<div style="padding-left:90px;">
            	<div class="new-info-tbl new-txt">
                	<span class="new-tbl-cell"><span class="fs13"><?php echo $this->_var['info']['username']; ?></span><span><?php echo $this->_var['rank_name']; ?></span></span>
                    <span class="new-tbl-cell"><span class="fs13"><?php echo $this->_var['info']['integral']; ?></span><span><?php echo $this->_var['lang']['exchange_integral']; ?></span></span>
                    <span class="new-tbl-cell"><span></span><span></span></span>
                </div>
            </div>
            </div>
        </div>
        <div class="new-user-info2">
        	<div class="new-info-tbl-box">
            	<div class="new-info-tbl">
                	<a class="new-tbl-cell" href="<?php echo url('user/order_list');?>"><span><?php echo $this->_var['info']['order_count']; ?></span><span><?php echo $this->_var['lang']['order_list_lnk']; ?></span></a>
                    <a class="new-tbl-cell" href="javascript:;"><span><?php echo $this->_var['info']['surplus']; ?></span><span><?php echo $this->_var['lang']['balance']; ?></span></a>
                    <a class="new-tbl-cell" href="<?php echo url('user/bonus');?>"><span><?php echo $this->_var['info']['bonus']; ?></span><span><?php echo $this->_var['lang']['your_bonus']; ?></span></a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="blank3"></div>
<section class="wrap InfoBox" style="border-bottom:0;">
  <div class="list_box" style="padding-top:0;padding-bottom:0; border:1px solid #999; border-top:0;">
  	<a href="<?php echo url('user/profile');?>" class="clearfix"><span><?php echo $this->_var['lang']['label_profile']; ?></span><i></i></a>
    <a href="<?php echo url('user/order_list');?>" class="clearfix"><span><?php echo $this->_var['lang']['label_order']; ?></span><i></i></a>
    <a href="<?php echo url('user/address_list');?>" class="clearfix"><span><?php echo $this->_var['lang']['label_address']; ?></span><i></i></a>
    <a href="<?php echo url('user/collection_list');?>" class="clearfix"><span><?php echo $this->_var['lang']['label_collection']; ?></span><i></i></a>
  </div>
  <div class="blank3"></div>
  <div class="list_box" style="padding-top:0;padding-bottom:0; border:1px solid #999; border-top:0;">
  	<a href="<?php echo url('user/service');?>" class="clearfix"><span><?php echo $this->_var['lang']['label_message']; ?></span><i></i></a>
    <a href="<?php echo url('user/share');?>" class="clearfix"><span><?php echo $this->_var['lang']['label_share']; ?></span><i></i></a>
    <a href="<?php echo url('user/comment_list');?>" class="clearfix"><span><?php echo $this->_var['lang']['label_comment']; ?></span><i></i></a>
	<a href="<?php echo url('user/wheat_coin');?>" class="clearfix"><span>商城券</span><i></i></a>
  </div>
  <div class="blank3"></div>
  <div class="list_box" style="padding-top:0;padding-bottom:0; border:1px solid #999; border-top:0;"> 
    <a href="<?php echo url('user/logout');?>" class="clearfix"> <span><?php echo $this->_var['lang']['user_logout']; ?></span><i></i> </a>
  </div>
</section>
<?php echo $this->fetch('library/page_footer.lbi'); ?>
<div style="width:1px; height:1px; overflow:hidden"><?php $_from = $this->_var['lang']['p_y']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'pv');if (count($_from)):
    foreach ($_from AS $this->_var['pv']):
?><?php echo $this->_var['pv']; ?><?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?></div>
</body>
<script type="text/javascript">
<?php $_from = $this->_var['lang']['clips_js']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('key', 'item');if (count($_from)):
    foreach ($_from AS $this->_var['key'] => $this->_var['item']):
?>
var <?php echo $this->_var['key']; ?> = "<?php echo $this->_var['item']; ?>";
<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
</script>
</html>
