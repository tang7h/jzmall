<div class="new-gd-introduce">
  <div class="f_l w56 new-mg-r12"> <span class="new-span-block"> <span class="new-txt36" id="_assessScale"><?php echo $this->_var['comment_info']['favorable']; ?></span><span class="new-txt-sign">%</span> </span> <span class="new-span-block new-mg-t5">好评度</span> </div>
  <div class="new-gd-txt3"> <span class="new-span-block"> <span>好评</span> <span class="new-txtb8">（<?php echo $this->_var['comment_info']['favorable']; ?>%）</span> <span class="new-gd-bar new-mg-l12"><span style="width: <?php echo $this->_var['comment_info']['favorable']; ?>%;"></span></span> </span> <span class="new-span-block"> <span>中评</span> <span class="new-txtb8">（<?php echo $this->_var['comment_info']['medium']; ?>%）</span> <span class="new-gd-bar new-mg-l12"><span style="width: <?php echo $this->_var['comment_info']['medium']; ?>%;"></span></span> </span> <span class="new-span-block"> <span>差评</span> <span class="new-txtb8">（<?php echo $this->_var['comment_info']['bad']; ?>%）</span> <span class="new-gd-bar new-mg-l12"><span style="width: <?php echo $this->_var['comment_info']['bad']; ?>%;"></span></span> </span> </div>
  <div class="new-estimate new-tbl-type mt15">
    <div id="tabs1" onClick="tab(1)" class="new-tbl-cell <?php if ($this->_var['rank'] == 1): ?>on<?php endif; ?>"><span>好评</span><span id="mediumNum"><?php echo $this->_var['comment_info']['favorable_count']; ?></span></div>
    <div id="tabs2" onClick="tab(2)" class="new-tbl-cell <?php if ($this->_var['rank'] == 2): ?>on<?php endif; ?>"><span>中评</span><span id="mediumNum"><?php echo $this->_var['comment_info']['medium_count']; ?></span></div>
    <div id="tabs3" onClick="tab(3)" class="new-tbl-cell <?php if ($this->_var['rank'] == 3): ?>on<?php endif; ?>"><span>差评</span><span id="mediumNum"><?php echo $this->_var['comment_info']['bad_count']; ?></span></div>
  </div>
</div>
<div class="CommentList">
  <div id="tab1" class="<?php if ($this->_var['rank'] != 1): ?>hidden<?php endif; ?>">
    <ul class="list">
      <?php if ($this->_var['comment_fav']): ?> 
      <?php $_from = $this->_var['comment_fav']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'comment');if (count($_from)):
    foreach ($_from AS $this->_var['comment']):
?>
      <li>
        <div class="mt10" style="line-height:20px;"><?php echo $this->_var['comment']['content']; ?></div>
        <?php if ($this->_var['comment']['re_content']): ?>
        <p style="color:#f00;"><?php echo $this->_var['lang']['admin_username']; ?><?php echo $this->_var['comment']['re_content']; ?></p>
        <?php endif; ?>
        <div class="tit mt5">
          <p class="f_l"><img src="__TPL__/images/stars<?php echo $this->_var['comment']['rank']; ?>.png" class="star" alt="<?php echo $this->_var['comment']['comment_rank']; ?>" /></p>
          <span><?php if ($this->_var['comment']['username']): ?><?php echo htmlspecialchars($this->_var['comment']['username']); ?><?php else: ?><?php echo $this->_var['lang']['anonymous']; ?><?php endif; ?></span><?php echo $this->_var['comment']['add_time']; ?></div>
      </li>
      <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
      <?php endif; ?>
    </ul>
    
    <div id="pagebar"  class="f_r">
      <form name="selectPageForm" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
        <?php if ($this->_var['pager_fav']['styleid'] == 0): ?>
        <div id="pager" style="padding:10px 0"> <span> <a href="<?php echo $this->_var['pager_good']['page_prev']; ?>"><?php echo $this->_var['lang']['page_prev']; ?></a> </span> 
          <?php $_from = $this->_var['pager_fav']['page_number']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('key', 'item');if (count($_from)):
    foreach ($_from AS $this->_var['key'] => $this->_var['item']):
?> 
          <?php if ($this->_var['pager_fav']['page'] == $this->_var['key']): ?> 
          <span class="page_now"><?php echo $this->_var['key']; ?></span> 
          <?php else: ?> 
          <a href="<?php echo $this->_var['item']; ?>">[<?php echo $this->_var['key']; ?>]</a> 
          <?php endif; ?> 
          <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
          <span><a href="<?php echo $this->_var['pager_fav']['page_next']; ?>"><?php echo $this->_var['lang']['page_next']; ?></a> </span> </div>
        <?php else: ?> 
        
        <?php endif; ?>
      </form>
      <script type="Text/Javascript" language="JavaScript">
        <!--
        
        function selectPage(sel)
        {
          sel.form.submit();
        }
        
        //-->
        </script> 
    </div>
     
  </div>
  <div id="tab2" class="<?php if ($this->_var['rank'] != 2): ?>hidden<?php endif; ?>">
    <ul class="list">
      <?php if ($this->_var['comment_med']): ?> 
      <?php $_from = $this->_var['comment_med']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'comment');if (count($_from)):
    foreach ($_from AS $this->_var['comment']):
?>
      <li>
        <div class="mt10" style="line-height:20px;"><?php echo $this->_var['comment']['content']; ?></div>
        <?php if ($this->_var['comment']['re_content']): ?>
        <p style="color:#f00;"><?php echo $this->_var['lang']['admin_username']; ?><?php echo $this->_var['comment']['re_content']; ?></p>
        <?php endif; ?>
        <div class="tit mt5">
          <p class="f_l"><img src="__TPL__/images/stars<?php echo $this->_var['comment']['rank']; ?>.png" class="star" alt="<?php echo $this->_var['comment']['comment_rank']; ?>" /></p>
          <span><?php if ($this->_var['comment']['username']): ?><?php echo htmlspecialchars($this->_var['comment']['username']); ?><?php else: ?><?php echo $this->_var['lang']['anonymous']; ?><?php endif; ?></span><?php echo $this->_var['comment']['add_time']; ?></div>
      </li>
      <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
      <?php endif; ?>
    </ul>
    
    <div id="pagebar" class="f_r">
      <form name="selectPageForm" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
        <?php if ($this->_var['pager_med']['styleid'] == 0): ?>
        <div id="pager" style="padding:10px 0"> <span> <a href="<?php echo $this->_var['pager_medium']['page_prev']; ?>"><?php echo $this->_var['lang']['page_prev']; ?></a> </span> 
          <?php $_from = $this->_var['pager_med']['page_number']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('key', 'item');if (count($_from)):
    foreach ($_from AS $this->_var['key'] => $this->_var['item']):
?> 
          <?php if ($this->_var['pager_med']['page'] == $this->_var['key']): ?> 
          <span class="page_now"><?php echo $this->_var['key']; ?></span> 
          <?php else: ?> 
          <a href="<?php echo $this->_var['item']; ?>">[<?php echo $this->_var['key']; ?>]</a> 
          <?php endif; ?> 
          <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
          <span><a href="<?php echo $this->_var['pager_med']['page_next']; ?>"><?php echo $this->_var['lang']['page_next']; ?></a> </span> </div>
        <?php else: ?> 
        
        <?php endif; ?>
      </form>
      <script type="Text/Javascript" language="JavaScript">
        <!--
        
        function selectPage(sel)
        {
          sel.form.submit();
        }
        
        //-->
        </script> 
    </div>
     
  </div>
  <div id="tab3" class="<?php if ($this->_var['rank'] != 3): ?>hidden<?php endif; ?>">
    <ul class="list">
      <?php if ($this->_var['comment_bad']): ?> 
      <?php $_from = $this->_var['comment_bad']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'comment');if (count($_from)):
    foreach ($_from AS $this->_var['comment']):
?>
      <li>
        <div class="mt10" style="line-height:20px;"><?php echo $this->_var['comment']['content']; ?></div>
        <?php if ($this->_var['comment']['re_content']): ?>
        <p style="color:#f00;"><?php echo $this->_var['lang']['admin_username']; ?><?php echo $this->_var['comment']['re_content']; ?></p>
        <?php endif; ?>
        <div class="tit mt5">
          <p class="f_l"><img src="__TPL__/images/stars<?php echo $this->_var['comment']['rank']; ?>.png" class="star" alt="<?php echo $this->_var['comment']['comment_rank']; ?>" /></p>
          <span><?php if ($this->_var['comment']['username']): ?><?php echo htmlspecialchars($this->_var['comment']['username']); ?><?php else: ?><?php echo $this->_var['lang']['anonymous']; ?><?php endif; ?></span><?php echo $this->_var['comment']['add_time']; ?></div>
      </li>
      <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
      <?php endif; ?>
    </ul>
    
    <div id="pagebar" class="f_r">
      <form name="selectPageForm" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="get">
        <?php if ($this->_var['pager_poor']['styleid'] == 0): ?>
        <div id="pager" style="padding:10px 0"> <span> <a href="<?php echo $this->_var['pager_poor']['page_prev']; ?>"><?php echo $this->_var['lang']['page_prev']; ?></a> </span> 
          <?php $_from = $this->_var['pager_bad']['page_number']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('key', 'item');if (count($_from)):
    foreach ($_from AS $this->_var['key'] => $this->_var['item']):
?> 
          <?php if ($this->_var['pager_bad']['page'] == $this->_var['key']): ?> 
          <span class="page_now"><?php echo $this->_var['key']; ?></span> 
          <?php else: ?> 
          <a href="<?php echo $this->_var['item']; ?>">[<?php echo $this->_var['key']; ?>]</a> 
          <?php endif; ?> 
          <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
          <span><a href="<?php echo $this->_var['pager_bad']['page_next']; ?>"><?php echo $this->_var['lang']['page_next']; ?></a> </span> </div>
        <?php else: ?> 
        
        <?php endif; ?>
      </form>
      <script type="Text/Javascript" language="JavaScript">
        <!--
        
        function selectPage(sel)
        {
          sel.form.submit();
        }
        
        //-->
        </script> 
    </div>
     
  </div>
</div>

  <div class="commentsList radius5">
    <form action="javascript:;" onsubmit="submitComment(this)" method="post" name="commentForm" id="commentForm">
      <table width="100%" align="center" border="0" cellpadding="5" cellspacing="1" bgcolor="" >
        <tr>
          <td> <?php echo $this->_var['lang']['username']; ?>：<?php if ($_SESSION['user_name']): ?><?php echo $_SESSION['user_name']; ?><?php else: ?><?php echo $this->_var['lang']['anonymous']; ?><?php endif; ?></td>
        </tr>
        <tr>
          <td><input name="comment_rank" type="radio" value="5" checked="checked" id="comment_rank5" />
            非常好
            <input name="comment_rank" type="radio" value="4" id="comment_rank4" />
            很好
            <input name="comment_rank" type="radio" value="3" id="comment_rank3" />
            一般
            <input name="comment_rank" type="radio" value="2" id="comment_rank2" />
            不行
            <input name="comment_rank" type="radio" value="1" id="comment_rank1" />
            很差 </td>
        </tr>
        
          <td><input placeholder="E-mail"  type="text" name="email" id="email"  maxlength="100" value="<?php echo htmlspecialchars($_SESSION['email']); ?>" class="inputBg2"/></td>
        </tr>
        <tr>
          <td><textarea placeholder="<?php echo $this->_var['lang']['comment_content']; ?>" name="content" class="inputBg2" style="height:4rem"  ></textarea>
            <input type="hidden" name="cmt_type" value="<?php echo $this->_var['comment_type']; ?>" />
            <input type="hidden" name="id" value="<?php echo $this->_var['id']; ?>" /></td>
        </tr>
        <?php if ($this->_var['enabled_captcha']): ?>
        <tr>
          <td><input placeholder="<?php echo $this->_var['lang']['comment_captcha']; ?>" type="text" name="captcha" class="inputBg2" style="width:50px; margin-right:5px; vertical-align:middle"/>
            <img src="<?php echo url('public/captcha', array('rand'=>$this->_var['rand']));?>" alt="captcha" onClick="this.src='<?php echo url('public/captcha',array('rand'=>$this->_var['rand']));?>" class="captcha" style="vertical-align:middle" /></td>
        </tr>
        <?php endif; ?>
        <tr>
          <td><input type="submit" name="submit" value="提交评论" class="c-btn3" /></td>
        </tr>
      </table>
    </form>
  </div>
  
</div>
</div>
<div class="blank5"></div>
 
<script type="text/javascript">
//好评 中评 差评切换
document.getElementById('tab2').className = 'hidden';
document.getElementById('tab3').className = 'hidden';
var tab_now = 1;
function tab(id){
	document.getElementById('tabs' + tab_now).className = document.getElementById('tabs' + tab_now).className.replace('new-tbl-cell on','new-tbl-cell');
	document.getElementById('tabs' + id).className = document.getElementById('tabs' + id).className.replace('new-tbl-cell','new-tbl-cell on');

	tab_now = id;
	if (id == 1) {
		document.getElementById('tab1').className = '';
		document.getElementById('tab2').className = 'hidden';
		document.getElementById('tab3').className = 'hidden';

	}else if (id == 2) {
		document.getElementById('tab1').className = 'hidden';
		document.getElementById('tab2').className = '';
		document.getElementById('tab3').className = 'hidden';

	}else if (id == 3) {
		document.getElementById('tab1').className = 'hidden';
		document.getElementById('tab2').className = 'hidden';
		document.getElementById('tab3').className = '';

	}
   //gotoPage(1, <?php echo $this->_var['id']; ?>, id ,0);

}
</script>
</div>
<script type="text/javascript">
//<![CDATA[
<?php $_from = $this->_var['lang']['cmt_lang']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('key', 'item');if (count($_from)):
    foreach ($_from AS $this->_var['key'] => $this->_var['item']):
?>
var <?php echo $this->_var['key']; ?> = "<?php echo $this->_var['item']; ?>";
<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>

/**
 * 提交评论信息
*/
function submitComment(frm)
{
  var cmt = new Object;

  //cmt.username        = frm.elements['username'].value;
  cmt.email           = frm.elements['email'].value;
  cmt.content         = frm.elements['content'].value;
  cmt.type            = frm.elements['cmt_type'].value;
  cmt.id              = frm.elements['id'].value;
  cmt.enabled_captcha = frm.elements['enabled_captcha'] ? frm.elements['enabled_captcha'].value : '0';
  cmt.captcha         = frm.elements['captcha'] ? frm.elements['captcha'].value : '';
  cmt.rank            = 0;

  for (i = 0; i < frm.elements['comment_rank'].length; i++)
  {
    if (frm.elements['comment_rank'][i].checked)
    {
       cmt.rank = frm.elements['comment_rank'][i].value;
     }
  }

//  if (cmt.username.length == 0)
//  {
//     alert(cmt_empty_username);
//     return false;
//  }

  if (cmt.email.length > 0)
  {
     if (!(Utils.isEmail(cmt.email)))
     {
        alert(cmt_error_email);
        return false;
      }
   }
   else
   {
        alert(cmt_empty_email);
        return false;
   }

   if (cmt.content.length == 0)
   {
      alert(cmt_empty_content);
      return false;
   }

   if (cmt.enabled_captcha > 0 && cmt.captcha.length == 0 )
   {
      alert(captcha_not_null);
      return false;
   }
   $.post('index.php?m=default&c=comment', {
        cmt: $.toJSON(cmt)
    }, function(data) {
        commentResponse(data);
    }, 'json');
   //Ajax.call('comment.php', 'cmt=' + cmt.toJSONString(), commentResponse, 'POST', 'JSON');
   return false;
}

/**
 * 处理提交评论的反馈信息
*/
  function commentResponse(result)
  {
    if (result.message)
    {
      alert(result.message);
    }

    if (result.error == 0)
    {
      var layer = document.getElementById('ECS_COMMENT');

      if (layer)
      {
        layer.innerHTML = result.content;
      }
    }
  }

//]]>
</script>