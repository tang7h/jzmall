<?php echo $this->fetch('library/page_header.lbi'); ?>
<div id="page" style="right: 0px; left: 0px; display: block;">
  <header id="header">
    <div class="header_l header_return"><a href="javascript:history.go(-1);"><span></span></a></div>
    <div id="search_box2">
      <div class="search_box" id="searchBox"><?php echo $this->_var['lang']['no_keywords']; ?></div>
    </div>
    <div class="header_r header_search"> <a class="new-a-jd" onClick="showSearch()"><span></span></a></div>
    <div id="search_box">
      <?php echo $this->fetch('library/page_menu.lbi'); ?></div>
     <div class="search_box search_2" >
      <div class="search_2Box">
        <form method="post" action="<?php echo url('category/index');?>" name="searchForm" id="searchForm_id">
          <a href="#" class="new-a-cancel"><?php echo $this->_var['lang']['is_cancel']; ?></a>
          <div class="search_2BoxCon">
            <input placeholder="<?php echo $this->_var['lang']['no_keywords']; ?>" name="keywords" type="text" id="keywordBox" style="color:#c3c2c2;" />
            <a href="javascript:void(0);" target="_self" class="new-s-close new-s-close-v1"></a>
            <button class="new-s-srch" type="submit" onclick="return check('keywordBox')"><span></span></button>
          </div>
        </form>
      </div>
    </div>
  </header>
  <?php echo $this->fetch('library/goods_list_act.lbi'); ?>
</div>
<?php echo $this->fetch('library/page_footer.lbi'); ?>
<script type="text/javascript">
get_asynclist("<?php echo url('activity/asynclist_list', array('id'=>$this->_var['id'], 'category'=>$this->_var['category'], 'brand'=>$this->_var['brand_id'], 'price_min'=>$this->_var['price_min'], 'price_max'=>$this->_var['price_max'], 'filter_attr'=>$this->_var['filter_attr'], 'sort'=>$this->_var['sort'], 'order'=>$this->_var['order']));?>" , '__TPL__/images/loader.gif');
$(function(){
	$("#searchBox").click(function(){
		$(".search_2").css("display","block");
		$("#keywordBox").focus();
	});
	
	$(".new-s-close").click(function(){
		$("#keywordBox").attr("placeholder","").val("").focus();
	});
	
	$(".new-a-cancel").click(function(){
		$(".search_2").css("display","none");
	});
});
</script> 
</body>
</html>
