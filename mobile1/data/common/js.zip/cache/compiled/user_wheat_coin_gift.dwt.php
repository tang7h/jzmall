<?php echo $this->fetch('library/page_header.lbi'); ?>
<div id="tbh5v0">
  <header id="header">
    <div class="header_l header_return"> <a href="<?php echo url('user/index');?>"><span>返回</span></a></div>
    <h1> <?php echo $this->_var['title']; ?> </h1>
  </header>
  <section class="wrap" style="border:0;">
  <div class="InfoBox">
    <form name="wheat_coin_gift" action="<?php echo url('user/wheat_coin_gift');?>" method="post" onSubmit="return wheat_coin_gift()" >
      <section class="order_box padd1 radius10" style="padding-top:0;padding-bottom:0;">
        <div class="table_box table_box2">
          <dl>
            <dd class="dd1">赠送帐号：</dd>
            <input  placeholder="请输入帐号" name="user_name_sk" type="text"  class="dd2" />
          </dl>
          <dl>
            <dd class="dd1">赠送商城券：</dd>
            <input placeholder="帐号可用商城券为<?php echo $this->_var['wheat_coin']; ?>个" name="wheat_coin" type="text" class="dd2" />
          </dl>
        </div>
      </section>
      <div class="blank3"></div>
      <input name="submit" type="submit" class="c-btn4" value="赠送" />
    </form>
  </div>
</section>
</div>
<?php echo $this->fetch('library/page_footer.lbi'); ?>
<script>
function wheat_coin_gift() {
	var frm = document.forms['wheat_coin_gift'];
	var user_name_sk = frm.elements['user_name_sk'].value;
	var wheat_coin = frm.elements['wheat_coin'].value;
	var msg = '';

	if (user_name_sk.length == 0) {
		msg += '收款帐号不能为空' + '\n';
	}

	if (wheat_coin.length == 0) {
		msg += '赠送商城券不能为空' + '\n';
	}

	if (msg.length > 0) {
		alert(msg);
		return false;
	} else {
		return true;
	}
}
</script>
</body></html>