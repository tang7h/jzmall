<?php
return array(
    'DB_HOST'   => 'localhost',
    'DB_USER'   => 'root',
    'DB_PWD'   => 'ECMobanHost456',
    'DB_NAME'   => 'kehujd',
    'DB_PREFIX'   => 'ecs_',
    'DB_PORT'   => '3306',
    'DB_CHARSET'   => 'utf8',
    'DB_TYPE'   => 'mysql',
);
